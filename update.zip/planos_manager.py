"""
PlanosManager PRO v2.0 - Presentaciones Profesionales

Nuevas funcionalidades:
- Sistema de capas con visibilidad por categoría
- Etiquetas y anotaciones personalizables
- Exportación a PDF/PNG de alta calidad
- Generación automática de reportes
- Medición de distancias
- Undo/Redo completo
- Base de datos de elementos con propiedades
- Grid y reglas de medición
- Plantillas de presentación
- Duplicar elementos con Ctrl+D
- Selección múltiple con Ctrl+Click
"""

import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, ttk
from PIL import Image, ImageTk, ImageOps, ImageDraw, ImageFont
import os
import math
import json
from datetime import datetime
import io
from utils_paths import get_resource_path
import requests
import json


# Intentar importar pdf2image (no obligatorio)
try:
    from pdf2image import convert_from_path
    PDF2IMAGE_AVAILABLE = True
except Exception:
    PDF2IMAGE_AVAILABLE = False

# PyMuPDF (fitz) mejor opción standalone
try:
    import fitz
    PYMUPDF_AVAILABLE = True
except ImportError:
    PYMUPDF_AVAILABLE = False

# Para exportar a PDF
try:
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.pdfgen import canvas as pdf_canvas
    from reportlab.lib.utils import ImageReader
    from reportlab.platypus import Table, TableStyle, Paragraph, SimpleDocTemplate, PageBreak, Image as RLImage
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    REPORTLAB_AVAILABLE = True
except Exception:
    REPORTLAB_AVAILABLE = False


import sqlite3
import shutil

PROYECTOS_DIR = os.path.join(os.path.dirname(__file__), "proyectos", "planos_data")

# TkinterMapView
try:
    import tkintermapview
    MAPVIEW_AVAILABLE = True
except ImportError:
    MAPVIEW_AVAILABLE = False

if not os.path.exists(PROYECTOS_DIR):
    os.makedirs(PROYECTOS_DIR)

class PlanosDB:
    def __init__(self):
        self.db_path = os.path.join(PROYECTOS_DIR, "planos.db")
        self._init_db()

    def _init_db(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            file_path TEXT NOT NULL,
            owner TEXT NOT NULL,
            created_at TEXT,
            updated_at TEXT
        )""")
        c.execute("""CREATE TABLE IF NOT EXISTS shares (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER,
            shared_with TEXT,
            permission TEXT DEFAULT 'read',
            FOREIGN KEY(project_id) REFERENCES projects(id)
        )""")
        conn.commit()
        conn.close()

    def create_project(self, name, owner, file_path):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        c.execute("INSERT INTO projects (name, owner, file_path, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                  (name, owner, file_path, now, now))
        pid = c.lastrowid
        conn.commit()
        conn.close()
        return pid

    def update_project(self, pid, name=None):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if name:
            c.execute("UPDATE projects SET name=?, updated_at=? WHERE id=?", (name, now, pid))
        else:
            c.execute("UPDATE projects SET updated_at=? WHERE id=?", (now, pid))
        conn.commit()
        conn.close()

    def get_user_projects(self, user):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM projects WHERE owner=? ORDER BY updated_at DESC", (user,))
        projs = [dict(row) for row in c.fetchall()]
        conn.close()
        return projs

    def get_shared_projects(self, user):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        # Join to get project details
        c.execute("""
            SELECT p.*, s.permission 
            FROM projects p 
            JOIN shares s ON p.id = s.project_id 
            WHERE s.shared_with=?
            ORDER BY p.updated_at DESC
        """, (user,))
        projs = [dict(row) for row in c.fetchall()]
        conn.close()
        return projs

    def share_project(self, pid, target_user):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        # Verify not already shared
        c.execute("SELECT id FROM shares WHERE project_id=? AND shared_with=?", (pid, target_user))
        if c.fetchone():
            conn.close()
            return False
        
        c.execute("INSERT INTO shares (project_id, shared_with, permission) VALUES (?, ?, ?)",
                  (pid, target_user, 'read')) # Default read, could be write
        conn.commit()
        conn.close()
        return True

    def delete_project(self, pid):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("DELETE FROM shares WHERE project_id=?", (pid,))
        c.execute("DELETE FROM projects WHERE id=?", (pid,))
        conn.commit()
        conn.close()


class PlanosManagerPro:
    def __init__(self, parent, current_user=None, auto_wizard=False):
        # Si parent es un Toplevel, lo usamos como ventana principal
        # Si es un Frame, nos adaptamos para incrustarnos (modo embedded)
        self.is_embedded = not isinstance(parent, tk.Toplevel)

        if self.is_embedded:
            self.parent = parent
            # En modo embedded, 'win' será el frame padre donde dibujamos
            # No podemos configurar title o state zoomed aquí, eso es responsabilidad del contenedor
            self.win = tk.Frame(parent, bg="#ffffff")
            self.win.pack(fill="both", expand=True)
        else:
            self.win = parent
            self.parent = parent.master
            # Configurar ventana solo si es Toplevel
            self.win.title("Planos Manager PRO v2.0")
            try:
                self.win.state("zoomed")
            except:
                pass
            self.win.configure(bg="#ffffff")
            self.win.protocol("WM_DELETE_WINDOW", self._on_close)
            self.win.deiconify()
            self.win.grab_set()
        
        self.current_user = current_user or {"username": "Usuario", "is_admin": 0}

        # Estado del plano
        self.plan_path = None
        self.plan_image = None
        self.plan_pil = None
        self.scale = 1.0
        self.pan_active = False
        self.pan_start = (0, 0)
        self.space_pressed = False
        self.shift_pressed = False
        self.ctrl_pressed = False

        # Configuración de proyecto
        self.project_name = "Proyecto sin nombre"
        self.project_client = ""
        self.project_notes = ""

        # Icon placement state
        self.current_icon_path = None
        self.current_icon_tipo = None
        self.placing_mode = False

        # Elementos en canvas
        self.elements = []
        self.selected_el = None
        self.selected_elements = []  # Para selección múltiple

        # Historial para Undo/Redo
        self.history = []
        self.history_index = -1
        self.max_history = 50

        # Capas y visibilidad
        self.layers_visible = {
            "intrusion": True,
            "cctv": True,
            "ccaa": True,
            "incendio": True,
            "labels": True,
            "walls": True,
            "measurements": True
        }

        # Grid settings
        self.show_grid = False
        self.grid_size = 50
        
        # Scale / Calibration
        self.pixels_per_meter = None
        self.calibrating = False
        self.calibration_start = None
        # Measurement tool
        self.measuring = False
        self.measure_start = None
        self.measure_line = None
        self.measure_text = None

        # Wall drawing
        self.drawing_wall = False
        self.wall_start = None
        self.walls = []

        # Labels
        self.labels = []

        # Barrier Tool State
        self.drawing_barrier = False
        self.barrier_step = 0
        self.barrier_start = None


        # Database
        self.db = PlanosDB()
        self.current_project_id = None
        
        # UI
        if self.is_embedded:
             self._show_dashboard()
        else:
             # Standalone test mode usually
             self._build_editor_ui()
             
        if auto_wizard:
             self.win.after(200, self._new_project_wizard)

        self._bind_keyboard_shortcuts()

    # ---------------------------
    # Dashboard (Project Manager)
    # ---------------------------
    def _show_dashboard(self):
        # Limpiar ventana actual
        for widget in self.win.winfo_children():
            widget.destroy()

        self.in_dashboard = True

        # Header
        header = tk.Frame(self.win, bg="#263238", height=60)
        header.pack(fill="x")
        tk.Label(header, text="Gestor de Proyectos - Planos", bg="#263238", fg="white", 
                font=("Segoe UI", 14, "bold")).pack(pady=15)

        content = tk.Frame(self.win, bg="#eceff1")
        content.pack(fill="both", expand=True, padx=20, pady=20)

        # -- Left: My Projects --
        frame_my = tk.LabelFrame(content, text="Mis Proyectos", bg="white")
        frame_my.pack(side="left", fill="both", expand=True, padx=(0, 10))

        self.tree_my = ttk.Treeview(frame_my, columns=("fecha",), displaycolumns=("fecha",))
        self.tree_my.heading("#0", text="Nombre")
        self.tree_my.heading("fecha", text="Última Modificación")
        self.tree_my.pack(fill="both", expand=True, padx=5, pady=5)
        self.tree_my.bind("<Double-1>", lambda e: self._open_selected_project("my"))

        # -- Right: Shared With Me --
        frame_shared = tk.LabelFrame(content, text="Compartidos conmigo", bg="white")
        frame_shared.pack(side="right", fill="both", expand=True, padx=(10, 0))

        self.tree_shared = ttk.Treeview(frame_shared, columns=("owner", "fecha"), displaycolumns=("owner", "fecha"))
        self.tree_shared.heading("#0", text="Nombre")
        self.tree_shared.heading("owner", text="Propietario")
        self.tree_shared.heading("fecha", text="Fecha")
        self.tree_shared.pack(fill="both", expand=True, padx=5, pady=5)
        self.tree_shared.bind("<Double-1>", lambda e: self._open_selected_project("shared"))

        # Controls
        controls = tk.Frame(content, bg="#eceff1")
        controls.pack(side="bottom", fill="x", pady=10)

        tk.Button(controls, text="➕ Nuevo Proyecto", bg="#2196f3", fg="white", font=("Segoe UI", 10, "bold"),
                 command=self._new_project_wizard).pack(side="left", padx=5)
        
        tk.Button(controls, text="📂 Abrir Seleccionado", bg="#4caf50", fg="white",
                 command=lambda: self._open_selected_project("auto")).pack(side="left", padx=5)

        tk.Button(controls, text="🔗 Compartir", bg="#ff9800", fg="white",
                 command=self._share_selected_project).pack(side="left", padx=5)

        tk.Button(controls, text="🗑️ Eliminar", bg="#f44336", fg="white",
                 command=self._delete_project_db).pack(side="left", padx=5)

        self._refresh_dashboard()

    def _refresh_dashboard(self):
        # Mis proyectos
        for item in self.tree_my.get_children():
            self.tree_my.delete(item)
        
        my_projs = self.db.get_user_projects(self.current_user["username"])
        for p in my_projs:
            self.tree_my.insert("", "end", iid=f"my_{p['id']}", text=p['name'], values=(p['updated_at'],))
        
        # Compartidos
        for item in self.tree_shared.get_children():
            self.tree_shared.delete(item)
        
        shared_projs = self.db.get_shared_projects(self.current_user["username"])
        for p in shared_projs:
             self.tree_shared.insert("", "end", iid=f"sh_{p['id']}", text=p['name'], values=(p['owner'], p['updated_at']))

    # ---------------------------
    # UI Building (Editor)
    # ---------------------------
    def _build_editor_ui(self):
        self.in_dashboard = False
        # Limpiar
        for widget in self.win.winfo_children():
            widget.destroy()
            
        # ... (rest of standard UI) ...
        self._build_ui_structure()

    def _build_ui_structure(self):
        # Top menu frame
        top = tk.Frame(self.win, bg="#263238", height=60)
        top.pack(side="top", fill="x")

        # Archivo
        file_frame = tk.LabelFrame(top, text="Archivo", bg="#263238", fg="white")
        file_frame.pack(side="left", padx=5, pady=5)
        
        tk.Button(file_frame, text="⬅ Volver", command=self._show_dashboard, 
                 bg="#546e7a", fg="white", width=8).pack(side="left", padx=2)
        tk.Button(file_frame, text="💾 Guardar", command=self._save_project_db,
                 bg="#388e3c", fg="white", width=10).pack(side="left", padx=2)
        
        # Herramientas
        tools_frame = tk.LabelFrame(top, text="Herramientas", bg="#263238", fg="white")
        tools_frame.pack(side="left", padx=5, pady=5)
        
        tk.Button(tools_frame, text="🏗️ Pared", command=self._toggle_draw_wall,
                 width=8).pack(side="left", padx=2)
        tk.Button(tools_frame, text="📏 Medir", command=self._toggle_measure,
                 width=8).pack(side="left", padx=2)
        tk.Button(tools_frame, text="🏷️ Etiqueta", command=self._add_label,
                  width=10).pack(side="left", padx=2)

        tk.Button(tools_frame, text="⊞ Grid", command=self._toggle_grid,
                  width=8).pack(side="left", padx=2)
                  
        self.snap_var = tk.BooleanVar(value=False)
        tk.Checkbutton(tools_frame, text="Snap", variable=self.snap_var, 
                       bg="#263238", fg="white", selectcolor="#546e7a").pack(side="left", padx=2)

        tk.Button(tools_frame, text="📏 Calibrar", command=self._toggle_calibration,
                  bg="#ffeb3b", width=10).pack(side="left", padx=2)

        # Exportar
        export_frame = tk.LabelFrame(top, text="Exportar", bg="#263238", fg="white")
        export_frame.pack(side="left", padx=5, pady=5)
        
        tk.Button(export_frame, text="📄 PDF", command=self._export_to_pdf,
                 bg="#d32f2f", fg="white", width=8).pack(side="left", padx=2)
        tk.Button(export_frame, text="🖼️ PNG", command=self._export_to_image,
                 bg="#7b1fa2", fg="white", width=8).pack(side="left", padx=2)
        tk.Button(export_frame, text="📊 Reporte", command=self._generate_report,
                 bg="#0097a7", fg="white", width=10).pack(side="left", padx=2)
                 
        self.legend_var = tk.BooleanVar(value=True)
        tk.Checkbutton(export_frame, text="Auto Leyenda", variable=self.legend_var,
                       bg="#263238", fg="white", selectcolor="#546e7a").pack(side="left", padx=5)

        # Edición
        edit_frame = tk.LabelFrame(top, text="Edición", bg="#263238", fg="white")
        edit_frame.pack(side="left", padx=5, pady=5)
        
        tk.Button(edit_frame, text="↶ Deshacer", command=self._undo,
                 width=10).pack(side="left", padx=2)
        tk.Button(edit_frame, text="↷ Rehacer", command=self._redo,
                 width=10).pack(side="left", padx=2)

        if not self.is_embedded:
            tk.Button(top, text="❌ Cerrar", command=self._on_close,
                     bg="#c62828", fg="white").pack(side="right", padx=8, pady=8)

        # Status Bar (Bottom)
        self.status_var = tk.StringVar()
        self.status_var.set("Listo")
        self.status_bar = tk.Label(self.win, textvariable=self.status_var, bd=1, relief=tk.SUNKEN, anchor="w", bg="#eceff1", font=("Segoe UI", 9))
        self.status_bar.pack(side="bottom", fill="x")

        # Left panel (categories + layers)
        left = tk.Frame(self.win, bg="#ECEFF1", width=240)
        left.pack(side="left", fill="y")

        # Project info
        info_frame = tk.LabelFrame(left, text="Información del Proyecto", bg="#ECEFF1")
        info_frame.pack(fill="x", padx=5, pady=5)
        
        tk.Button(info_frame, text="✏️ Editar Info", command=self._edit_project_info,
                 width=20).pack(pady=5)

        # Categories
        tk.Label(left, text="Categorías de Iconos", bg="#ECEFF1", 
                font=("Segoe UI", 11, "bold")).pack(pady=10)

        self.cat_buttons = {}
        categories = [
            ("🚨 Intrusión", "intrusion"),
            ("📹 CCTV", "cctv"),
            ("❄️ Control Acceso", "ccaa"),
            ("🔥 Incendio", "fuego")
        ]

        for (label, folder) in categories:
            b = tk.Button(left, text=label, width=25, 
                         command=lambda f=folder: self._open_icon_picker(f))
            b.pack(pady=3)
            self.cat_buttons[folder] = b

        # Layers control
        layers_frame = tk.LabelFrame(left, text="Control de Capas", bg="#ECEFF1")
        layers_frame.pack(fill="x", padx=5, pady=10)

        self.layer_vars = {}
        for layer, visible in self.layers_visible.items():
            var = tk.BooleanVar(value=visible)
            self.layer_vars[layer] = var
            cb = tk.Checkbutton(layers_frame, text=layer.capitalize(), 
                               variable=var, bg="#ECEFF1",
                               command=lambda l=layer: self._toggle_layer(l))
            cb.pack(anchor="w", padx=10, pady=2)

        # Right panel (properties + element list)
        right = tk.Frame(self.win, bg="#F7F7F7", width=280)
        right.pack(side="right", fill="y")

        # Properties
        prop_frame = tk.LabelFrame(right, text="Propiedades", bg="#F7F7F7",
                                   font=("Segoe UI", 11, "bold"))
        prop_frame.pack(fill="x", padx=5, pady=5)

        self.prop_name = tk.Label(prop_frame, text="Elemento: -", bg="#F7F7F7")
        self.prop_name.pack(anchor="w", padx=10, pady=4)
        
        self.prop_tipo = tk.Label(prop_frame, text="Tipo: -", bg="#F7F7F7")
        self.prop_tipo.pack(anchor="w", padx=10)
        
        self.prop_coords = tk.Label(prop_frame, text="Coords: -", bg="#F7F7F7")
        self.prop_coords.pack(anchor="w", padx=10, pady=4)

        # Element details
        tk.Label(prop_frame, text="Nombre:", bg="#F7F7F7").pack(anchor="w", padx=10, pady=(8,0))
        self.entry_name = tk.Entry(prop_frame, width=25)
        self.entry_name.pack(anchor="w", padx=10)

        tk.Label(prop_frame, text="Modelo:", bg="#F7F7F7").pack(anchor="w", padx=10, pady=(8,0))
        self.entry_model = tk.Entry(prop_frame, width=25)
        self.entry_model.pack(anchor="w", padx=10)

        tk.Label(prop_frame, text="Zona:", bg="#F7F7F7").pack(anchor="w", padx=10, pady=(8,0))
        self.entry_zone = tk.Entry(prop_frame, width=25)
        self.entry_zone.pack(anchor="w", padx=10)

        tk.Label(prop_frame, text="Notas:", bg="#F7F7F7").pack(anchor="w", padx=10, pady=(8,0))
        self.entry_notes = tk.Text(prop_frame, width=25, height=3)
        self.entry_notes.pack(anchor="w", padx=10)

        # Camera cone properties
        cone_frame = tk.LabelFrame(prop_frame, text="Cono de Visión/Detección", bg="#F7F7F7")
        cone_frame.pack(fill="x", padx=5, pady=5)

        tk.Label(cone_frame, text="⚠️ Shift + Arrastrar = Rotar cono", 
                bg="#F7F7F7", fg="#d32f2f", font=("Segoe UI", 8, "italic")).pack(pady=4)

        tk.Label(cone_frame, text="Ángulo (°):", bg="#F7F7F7").pack(anchor="w", padx=10)
        self.entry_angle = tk.Spinbox(cone_frame, from_=10, to=180, width=8)
        self.entry_angle.pack(anchor="w", padx=10)
        
        tk.Label(cone_frame, text="Longitud (px):", bg="#F7F7F7").pack(anchor="w", padx=10, pady=(5,0))
        self.entry_len = tk.Spinbox(cone_frame, from_=20, to=2000, width=8)
        self.entry_len.pack(anchor="w", padx=10)
        
        tk.Label(cone_frame, text="Rotación (°):", bg="#F7F7F7").pack(anchor="w", padx=10, pady=(5,0))
        self.entry_rotation = tk.Spinbox(cone_frame, from_=0, to=360, width=8)
        self.entry_rotation.pack(anchor="w", padx=10)
        
        # Botones de rotación rápida
        quick_rot_frame = tk.Frame(cone_frame, bg="#F7F7F7")
        quick_rot_frame.pack(pady=5)
        
        tk.Button(quick_rot_frame, text="↑", width=3, 
                 command=lambda: self._quick_rotate(0)).grid(row=0, column=1, padx=2)
        tk.Button(quick_rot_frame, text="←", width=3,
                 command=lambda: self._quick_rotate(180)).grid(row=1, column=0, padx=2)
        tk.Button(quick_rot_frame, text="↓", width=3,
                 command=lambda: self._quick_rotate(90)).grid(row=1, column=1, padx=2)
        tk.Button(quick_rot_frame, text="→", width=3,
                 command=lambda: self._quick_rotate(0)).grid(row=1, column=2, padx=2)
        
        tk.Label(cone_frame, text="(Norte/Este/Sur/Oeste)", 
                bg="#F7F7F7", font=("Segoe UI", 7)).pack()

        # Action buttons
        tk.Button(prop_frame, text="✓ Aplicar Cambios", command=self._apply_properties,
                 bg="#4caf50", fg="white").pack(padx=10, pady=10, fill="x")
        
        tk.Button(prop_frame, text="🗑️ Eliminar", command=self._delete_selected,
                 bg="#d32f2f", fg="white").pack(padx=10, pady=5, fill="x")
        
        tk.Button(prop_frame, text="📋 Duplicar (Ctrl+D)", command=self._duplicate_selected,
                 bg="#1976d2", fg="white").pack(padx=10, pady=5, fill="x")

        # Element list
        list_frame = tk.LabelFrame(right, text="Lista de Elementos", bg="#F7F7F7")
        list_frame.pack(fill="both", expand=True, padx=5, pady=5)

        # Scrollbar for list
        scroll = tk.Scrollbar(list_frame)
        scroll.pack(side="right", fill="y")

        self.element_listbox = tk.Listbox(list_frame, yscrollcommand=scroll.set,
                                          selectmode="single")
        self.element_listbox.pack(fill="both", expand=True)
        scroll.config(command=self.element_listbox.yview)
        
        self.element_listbox.bind("<<ListboxSelect>>", self._on_listbox_select)

        # Stats
        self.stats_label = tk.Label(right, text="Total: 0 elementos", bg="#F7F7F7",
                                    font=("Segoe UI", 9))
        self.stats_label.pack(pady=5)

        # Canvas area
        canvas_frame = tk.Frame(self.win, bg="black")
        canvas_frame.pack(fill="both", expand=True, side="left")

        self.canvas = tk.Canvas(canvas_frame, bg="#ffffff", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)

        # Bindings
        self.canvas.bind("<Button-1>", self._canvas_click)
        self.canvas.bind("<ButtonPress-2>", self._pan_start)
        self.canvas.bind("<B2-Motion>", self._pan_move)
        self.canvas.bind("<ButtonRelease-2>", self._pan_end)
        self.canvas.bind("<B1-Motion>", self._on_drag_motion)
        self.canvas.bind("<ButtonRelease-1>", self._on_button_release)
        self.canvas.bind("<Button-3>", self._on_right_click)
        self.canvas.bind("<MouseWheel>", self._on_mousewheel)
        self.canvas.bind("<Motion>", self._on_mouse_move)
        
        # Foco para que funcione el scroll/zoom con rueda
        self.canvas.bind("<Enter>", lambda _: self.canvas.focus_set())
        # tk.Button(file_frame, text="📥 Cargar", command=self._import_project,
        #          bg="#f57c00", fg="white", width=10).pack(side="left", padx=2)

    def show_status(self, message, color="black"):
        """Mostrar mensaje en la barra de estado"""
        self.status_var.set(message)
        self.status_bar.config(fg=color)
        # Opcional: auto-limpiar después de unos segundos si es éxito
        if color == "green":
            self.win.after(5000, lambda: self.status_var.set("Listo") if self.status_var.get() == message else None)
            self.win.after(5000, lambda: self.status_bar.config(fg="black"))

    def _new_project_wizard(self):
        name = simpledialog.askstring("Nuevo Proyecto", "Nombre del proyecto:")
        if not name: return
        
        # Crear estructura vacía y abrir editor
        self.project_name = name
        self.project_client = ""
        self.project_notes = ""
        self.plan_path = None
        self.plan_pil = None
        self.current_project_id = None # Se creará ID al guardar por primera vez
        self.elements = []
        self.walls = []
        self.labels = []
        
        self._build_editor_ui()
        self._build_editor_ui()
        
        # Preguntar tipo de fondo
        choice = messagebox.askyesnocancel("Nuevo Proyecto", 
            "¿Cómo desea iniciar el plano?\n\n"
            "Sí: Cargar imagen o PDF\n"
            "No: Seleccionar ubicación en Mapa\n"
            "Cancelar: Lienzo en blanco")
            
        if choice is True:
            self._open_plan()
        elif choice is False:
            self._open_map_selector()


    def _open_selected_project(self, mode="auto"):
        item = None
        is_shared = False
        
        if mode == "my" or (mode=="auto" and self.tree_my.selection()):
             item = self.tree_my.selection()
             if item: item = item[0]
        elif mode == "shared" or (mode=="auto" and self.tree_shared.selection()):
             item = self.tree_shared.selection()
             is_shared = True
             if item: item = item[0]
        
        if not item: return

        # Parse ID from iid (my_123 or sh_123)
        try:
            pid = int(item.split('_')[1])
        except: return

        # Get path from DB
        conn = sqlite3.connect(self.db.db_path)
        c = conn.cursor()
        c.execute("SELECT * FROM projects WHERE id=?", (pid,))
        row = c.fetchone()
        conn.close()
        
        if not row:
             messagebox.showerror("Error", "Proyecto no encontrado en base de datos.")
             self._refresh_dashboard()
             return

        # Row: 0=id, 1=name, 2=path, 3=owner, ...
        file_path = row[2]
        
        if not os.path.exists(file_path):
             messagebox.showerror("Error", f"El archivo del proyecto no existe:\n{file_path}")
             return

        # Load JSON
        try:
             self.current_project_id = pid
             self._build_editor_ui()
             self._load_project_file(file_path)
             self._redraw_all() # Ensure everything is drawn
        except Exception as e:
             messagebox.showerror("Error", f"Error cargando proyecto:\n{e}")

    def _share_selected_project(self):
        item = self.tree_my.selection()
        if not item:
            messagebox.showwarning("Compartir", "Selecciona uno de TUS proyectos.")
            return
        
        pid = int(item[0].split('_')[1])
        
        target = simpledialog.askstring("Compartir", "Nombre de usuario destino:")
        if not target: return
        
        if self.db.share_project(pid, target):
            self.show_status(f"Compartido con {target}", "green")
        else:
            self.show_status("Ya compartido o error.", "orange")

    def _delete_project_db(self):
        item = self.tree_my.selection()
        if not item: return
        
        pid = int(item[0].split('_')[1])
        if messagebox.askyesno("Eliminar", "¿Seguro que quieres borrar este proyecto?"):
             # Get path to delete file too?
             # For safety, maybe keep file or delete it. Let's delete it to keep clean.
             conn = sqlite3.connect(self.db.db_path)
             c = conn.cursor()
             c.execute("SELECT file_path FROM projects WHERE id=?", (pid,))
             row = c.fetchone()
             conn.close()
             
             if row and os.path.exists(row[0]):
                 try:
                     os.remove(row[0])
                 except: pass

             self.db.delete_project(pid)
             self._refresh_dashboard()

    def _save_project_db(self):
        """Guardar proyecto en sistema gestionado"""
        if not self.project_name:
             self.project_name = simpledialog.askstring("Guardar", "Nombre del proyecto:")
             if not self.project_name: return

        # Path gestionado
        filename = f"proj_{self.current_user['username']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        # Si ya tiene ID, podríamos querer sobrescribir el mismo archivo...
        # Pero si queremos versionado simple, sobrescribimos.
        # Busquemos si ya tiene path en DB
        save_path = None
        if self.current_project_id:
             conn = sqlite3.connect(self.db.db_path)
             c = conn.cursor()
             c.execute("SELECT file_path FROM projects WHERE id=?", (self.current_project_id,))
             row = c.fetchone()
             conn.close()
             if row:
                 save_path = row[0]
        
        if not save_path:
             save_path = os.path.join(PROYECTOS_DIR, filename)

        # Build Data
        data = {
            "project_name": self.project_name,
            "project_client": self.project_client,
            "project_notes": self.project_notes,
            "plan_path": self.plan_path,
            "created_by": self.current_user["username"],
            "created_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "elements": [self._element_to_dict(el) for el in self.elements],
            "walls": self.walls,
            "labels": self.labels,
            # Guardar offset zoom/pan?
        }
        
        try:
            with open(save_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            # Update DB
            if self.current_project_id:
                self.db.update_project(self.current_project_id, self.project_name)
            else:
                self.current_project_id = self.db.create_project(self.project_name, self.current_user["username"], save_path)
            
            self.show_status("Proyecto guardado correctamente.", "green")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo guardar:\n{e}")

    def _load_project_file(self, path):
         # Same logic as _import_project but taking path arg
         with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
         
         self.project_name = data.get("project_name", "")
         self.project_client = data.get("project_client", "")
         self.project_notes = data.get("project_notes", "")
         
         plan_path = data.get("plan_path")
         if plan_path and os.path.exists(plan_path):
             self.plan_path = plan_path
             self.plan_pil = self._load_image_safe(plan_path)
             self._render_plan_image()
         
         self._clear_elements()
         for el in data.get("elements", []):
             p = el.get("path")
             if p and os.path.exists(p):
                 self._create_element(p, el.get("tipo"), el["x"], el["y"], True, el.get("cone"),
                                     el.get("name"), el.get("model"), el.get("zone"), el.get("notes"))
             elif el.get("tipo") == "barrier":
                 self._create_barrier(el["start"], el["end"], True, el.get("name"), el.get("model"))
         
         self.walls = data.get("walls", [])
         self.labels = data.get("labels", [])
         self._redraw_all()
         self._save_state()



    def _bind_keyboard_shortcuts(self):
        """Atajos de teclado"""
        # Enlazar al toplevel superior (sea la ventana principal o el Toplevel propio)
        top = self.win.winfo_toplevel()
        
        top.bind("<Control-z>", lambda e: self._undo())
        top.bind("<Control-y>", lambda e: self._redo())
        top.bind("<Control-d>", lambda e: self._duplicate_selected())
        top.bind("<Control-c>", lambda e: self._copy_element())
        top.bind("<Control-v>", lambda e: self._paste_element())
        top.bind("<Control-s>", lambda e: self._export_project())
        top.bind("<Delete>", lambda e: self._delete_selected())
        top.bind("<BackSpace>", lambda e: self._delete_selected())
        
        top.bind("<KeyPress-Shift_L>", lambda e: self._set_shift(True))
        top.bind("<KeyRelease-Shift_L>", lambda e: self._set_shift(False))
        top.bind("<KeyPress-Shift_R>", lambda e: self._set_shift(True))
        top.bind("<KeyRelease-Shift_R>", lambda e: self._set_shift(False))
        top.bind("<KeyPress-Control_L>", lambda e: self._set_ctrl(True))
        top.bind("<KeyRelease-Control_L>", lambda e: self._set_ctrl(False))
        top.bind("<KeyPress-Control_R>", lambda e: self._set_ctrl(True))
        top.bind("<KeyRelease-Control_R>", lambda e: self._set_ctrl(False))
        top.bind("<KeyPress-space>", lambda e: self._set_space(True))
        top.bind("<KeyRelease-space>", lambda e: self._set_space(False))

    # ---------------------------
    # Utilities
    # ---------------------------
    def _on_close(self):
        if messagebox.askyesno("Cerrar", "¿Desea guardar los cambios antes de cerrar?"):
            self._export_project()
        for el in self.elements:
            el.pop("image_ref", None)
            
        if not self.is_embedded:
            self.win.grab_release()
            self.win.destroy()
        else:
            # En modo embedded, simplemente limpiamos si es necesario
            # o destruimos nuestro frame contenedor
            self.win.destroy()

    def _set_shift(self, val):
        self.shift_pressed = val

    def _set_ctrl(self, val):
        self.ctrl_pressed = val

    def _set_space(self, val):
        self.space_pressed = val

    # ---------------------------
    # History Management (Undo/Redo)
    # ---------------------------
    def _save_state(self):
        """Guardar estado actual para undo/redo"""
        state = {
            "elements": [self._element_to_dict(el) for el in self.elements],
            "walls": list(self.walls),
            "labels": list(self.labels)
        }
        
        # Eliminar estados futuros si estamos en medio del historial
        if self.history_index < len(self.history) - 1:
            self.history = self.history[:self.history_index + 1]
        
        self.history.append(state)
        if len(self.history) > self.max_history:
            self.history.pop(0)
        else:
            self.history_index += 1

    def _element_to_dict(self, el):
        """Convertir elemento a dict para serialización. Guarda coordenadas relativas a la imagen original."""
        data = {
            "tipo": el["tipo"],
            "name": el.get("name", ""),
            "model": el.get("model", ""),
            "zone": el.get("zone", ""),
            "notes": el.get("notes", "")
        }
        
        bg_x, bg_y = 0, 0
        if hasattr(self, 'plan_canvas_id') and self.plan_canvas_id:
            try: 
                coords = self.canvas.coords(self.plan_canvas_id)
                if coords: bg_x, bg_y = coords[0], coords[1]
            except: pass
            
        scale = getattr(self, "scale", 1.0)
        
        if el["tipo"] == "barrier":
            sx, sy = el["start"]
            ex, ey = el["end"]
            data["start"] = ((sx - bg_x) / scale, (sy - bg_y) / scale)
            data["end"] = ((ex - bg_x) / scale, (ey - bg_y) / scale)
        else: # Normal icon element
            data["path"] = el["path"]
            data["x"] = (el["x"] - bg_x) / scale
            data["y"] = (el["y"] - bg_y) / scale
            if el.get("cone"):
                data["cone"] = {
                    "angle": el["cone"]["angle"],
                    "len": el["cone"]["len"],
                    "rotation": el["cone"]["rotation"]
                }
        return data

    def _restore_state(self, state):
        """Restaurar estado desde historial"""
        self._clear_elements()
        
        bg_x, bg_y = 0, 0
        if hasattr(self, 'plan_canvas_id') and self.plan_canvas_id:
            try: 
                coords = self.canvas.coords(self.plan_canvas_id)
                if coords: bg_x, bg_y = coords[0], coords[1]
            except: pass
            
        scale = getattr(self, "scale", 1.0)
        
        for el_data in state["elements"]:
            if el_data["tipo"] == "barrier":
                sx, sy = el_data["start"]
                ex, ey = el_data["end"]
                sx_c = sx * scale + bg_x
                sy_c = sy * scale + bg_y
                ex_c = ex * scale + bg_x
                ey_c = ey * scale + bg_y
                self._create_barrier((sx_c, sy_c), (ex_c, ey_c),
                                     from_import=True, name=el_data.get("name", ""),
                                     model=el_data.get("model", ""))
            else:
                cx = el_data["x"] * scale + bg_x
                cy = el_data["y"] * scale + bg_y
                self._create_element(
                    el_data["path"], el_data["tipo"], cx, cy,
                    from_import=True, cone_data=el_data.get("cone"),
                    name=el_data.get("name", ""),
                    model=el_data.get("model", ""),
                    zone=el_data.get("zone", ""),
                    notes=el_data.get("notes", "")
                )
        # Restaurar paredes y etiquetas
        self.walls = list(state.get("walls", []))
        self.labels = list(state.get("labels", []))
        self._redraw_all()

    def _undo(self):
        """Deshacer última acción"""
        if self.history_index > 0:
            self.history_index -= 1
            self._restore_state(self.history[self.history_index])

    def _redo(self):
        """Rehacer acción"""
        if self.history_index < len(self.history) - 1:
            self.history_index += 1
            self._restore_state(self.history[self.history_index])

    # ---------------------------
    # Project Info
    # ---------------------------
    def _edit_project_info(self):
        """Editar información del proyecto"""
        dialog = tk.Toplevel(self.win)
        dialog.title("Información del Proyecto")
        dialog.geometry("400x300")
        dialog.transient(self.win)
        dialog.grab_set()

        tk.Label(dialog, text="Nombre del Proyecto:").pack(pady=5)
        name_entry = tk.Entry(dialog, width=40)
        name_entry.insert(0, self.project_name)
        name_entry.pack(pady=5)

        tk.Label(dialog, text="Cliente:").pack(pady=5)
        client_entry = tk.Entry(dialog, width=40)
        client_entry.insert(0, self.project_client)
        client_entry.pack(pady=5)

        tk.Label(dialog, text="Notas:").pack(pady=5)
        notes_text = tk.Text(dialog, width=40, height=6)
        notes_text.insert("1.0", self.project_notes)
        notes_text.pack(pady=5)

        def save():
            self.project_name = name_entry.get()
            self.project_client = client_entry.get()
            self.project_notes = notes_text.get("1.0", "end-1c")
            dialog.destroy()

        tk.Button(dialog, text="Guardar", command=save, bg="#4caf50", 
                 fg="white").pack(pady=10)

    # ---------------------------
    # Open / Import / Export
    # ---------------------------
    def _load_image_safe(self, path):
        """Cargar imagen de forma segura (soporta PDF y formatos comunes)"""
        # print(f"DEBUG: Intentando cargar imagen/PDF: {path}")
        ext = os.path.splitext(path)[1].lower()
        
        pil_img = None
        
        if ext == ".pdf":
            if PYMUPDF_AVAILABLE:
                try:
                    # print("DEBUG: Usando PyMuPDF (fitz)...")
                    doc = fitz.open(path)
                    # print(f"DEBUG: PDF abierto. Paginas: {doc.page_count}")
                    
                    # Cargar página
                    page = doc.load_page(0)
                    
                    # Calcular DPI óptimo para no matar la memoria
                    # Si es plano gigante (A0/A1), 150 dpi puede ser mucho (5000x7000px)
                    # Vamos a intentar limitar el tamaño máximo
                    zoom = 1.0
                    mat = fitz.Matrix(zoom, zoom)
                    pix = page.get_pixmap(matrix=mat, dpi=150)
                    
                    # print(f"DEBUG: Pixmap inicial: {pix.width}x{pix.height}")
                    
                    # Si es gigante, bajar calidad
                    if pix.width > 4000 or pix.height > 4000:
                        # print("DEBUG: Imagen gigante detectada, reduciendo DPI...")
                        pix = page.get_pixmap(dpi=100)
                        # print(f"DEBUG: Nuevo Pixmap: {pix.width}x{pix.height}")

                    img_data = pix.tobytes("png")
                    pil_img = Image.open(io.BytesIO(img_data))
                    pil_img.load() # Forzar carga en memoria
                    doc.close()
                except Exception as e:
                    print(f"ERROR CRITICO PyMuPDF: {e}")
                    raise e
            elif PDF2IMAGE_AVAILABLE:
                print("DEBUG: Usando pdf2image...")
                pages = convert_from_path(path, dpi=150)
                pil_img = pages[0]
            else:
                raise Exception("Falta dependencia 'pymupdf' para abrir PDF.")
        else:
            pil_img = Image.open(path)
        
        # Validación final de tamaño PIL
        if pil_img:
            w, h = pil_img.size
            # print(f"DEBUG: Imagen PIL Check: {w}x{h}, Mode: {pil_img.mode}")
            
            # Limite duro de Tkinter (~8000px suele ser el límite seguro, ponemos 5000)
            MAX_DIM = 5000
            if w > MAX_DIM or h > MAX_DIM:
                # print(f"DEBUG: Redimensionando por exceso (> {MAX_DIM}px)")
                pil_img.thumbnail((MAX_DIM, MAX_DIM), Image.Resampling.LANCZOS)
        
        return pil_img

    def _open_plan(self):
        path = filedialog.askopenfilename(
            title="Abrir plano",
            filetypes=[("Imagenes", "*.png;*.jpg;*.jpeg;*.bmp"),
                      ("PDF", "*.pdf"), ("Todos","*.*")]
        )
        if not path:
            return
        
        try:
            self.plan_pil = self._load_image_safe(path)
            self.plan_path = path
            self._render_plan_image()
            self._clear_elements()
            self._save_state()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo abrir el plano:\n{e}")

    def _render_plan_image(self):
        """Renderizar imagen del plano en canvas"""
        if self.plan_pil is None:
            return
        
        try:
            print("DEBUG: Renderizando imagen en Canvas...")
            # Guardamos referenccia para el Garbage Collector
            self.plan_image = ImageTk.PhotoImage(self.plan_pil)
            print("DEBUG: PhotoImage creado.")
            
            existing = getattr(self, "plan_canvas_id", None)
            if existing:
                self.canvas.delete(existing)
            
            self.plan_canvas_id = self.canvas.create_image(0, 0, anchor="nw", 
                                                           image=self.plan_image)
            self.canvas.lower(self.plan_canvas_id)
            print("DEBUG: Imagen colocada en Canvas ID:", self.plan_canvas_id)
            
            # Configurar scrollregion
            w, h = self.plan_pil.size
            self.canvas.config(scrollregion=(0, 0, w, h))
            print(f"DEBUG: Scrollregion seteado a {w}x{h}")

            if self.show_grid:
                self._draw_grid()
                
        except Exception as e:
            # print(f"ERROR RENDERIZADO: {e}")
            messagebox.showerror("Error Visualización", f"No se pudo mostrar la imagen:\n{e}")

    # ... _render_plan_image and _export_project unchanged ...

    def _import_project(self):
        """Importar proyecto desde JSON"""
        file = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if not file:
            return
        
        try:
            with open(file, "r", encoding="utf-8") as f:
                data = json.load(f)
            
            self.project_name = data.get("project_name", "Proyecto sin nombre")
            self.project_client = data.get("project_client", "")
            self.project_notes = data.get("project_notes", "")
            
            plan_path = data.get("plan_path")
            if plan_path and os.path.exists(plan_path):
                try:
                    self.plan_path = plan_path
                    self.plan_pil = self._load_image_safe(plan_path)
                    self._render_plan_image()
                except Exception as e:
                    messagebox.showwarning("Error carga plano", f"No se pudo cargar imagen de fondo:\n{e}")
            else:
                messagebox.showwarning("Aviso", 
                    "El plano referenciado no existe. Cargando solo los elementos.")

            
            self._clear_elements()
            
            bg_x, bg_y = 0, 0
            if hasattr(self, 'plan_canvas_id') and self.plan_canvas_id:
                try:
                    coords = self.canvas.coords(self.plan_canvas_id)
                    if coords: bg_x, bg_y = coords[0], coords[1]
                except: pass
            scale = getattr(self, "scale", 1.0)
            
            for el in data.get("elements", []):
                if el.get("tipo") == "barrier":
                    sx, sy = el["start"]
                    ex, ey = el["end"]
                    sx_c = sx * scale + bg_x
                    sy_c = sy * scale + bg_y
                    ex_c = ex * scale + bg_x
                    ey_c = ey * scale + bg_y
                    self._create_barrier((sx_c, sy_c), (ex_c, ey_c),
                                         from_import=True, name=el.get("name", ""),
                                         model=el.get("model", ""))
                else:
                    path = el.get("path")
                    if path and os.path.exists(path):
                        cx = el.get("x", 0) * scale + bg_x
                        cy = el.get("y", 0) * scale + bg_y
                        self._create_element(
                            path, el.get("tipo"), cx, cy,
                            from_import=True, cone_data=el.get("cone"),
                            name=el.get("name", ""),
                            model=el.get("model", ""),
                            zone=el.get("zone", ""),
                            notes=el.get("notes", "")
                        )
            
            self.walls = data.get("walls", [])
            self.labels = data.get("labels", [])
            self._redraw_all()
            self._save_state()
            
            self.show_status("Proyecto importado correctamente.", "green")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo importar:\n{e}")

    # ---------------------------
    # Export to PDF/PNG
    # ---------------------------
    def _export_to_pdf(self):
        """Exportar a PDF con reporte"""
        if not REPORTLAB_AVAILABLE:
            messagebox.showerror("Dependencia", 
                "Exportar a PDF requiere reportlab instalado:\npip install reportlab")
            return
        
        file = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF", "*.pdf")],
            initialfile=f"{self.project_name}_presentacion.pdf"
        )
        if not file:
            return
        
        try:
            # Crear PDF
            doc = SimpleDocTemplate(file, pagesize=landscape(A4))
            story = []
            styles = getSampleStyleSheet()
            
            # Título
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=24,
                textColor=colors.HexColor('#1976d2'),
                spaceAfter=30,
            )
            story.append(Paragraph(self.project_name, title_style))
            
            # Info del proyecto
            info_text = f"""
            <b>Cliente:</b> {self.project_client}<br/>
            <b>Fecha:</b> {datetime.now().strftime("%d/%m/%Y")}<br/>
            <b>Elaborado por:</b> {self.current_user['username']}<br/>
            """
            story.append(Paragraph(info_text, styles['Normal']))
            story.append(Paragraph("<br/><br/>", styles['Normal']))
            
            # Captura del canvas como imagen
            self._save_canvas_as_temp_image()
            if hasattr(self, 'temp_image_path') and os.path.exists(self.temp_image_path):
                # Calcular tamaño para ajustar a la página (A4 Landscape = 29.7cm x 21cm)
                # Margenes default ~2.5cm, espacio util ~24cm x 16cm
                # Usamos un tamaño seguro de 24x15 cm máximo
                
                # Obtener ratio de la imagen
                with Image.open(self.temp_image_path) as pil_check:
                    iw, ih = pil_check.size
                
                ratio = iw / ih
                
                # Max dimensions available
                max_w = 24 * cm
                max_h = 14 * cm # Dejamos espacio para titulo y tabla
                
                # Calcular dimensiones finales
                if (max_w / max_h) > ratio:
                    # Limitado por altura
                    display_h = max_h
                    display_w = max_h * ratio
                else:
                    # Limitado por anchura
                    display_w = max_w
                    display_h = max_w / ratio
                
                img = RLImage(self.temp_image_path, width=display_w, height=display_h)
                story.append(img)
            
            story.append(PageBreak())
            
            # Tabla de elementos
            story.append(Paragraph("<b>Lista de Equipos</b>", styles['Heading2']))
            
            table_data = [['#', 'Tipo', 'Nombre', 'Modelo', 'Zona', 'Notas']]
            for i, el in enumerate(self.elements, 1):
                table_data.append([
                    str(i),
                    el['tipo'].upper(),
                    el.get('name', '-'),
                    el.get('model', '-'),
                    el.get('zone', '-'),
                    el.get('notes', '-')[:30]
                ])
            
            t = Table(table_data)
            t.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(t)
            
            # Resumen por categoría
            story.append(PageBreak())
            story.append(Paragraph("<b>Resumen por Categoría</b>", styles['Heading2']))
            
            cat_count = {}
            for el in self.elements:
                tipo = el['tipo']
                cat_count[tipo] = cat_count.get(tipo, 0) + 1
            
            summary_data = [['Categoría', 'Cantidad']]
            for cat, count in cat_count.items():
                summary_data.append([cat.upper(), str(count)])
            
            summary_table = Table(summary_data)
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1976d2')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 14),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.lightblue),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            story.append(summary_table)
            
            # Notas del proyecto
            if self.project_notes:
                story.append(Paragraph("<br/><br/>", styles['Normal']))
                story.append(Paragraph("<b>Notas del Proyecto:</b>", styles['Heading3']))
                story.append(Paragraph(self.project_notes, styles['Normal']))
            
            # Construir PDF
            doc.build(story)
            
            # Limpiar archivo temporal
            if hasattr(self, 'temp_image_path') and os.path.exists(self.temp_image_path):
                os.remove(self.temp_image_path)
            
            self.show_status(f"PDF generado: {os.path.basename(file)}", "green")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo generar el PDF:\n{e}")

    def _save_canvas_as_temp_image(self):
        """Guardar canvas como imagen temporal usando generador de alta resolución"""
        try:
            img = self._generate_high_res_image()
            if img:
                self.temp_image_path = "temp_canvas_export.png"
                img.save(self.temp_image_path)
        except Exception as e:
            print(f"Error capturando canvas: {e}")

    def _export_to_image(self):
        """Exportar canvas a PNG de alta calidad"""
        file = filedialog.asksaveasfilename(
            defaultextension=".png",
            filetypes=[("PNG", "*.png"), ("JPEG", "*.jpg")],
            initialfile=f"{self.project_name}_plano.png"
        )
        if not file:
            return
        
        try:
            img = self._generate_high_res_image()
            if img:
                img.save(file)
                self.show_status(f"Imagen guardada: {os.path.basename(file)}", "green")
            else:
                messagebox.showwarning("Exportar", "No hay imagen de plano para exportar.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo exportar imagen:\n{e}")

    def _draw_cone_on_image(self, draw, el):
        """Dibujar cono de cámara en imagen PIL"""
        cone = el['cone']
        cx, cy = el['x'], el['y']
        angle = cone['angle']
        length = cone['len']
        rotation = cone.get('rotation', 0)
        
        half = angle / 2.0
        p1 = (cx + length * math.cos(math.radians(rotation - half)),
              cy + length * math.sin(math.radians(rotation - half)))
        p2 = (cx + length * math.cos(math.radians(rotation + half)),
              cy + length * math.sin(math.radians(rotation + half)))
        
        draw.polygon([cx, cy, p1[0], p1[1], p2[0], p2[1]], 
                     fill=(135, 206, 235, 100), outline=(70, 130, 180))

    def _generate_report(self):
        """Generar reporte detallado en texto"""
        file = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Texto", "*.txt")],
            initialfile=f"{self.project_name}_reporte.txt"
        )
        if not file:
            return
        
        try:
            with open(file, "w", encoding="utf-8") as f:
                f.write("=" * 70 + "\n")
                f.write(f"REPORTE DE PROYECTO: {self.project_name}\n")
                f.write("=" * 70 + "\n\n")
                
                f.write(f"Cliente: {self.project_client}\n")
                f.write(f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}\n")
                f.write(f"Elaborado por: {self.current_user['username']}\n\n")
                
                if self.project_notes:
                    f.write(f"Notas:\n{self.project_notes}\n\n")
                
                f.write("-" * 70 + "\n")
                f.write("RESUMEN POR CATEGORÍA\n")
                f.write("-" * 70 + "\n")
                
                cat_count = {}
                for el in self.elements:
                    tipo = el['tipo']
                    cat_count[tipo] = cat_count.get(tipo, 0) + 1
                
                for cat, count in cat_count.items():
                    f.write(f"  {cat.upper()}: {count} elementos\n")
                
                f.write(f"\n  TOTAL: {len(self.elements)} elementos\n\n")
                
                f.write("-" * 70 + "\n")
                f.write("LISTADO DETALLADO DE ELEMENTOS\n")
                f.write("-" * 70 + "\n\n")
                
                for i, el in enumerate(self.elements, 1):
                    f.write(f"{i}. TIPO: {el['tipo'].upper()}\n")
                    f.write(f"   Nombre: {el.get('name', 'Sin nombre')}\n")
                    f.write(f"   Modelo: {el.get('model', '-')}\n")
                    f.write(f"   Zona: {el.get('zone', '-')}\n")
                    if el["tipo"] == "barrier":
                        f.write(f"   Punto A: ({int(el['start'][0])}, {int(el['start'][1])})\n")
                        f.write(f"   Punto B: ({int(el['end'][0])}, {int(el['end'][1])})\n")
                    else:
                        f.write(f"   Ubicación: ({int(el['x'])}, {int(el['y'])})\n")
                    if el.get('notes'):
                        f.write(f"   Notas: {el['notes']}\n")
                    f.write("\n")
            
            self.show_status(f"Reporte generado: {os.path.basename(file)}", "green")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo generar reporte:\n{e}")

    # ---------------------------
    # Icon picker and selection
    # ---------------------------
    def _open_icon_picker(self, category_folder):
        """Abrir selector de iconos"""
        # Obtener la ruta real (compatible con .exe y desarrollo)
        folder = get_resource_path(os.path.join("assets", "icons", category_folder))

        if not os.path.exists(folder):
            self.show_status(f"No existe carpeta: {category_folder}", "red")
            return
    
        picker = tk.Toplevel(self.win)
        picker.title(f"Iconos - {category_folder}")
        picker.geometry("600x450")
        picker.transient(self.win)
    
        # Frame con scroll
        canvas_picker = tk.Canvas(picker)
        scrollbar = tk.Scrollbar(picker, orient="vertical", command=canvas_picker.yview)
        scrollable_frame = tk.Frame(canvas_picker)
    
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas_picker.configure(scrollregion=canvas_picker.bbox("all"))
        )
    
        canvas_picker.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas_picker.configure(yscrollcommand=scrollbar.set)
    
        canvas_picker.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
    
        row = 0
        col = 0
        
        # Special items
        if category_folder == "intrusion":
            btn = tk.Button(
                scrollable_frame,
                text="🚧 Barrera\nPerimetral",
                font=("Segoe UI", 9, "bold"),
                bg="#ffebee",
                width=15, height=5,
                command=lambda w=picker: [w.destroy(), self._toggle_barrier_tool()]
            )
            btn.grid(row=row, column=col, padx=8, pady=8)
            col += 1
            
        for fname in sorted(os.listdir(folder)):

            if not fname.lower().endswith((".png", ".jpg", ".jpeg", ".gif", ".bmp")):
                continue
        
            path = os.path.join(folder, fname)
            try:
                pil = Image.open(path).convert("RGBA").resize((64, 64), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(pil)
            except Exception:
                continue
        
            btn = tk.Button(
                scrollable_frame,
                image=photo,
                text=os.path.splitext(fname)[0],
                compound="top",
                width=90,
                height=100,
                command=lambda p=path, t=category_folder: self._select_icon(p, t, picker)
            )
            btn.image = photo
            btn.grid(row=row, column=col, padx=8, pady=8)
        
            col += 1
            if col >= 6:
                col = 0
                row += 1


    def _select_icon(self, path, tipo, picker_window=None):
        """Seleccionar icono para colocar"""
        self.current_icon_path = path
        self.current_icon_tipo = tipo
        self.placing_mode = True
        
        if picker_window:
            picker_window.destroy()
        
        messagebox.showinfo("Icono seleccionado",
            f"Seleccionado: {os.path.basename(path)}\n"
            "Haz clic en el plano para colocarlo.")

    # ---------------------------
    # Create element in canvas
    # ---------------------------
    def _create_element(self, path, tipo, x, y, from_import=False, cone_data=None,
                       name="", model="", zone="", notes=""):
        """Crear elemento en el canvas"""
        try:
            pil = Image.open(path)
            
            # --- AUTO-TRANSPARENCY HACK ---
            # Si el usuario pide que no tengan fondo, intentamos quitar el blanco
            if pil.mode != 'RGBA':
                pil = pil.convert('RGBA')
            
            data = pil.getdata()
            new_data = []
            for item in data:
                # Si el pixel es muy blanco (>240, >240, >240), hacerlo transparente
                if item[0] > 240 and item[1] > 240 and item[2] > 240:
                    new_data.append((255, 255, 255, 0))
                else:
                    new_data.append(item)
            pil.putdata(new_data)
            # -------------------------------

            pil = ImageOps.contain(pil, (48, 48))
            photo = ImageTk.PhotoImage(pil)
        except Exception as e:
            messagebox.showwarning("Icono", f"No se pudo cargar: {path}\n{e}")
            return None
        
        cid = self.canvas.create_image(x, y, image=photo)
        
        if not name:
            name = os.path.splitext(os.path.basename(path))[0]

        el = {
            "id": cid,
            "path": path,
            "tipo": tipo,
            "x": x,
            "y": y,
            "image_ref": photo,
            "_pil_original": pil, # Guardamos la versión con transparencia ya procesada
            "name": name,
            "model": model,
            "zone": zone,
            "notes": notes
        }
        
        # Añadir cono para cámaras y detectores volumétricos
        name_lower = name.lower()
        # Cámaras: deben tener "camara", "camera", "domo", "ptz", "bullet", "minidomo" en el nombre (o nombre de archivo)
        is_camera = (tipo == "cctv" and any(k in name_lower for k in ["camara", "cámara", "camera", "domo", "ptz", "bullet", "minidomo", "fija"]))
        # Detectores: volumétrico, pir, doble tecnología
        is_detector = ("volumetrico" in name_lower or "volumétrico" in name_lower or "pir" in name_lower)

        needs_cone = is_camera or is_detector
        
        if needs_cone:
            angle = 60
            length = 200
            rotation = 0
            if cone_data:
                angle = cone_data.get("angle", angle)
                length = cone_data.get("len", length)
                rotation = cone_data.get("rotation", rotation)
            
            cone_id = self._draw_cone_at(x, y, angle, length, rotation)
            if cone_id.get("poly"):
                 self.canvas.tag_lower(cone_id["poly"], cid)
            el["cone"] = {"id": cone_id, "angle": angle, "len": length, "rotation": rotation}
        else:
            el["cone"] = None
        
        # Bindings
        self.canvas.tag_bind(cid, "<Button-1>", self._on_element_click)
        self.canvas.tag_bind(cid, "<B1-Motion>", self._on_element_move)
        self.canvas.tag_bind(cid, "<ButtonRelease-1>", self._on_element_release)
        
        self.elements.append(el)
        self._update_element_list()
        
        if not from_import:
            self._select_element(el)
            self._save_state()
        
        return el

    def _add_label(self):
        """Añadir etiqueta de texto"""
        text = simpledialog.askstring("Etiqueta", "Texto de la etiqueta:")
        if not text: return
        
        # Center of view
        x = self.canvas.canvasx(self.canvas.winfo_width()/2)
        y = self.canvas.canvasy(self.canvas.winfo_height()/2)
        
        lid = self.canvas.create_text(x, y, text=text, fill="black", font=("Arial", 12, "bold"))
        
        self.canvas.tag_bind(lid, "<Button-1>", self._on_label_click)
        self.canvas.tag_bind(lid, "<B1-Motion>", self._on_label_drag)
        self.canvas.tag_bind(lid, "<ButtonRelease-1>", self._on_label_release)
        
        self.labels.append({"id": lid, "text": text, "x": x, "y": y, "tipo": "label"})

    def _toggle_barrier_tool(self):
        """Activar herramienta de barrera perimetral"""
        self.drawing_barrier = not self.drawing_barrier
        self.barrier_step = 0
        self.barrier_start = None
        self.canvas.delete("temp_barrier")
        
        if self.drawing_barrier:
            self.placing_mode = False
            self.measuring = False
            self.drawing_wall = False
            self.win.config(cursor="crosshair")
            self.show_status("Barrera: 1. Clic Emisor -> 2. Clic Receptor", "blue")
        else:
            self.win.config(cursor="")
            self.show_status("Herramienta Barrera desactivada.")

    def _create_barrier(self, start, end, from_import=False, name="", model=""):
        """Crear elemento barrera (Emisor + Receptor + Línea)"""
        x1, y1 = start
        x2, y2 = end
        
        # Dibujar línea
        line_id = self.canvas.create_line(x1, y1, x2, y2, fill="red", width=3, dash=(5, 2))
        
        # Iconos (Generados programáticamente si no hay imagen)
        icon_em = self._get_barrier_icon("E")
        icon_rec = self._get_barrier_icon("R")
        
        cid1 = self.canvas.create_image(x1, y1, image=icon_em)
        cid2 = self.canvas.create_image(x2, y2, image=icon_rec)
        
        if not name: name = "Barrera Perimetral"
        
        # Texto de distancia
        text_id = self.canvas.create_text((x1+x2)/2, (y1+y2)/2 - 15, text="", fill="red", font=("Arial", 9, "bold"))
        
        el = {
            "id": line_id,
            "parts": [line_id, cid1, cid2, text_id],
            "text_id": text_id,
            "tipo": "barrier",
            "start": start,
            "end": end,
            "x": (x1+x2)/2,
            "y": (y1+y2)/2,
            "name": name,
            "model": model,
            "zone": "",
            "notes": "",
            "image_ref_em": icon_em,
            "image_ref_rec": icon_rec
        }
        
        # Bindings para todas las partes
        for item_id in [line_id, cid1, cid2]:
            self.canvas.tag_bind(item_id, "<Button-1>", lambda e, elem=el: self._on_barrier_click(e, elem))
            self.canvas.tag_bind(item_id, "<B1-Motion>", lambda e, elem=el: self._on_barrier_drag(e, elem))
            
        self.elements.append(el)
        self._update_element_list()
        
        if not from_import:
            self._select_element(el)
            self._save_state()
        
        self._update_barrier_label(el)
        return el

    def _update_barrier_label(self, el):
        """Actualizar etiqueta de distancia de la barrera"""
        x1, y1 = el["start"]
        x2, y2 = el["end"]
        dist_px = math.sqrt((x2-x1)**2 + (y2-y1)**2)
        
        if self.pixels_per_meter:
            dist_m = dist_px / self.pixels_per_meter
            txt = f"{dist_m:.1f} m"
        else:
            txt = f"{int(dist_px)} px"
            
        self.canvas.itemconfig(el["text_id"], text=txt)
        # Centrar posición
        self.canvas.coords(el["text_id"], (x1+x2)/2, (y1+y2)/2 - 15)



    def _get_barrier_icon_pil(self, letter):
        """Generar icono moderno para barrera (Columna sensor) como PIL Image"""
        # 32x64 px para que parezca columna alta
        w, h = 32, 48
        img = Image.new("RGBA", (w, h), (0,0,0,0))
        draw = ImageDraw.Draw(img)
        
        # Cuerpo columna (Gris oscuro)
        draw.rounded_rectangle([4, 2, 28, 46], radius=4, fill="#424242", outline="black")
        
        # Lentes (Rojos)
        draw.ellipse([10, 8, 22, 20], fill="#f44336", outline="black") # Lente superior
        draw.ellipse([10, 28, 22, 40], fill="#f44336", outline="black") # Lente inferior
        
        try:
            font = ImageFont.truetype("arial.ttf", 10)
        except:
            font = ImageFont.load_default()
            
        # Dibujar letra E/R pequeña
        draw.text((12, 20), letter, fill="white", font=font)
        
        return img

    def _get_barrier_icon(self, letter):
        """Wrapper para Tkinter del icono PIL"""
        pil_img = self._get_barrier_icon_pil(letter)
        return ImageTk.PhotoImage(pil_img)

    def _generate_high_res_image(self):
        """Generar imagen compuesta de alta resolución (Mapa + Elementos)"""
        if not self.plan_pil:
            return None
            
        # 1. Base: Mapa
        img = self.plan_pil.copy()
        draw = ImageDraw.Draw(img)
        
        # 2. Capa: Paredes
        for wall in self.walls:
            # coords: (x1, y1, x2, y2)
            c = wall["coords"]
            draw.line(c, fill="gray", width=4) # Paredes en gris oscuro
            
        # 3. Capa: Elementos y Barreras
        for el in self.elements:
            # Barreras
            if el["tipo"] == "barrier":
                if self.layers_visible.get("intrusion", True):
                    x1, y1 = el["start"]
                    x2, y2 = el["end"]
                    
                    # Línea de barrera
                    draw.line([x1, y1, x2, y2], fill="red", width=2)
                    
                    # Iconos
                    icon_em = self._get_barrier_icon_pil("E")
                    icon_rec = self._get_barrier_icon_pil("R")
                    
                    # Centrar iconos (32x48) -> offset x=16, y=24
                    img.paste(icon_em, (int(x1-16), int(y1-24)), icon_em)
                    img.paste(icon_rec, (int(x2-16), int(y2-24)), icon_rec)
                    
                    # Etiqueta de distancia si existe (guardada en el nombre o calculada)
                    # Si no tiene nombre específico, poner distancia
                    txt = el.get('name')
                    if not txt:
                         # Calcular distancia pixels
                         d_px = math.sqrt((x2-x1)**2 + (y2-y1)**2)
                         # Si hay calibración, mostrar metros
                         if self.pixels_per_meter:
                             m = d_px / self.pixels_per_meter
                             txt = f"{m:.2f}m"
                    
                    if txt:
                        try:
                            font = ImageFont.truetype("arial.ttf", 12)
                        except:
                            font = ImageFont.load_default()
                        
                        # Dibujar texto en el centro de la linea
                        mx, my = (x1+x2)/2, (y1+y2)/2
                        draw.rectangle([mx-15, my-8, mx+15, my+8], fill="white", outline="black")
                        draw.text((mx-10, my-6), txt, fill="black", font=font)

            # Resto de elementos (Cámaras, Detectores, etc.)
            elif self.layers_visible.get(el['tipo'], True):
                try:
                    # Cargar icono original
                    if os.path.exists(el['path']):
                        icon = Image.open(el['path']).convert("RGBA")
                        icon = icon.resize((48, 48), Image.Resampling.LANCZOS)
                        
                        # Dibujar cono si es cámara
                        if el.get('cone') and el['tipo'] == 'cctv':
                             self._draw_cone_on_image(draw, el)
                        
                        # Pegar icono (centrado aprox 48x48 -> offset 24,24 si x,y es centro? 
                        # En canvas x,y es TopLeft. Asumimos x,y es TopLeft del icono.
                        img.paste(icon, (int(el['x']), int(el['y'])), icon)
                        
                        # Etiqueta nombre
                        if el.get('name'):
                            try:
                                font = ImageFont.truetype("arial.ttf", 11)
                            except:
                                font = ImageFont.load_default()
                            draw.text((int(el['x']), int(el['y']) - 12), 
                                     el['name'], fill="black", font=font, stroke_width=2, stroke_fill="white")
                except Exception as e:
                    print(f"Error drawing element {el}: {e}")
                    
        # 4. Auto Leyenda
        if hasattr(self, 'legend_var') and self.legend_var.get() and len(self.elements) > 0:
            try:
                font = ImageFont.truetype("arial.ttf", 14)
                font_title = ImageFont.truetype("arialbd.ttf", 16)
            except:
                font = ImageFont.load_default()
                font_title = ImageFont.load_default()
                
            unique_types = {}
            for el in self.elements:
                if el.get('tipo', '') not in unique_types and 'path' in el and os.path.exists(el['path']):
                    unique_types[el['tipo']] = el['path']
                    
            if unique_types:
                # Calcular tamaño
                legend_w = 200
                legend_h = 40 + len(unique_types) * 40
                
                # Coordenadas (Esquina inferior derecha, con padding)
                img_w, img_h = img.size
                lx = img_w - legend_w - 30
                ly = img_h - legend_h - 30
                
                if lx > 0 and ly > 0:
                    draw.rectangle([lx, ly, lx+legend_w, ly+legend_h], fill=(255,255,255,230), outline="black", width=2)
                    draw.text((lx+10, ly+10), "LEYENDA", fill="black", font=font_title)
                    
                    curr_y = ly + 40
                    for tipo, path in unique_types.items():
                        try:
                            icon = Image.open(path).convert("RGBA")
                            icon = icon.resize((24, 24), Image.Resampling.LANCZOS)
                            img.paste(icon, (lx+15, curr_y), icon)
                            draw.text((lx+50, curr_y + 4), tipo.upper(), fill="black", font=font)
                        except: pass
                        curr_y += 40
                        
        return img

    def _on_barrier_click(self, event, el):
        self._select_element(el)
        el["_drag_start"] = (self.canvas.canvasx(event.x), self.canvas.canvasy(event.y))

    def _on_barrier_drag(self, event, el):
        # Mover todo el conjunto
        start_drag = el.get("_drag_start")
        if not start_drag: return
        
        cx, cy = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        dx = cx - start_drag[0]
        dy = cy - start_drag[1]
        
        for part_id in el["parts"]:
            self.canvas.move(part_id, dx, dy)
            
        # Actualizar datos lógicos
        el["start"] = (el["start"][0] + dx, el["start"][1] + dy)
        el["end"] = (el["end"][0] + dx, el["end"][1] + dy)
        el["x"] += dx
        el["y"] += dy
        
        el["_drag_start"] = (cx, cy)

    # ---------------------------
    # Canvas events
    # ---------------------------
    def _canvas_click(self, event):
        """Click en canvas"""
        if self.calibrating:
            self._calibrate_click(event)
            return

        if self.placing_mode and self.current_icon_path:
            x = self.canvas.canvasx(event.x)
            y = self.canvas.canvasy(event.y)
            x = self._snap(x)
            y = self._snap(y)
            self._create_element(self.current_icon_path, self.current_icon_tipo, x, y)
            self.placing_mode = False
            self.current_icon_path = None
            self.current_icon_tipo = None
            return
        
        # --- Barrier Tool Logic ---
        if self.drawing_barrier:
            x = self.canvas.canvasx(event.x)
            y = self.canvas.canvasy(event.y)
            
            if self.barrier_step == 0:
                self.barrier_start = (x, y)
                self.barrier_step = 1
                # Visual feedback
                self.canvas.create_oval(x-5, y-5, x+5, y+5, fill="red", outline="white", tags="temp_barrier")
                messagebox.showinfo("Barrera", "Punto inicial marcado. Ahora haga clic en el punto final (Receptor).")
            elif self.barrier_step == 1:
                self.canvas.delete("temp_barrier")
                self.canvas.delete("temp_barrier_line")
                self.canvas.delete("temp_barrier_text")
                start = self.barrier_start
                end = (x, y)
                self._create_barrier(start, end)
                self.drawing_barrier = False
                self.barrier_step = 0
                self.barrier_start = None
                self.win.config(cursor="")
            return
        # --------------------------
        
        if self.measuring:
            self._measure_click(event)
            return
        
        if self.drawing_wall:
            return
        
        # Selección de elemento
        clicked = self.canvas.find_closest(self.canvas.canvasx(event.x), 
                                          self.canvas.canvasy(event.y))
        if clicked:
            cid = clicked[0]
            el = self._get_element_by_cid(cid)
            if el:
                if self.ctrl_pressed:
                    # Selección múltiple
                    if el in self.selected_elements:
                        self.selected_elements.remove(el)
                    else:
                        self.selected_elements.append(el)
                else:
                    self.selected_elements = []
                    self._select_element(el)
                
                el["_drag_start"] = (self.canvas.canvasx(event.x), 
                                    self.canvas.canvasy(event.y))
                return
        
        self._select_element(None)

    def _on_element_click(self, event):
        """Click en elemento"""
        cid = self.canvas.find_closest(self.canvas.canvasx(event.x), 
                                       self.canvas.canvasy(event.y))[0]
        el = self._get_element_by_cid(cid)
        if el:
            self._select_element(el)
            el["_drag_start"] = (self.canvas.canvasx(event.x), 
                                self.canvas.canvasy(event.y))
            
            if self.shift_pressed and el.get("cone"):
                el["_rotating"] = True
            else:
                el["_rotating"] = False

    def _on_element_move(self, event):
        """Mover elemento (o rotar si Shift presionado)"""
        cid = self.canvas.find_closest(self.canvas.canvasx(event.x), 
                                       self.canvas.canvasy(event.y))[0]
        el = self._get_element_by_cid(cid)
        if not el:
            return
        
        # Modo ROTACIÓN (Shift presionado)
        if self.shift_pressed and el.get("cone"):
            cx, cy = el["x"], el["y"]
            mx, my = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
            angle = math.degrees(math.atan2(my - cy, mx - cx))
            
            el["cone"]["rotation"] = angle
            self._redraw_cone(el)
            
            # Actualizar panel si es el seleccionado
            if self.selected_el == el:
                try:
                    self.entry_rotation.delete(0, "end")
                    self.entry_rotation.insert(0, str(int(angle % 360)))
                except: pass
            return

        # Modo ARRASTRE
        start = el.get("_drag_start")
        if not start:
            return
        
        sx, sy = start
        mx, my = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
        dx = mx - sx
        dy = my - sy
        
        self.canvas.move(el["id"], dx, dy)
        if el.get("cone") and el["cone"].get("id"):
            cid_cone = el["cone"]["id"]
            if isinstance(cid_cone, dict):
                # Mover polígono y controles
                self.canvas.move(cid_cone["poly"], dx, dy)
                self.canvas.move(cid_cone.get("ctrl_rot"), dx, dy)
                self.canvas.move(cid_cone.get("ctrl_len"), dx, dy)
            else:
                self.canvas.move(cid_cone, dx, dy)
        
        el["x"] += dx
        el["y"] += dy
        el["_drag_start"] = (mx, my)
        self._select_element(el)

    def _on_element_release(self, event):
        """Soltar elemento"""
        cid = self.canvas.find_closest(self.canvas.canvasx(event.x), 
                                       self.canvas.canvasy(event.y))[0]
        el = self._get_element_by_cid(cid)
        if not el:
            return
        
        el.pop("_drag_start", None)
        el.pop("_rotating", None)
        
        # Snap al soltar elemento
        if hasattr(self, 'snap_var') and self.snap_var.get():
            target_x = self._snap(el["x"])
            target_y = self._snap(el["y"])
            dx = target_x - el["x"]
            dy = target_y - el["y"]
            
            if dx != 0 or dy != 0:
                self.canvas.move(el["id"], dx, dy)
                if el.get("cone") and el["cone"].get("id"):
                    cid_cone = el["cone"]["id"]
                    if isinstance(cid_cone, dict):
                        self.canvas.move(cid_cone["poly"], dx, dy)
                        self.canvas.move(cid_cone.get("ctrl_rot"), dx, dy)
                        self.canvas.move(cid_cone.get("ctrl_len"), dx, dy)
                    else:
                        self.canvas.move(cid_cone, dx, dy)
                el["x"] = target_x
                el["y"] = target_y
        
        self._save_state()

    def _snap(self, val):
        if hasattr(self, 'snap_var') and self.snap_var.get():
            return round(val / self.grid_size) * self.grid_size
        return val

    def _on_drag_motion(self, event):
        """Movimiento con arrastre (para pan)"""
        if self.space_pressed:
            dx = event.x - getattr(self, "pan_last_x", event.x)
            dy = event.y - getattr(self, "pan_last_y", event.y)
            self.canvas.move("all", dx, dy)
            self.pan_last_x = event.x
            self.pan_last_y = event.y

    def _on_button_release(self, event):
        """Soltar botón"""
        self.pan_last_x = None
        self.pan_last_y = None

    def _on_mouse_move(self, event):
        """Movimiento del mouse (para preview)"""
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        if self.drawing_barrier and self.barrier_step == 1 and self.barrier_start:
             self.canvas.delete("temp_barrier_line")
             self.canvas.delete("temp_barrier_text")
             
             x1, y1 = self.barrier_start
             self.canvas.create_line(x1, y1, x, y, fill="red", dash=(4, 4), tags="temp_barrier_line")
             
             dist = math.sqrt((x-x1)**2 + (y-y1)**2)
             if self.pixels_per_meter:
                 txt = f"{dist/self.pixels_per_meter:.2f} m"
             else:
                 txt = f"{int(dist)} px"
             
             self.canvas.create_text((x1+x)/2, (y1+y)/2 - 15, text=txt, fill="red", 
                                     font=("Arial", 9, "bold"), tags="temp_barrier_text")


    # ---------------------------
    # Pan
    # ---------------------------
    def _pan_start(self, event):
        self.pan_active = True
        self.pan_start = (event.x, event.y)

    def _pan_move(self, event):
        if not self.pan_active:
            return
        dx = event.x - self.pan_start[0]
        dy = event.y - self.pan_start[1]
        self.canvas.move("all", dx, dy)
        self.pan_start = (event.x, event.y)

    def _pan_end(self, event):
        self.pan_active = False

    # ---------------------------
    # Zoom
    # ---------------------------
    def _on_mousewheel(self, event):
        # Determine direction (Windows usually +-120, others scale differently)
        if event.num == 5 or event.delta < 0:
            direction = -1
        else:
            direction = 1

        factor = 1.1 if direction > 0 else 0.9
        
        # Limit zoom
        new_scale = self.scale * factor
        if new_scale < 0.1 or new_scale > 10.0:
            return "break"

        self.scale = new_scale
        
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        # 1. Scale coordinates (Vectors, Polygons, and Image Anchors)
        self.canvas.scale("all", x, y, factor, factor)
        
        # 2. Resize Background Image
        self._update_images_zoom()
        
        return "break" # Prevent default scrolling

    def _update_images_zoom(self):
        """Redimensionar todas las imágenes según zoom actual"""
        # Background
        if self.plan_pil:
            # Usar Bilinear para rapidez
            w = int(self.plan_pil.width * self.scale)
            h = int(self.plan_pil.height * self.scale)
            if w > 1 and h > 1:
                resized = self.plan_pil.resize((w, h), Image.Resampling.BILINEAR)
                self.plan_image = ImageTk.PhotoImage(resized)
                self.canvas.itemconfig(self.plan_canvas_id, image=self.plan_image)

        # Icons
        for el in self.elements:
            try:
                # Default icon size 48x48
                target_size = int(48 * self.scale)
                if target_size < 16: target_size = 16
                
                # Cargar original si no está cacheado para evitar degradación
                # (Idealmente cachear PIL original en el elemento)
                if "_pil_original" not in el:
                    el["_pil_original"] = Image.open(el["path"])
                
                pil_icon = el["_pil_original"]
                if pil_icon:
                    resized_icon = pil_icon.resize((target_size, target_size), Image.Resampling.BILINEAR)
                    photo = ImageTk.PhotoImage(resized_icon)
                    el["image_ref"] = photo # Keep ref
                    self.canvas.itemconfig(el["id"], image=photo)
            except Exception as e:
                # print(f"Zoom icon error: {e}")
                pass

    # ---------------------------
    # Context menu
    # ---------------------------
    def _on_right_click(self, event):
        """Menú contextual"""
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        clicked = self.canvas.find_closest(x, y)
        
        if not clicked:
            return
        
        cid = clicked[0]
        el = self._get_element_by_cid(cid)
        if not el:
            return
        
        self._select_element(el)
        
        menu = tk.Menu(self.win, tearoff=0)
        menu.add_command(label="✏️ Editar propiedades", 
                        command=lambda: self._select_element(el))
        menu.add_command(label="📋 Duplicar", command=self._duplicate_selected)
        menu.add_separator()
        if el.get("cone"):
            menu.add_command(label="🎥 Editar cono", command=self._open_cone_editor)
        menu.add_separator()
        menu.add_command(label="🗑️ Eliminar", command=self._delete_selected)
        
        menu.post(event.x_root, event.y_root)

    # ---------------------------
    # Element helpers
    # ---------------------------
    def _get_element_by_cid(self, cid):
        for el in self.elements:
            if el["id"] == cid:
                return el
        return None

    def _select_element(self, el):
        """Seleccionar elemento y actualizar panel de propiedades"""
        self.selected_el = el
        
        if el is None:
            self.prop_name.config(text="Elemento: -")
            self.prop_tipo.config(text="Tipo: -")
            self.prop_coords.config(text="Coords: -")
            self.entry_name.delete(0, "end")
            self.entry_model.delete(0, "end")
            self.entry_zone.delete(0, "end")
            self.entry_notes.delete("1.0", "end")
            self.entry_angle.delete(0, "end")
            self.entry_angle.insert(0, "60")
            self.entry_len.delete(0, "end")
            self.entry_len.insert(0, "200")
            self.entry_rotation.delete(0, "end")
            self.entry_rotation.insert(0, "0")
            return
        
        self.prop_name.config(text=f"Elemento: {el.get('name', 'Sin nombre')}")
        self.prop_tipo.config(text=f"Tipo: {el['tipo'].upper()}")
        self.prop_coords.config(text=f"Coords: ({int(el['x'])}, {int(el['y'])})")
        
        self.entry_name.delete(0, "end")
        self.entry_name.insert(0, el.get('name', ''))
        
        self.entry_model.delete(0, "end")
        self.entry_model.insert(0, el.get('model', ''))
        
        self.entry_zone.delete(0, "end")
        self.entry_zone.insert(0, el.get('zone', ''))
        
        self.entry_notes.delete("1.0", "end")
        self.entry_notes.insert("1.0", el.get('notes', ''))
        
        if el.get("cone"):
            self.entry_angle.delete(0, "end")
            self.entry_angle.insert(0, str(int(el["cone"]["angle"])))
            self.entry_len.delete(0, "end")
            self.entry_len.insert(0, str(int(el["cone"]["len"])))
            self.entry_rotation.delete(0, "end")
            self.entry_rotation.insert(0, str(int(el["cone"]["rotation"])))
        else:
            self.entry_angle.delete(0, "end")
            self.entry_angle.insert(0, "60")
            self.entry_len.delete(0, "end")
            self.entry_len.insert(0, "200")
            self.entry_rotation.delete(0, "end")
            self.entry_rotation.insert(0, "0")

    def _delete_selected(self):
        """Eliminar elemento seleccionado"""
        el = self.selected_el
        if not el:
            self.show_status("Eliminar: No hay elemento seleccionado.", "orange")
            return
        
        if el.get("cone"):
            try:
                self.canvas.delete(el["cone"]["id"])
            except:
                pass
        
        try:
            self.canvas.delete(el["id"])
        except:
            pass
        
        try:
            self.elements.remove(el)
        except:
            pass
        
        self._select_element(None)
        self._update_element_list()
        self._save_state()

    def _duplicate_selected(self):
        if self.selected_el:
            self._copy_element()
            self._paste_element()

    def _copy_element(self):
        if self.selected_el:
            self.clipboard_el = self.selected_el
            self.show_status(f"Copiado: {self.clipboard_el.get('name', 'Elemento')}")

    def _paste_element(self):
        if hasattr(self, 'clipboard_el') and self.clipboard_el:
            el = self.clipboard_el
            offset = 20
            new_el = self._create_element(
                el['path'], el['tipo'], 
                el['x'] + offset, el['y'] + offset,
                cone_data=el.get('cone'),
                name=el.get('name', '') + " (copia)",
                model=el.get('model', ''),
                zone=el.get('zone', ''),
                notes=el.get('notes', '')
            )
            self.clipboard_el = new_el
            self._save_state()
            self.show_status("Elemento pegado.")

    def _apply_properties(self):
        """Aplicar cambios de propiedades"""
        el = self.selected_el
        if not el:
            self.show_status("Propiedades: No hay elemento seleccionado.", "orange")
            return
        
        el['name'] = self.entry_name.get()
        el['model'] = self.entry_model.get()
        el['zone'] = self.entry_zone.get()
        el['notes'] = self.entry_notes.get("1.0", "end-1c")
        
        if el.get('cone'):
            try:
                angle = float(self.entry_angle.get())
                length = float(self.entry_len.get())
                rotation = float(self.entry_rotation.get())
                el['cone']['angle'] = angle
                el['cone']['len'] = length
                el['cone']['rotation'] = rotation
                self._redraw_cone(el)
            except:
                messagebox.showerror("Error", "Valores de cono inválidos.")
                return
        
        self._update_element_list()
        self._save_state()
        messagebox.showinfo("Propiedades", "Cambios aplicados correctamente.")

    def _quick_rotate(self, angle):
        """Rotación rápida del cono a ángulos cardinales"""
        el = self.selected_el
        if not el or not el.get('cone'):
            messagebox.showwarning("Rotar", "Seleccione un elemento con cono de visión.")
            return
        
        el['cone']['rotation'] = angle
        self.entry_rotation.delete(0, "end")
        self.entry_rotation.insert(0, str(angle))
        self._redraw_cone(el)
        self._save_state()

    # ---------------------------
    # Cones & FOV Logic
    # ---------------------------
    def _get_line_intersection(self, p0_x, p0_y, p1_x, p1_y, p2_x, p2_y, p3_x, p3_y):
        """Calcula intersección entre segmento p0-p1 y p2-p3. Retorna (x,y) o None."""
        s1_x = p1_x - p0_x
        s1_y = p1_y - p0_y
        s2_x = p3_x - p2_x
        s2_y = p3_y - p2_y

        d = (-s2_x * s1_y + s1_x * s2_y)
        if abs(d) < 1e-9: return None # Paralelas

        s = (-s1_y * (p0_x - p2_x) + s1_x * (p0_y - p2_y)) / d
        t = ( s2_x * (p0_y - p2_y) - s2_y * (p0_x - p2_x)) / d

        if 0 <= s <= 1 and 0 <= t <= 1:
            return (p0_x + (t * s1_x), p0_y + (t * s1_y))
        return None

    def _calculate_fov_polygon(self, cx, cy, angle, radius, rotation):
        """Calcula polígono de visión usando raycasting contra paredes."""
        try:
            walls = [w["coords"] for w in self.walls]
            points = [cx, cy]
            
            start_angle = rotation - (angle / 2)
            steps = 40 # Resolución del arco/sombras
            step_size = angle / steps
            
            for i in range(steps + 1):
                curr_angle_deg = start_angle + (i * step_size)
                rad = math.radians(curr_angle_deg)
                dx = math.cos(rad)
                dy = math.sin(rad)
                
                # Punto final ideal
                px = cx + dx * radius
                py = cy + dy * radius
                
                closest_dist_sq = radius * radius
                hit_point = (px, py)
                
                # Check colisiones con paredes
                for wx1, wy1, wx2, wy2 in walls:
                    inter = self._get_line_intersection(cx, cy, px, py, wx1, wy1, wx2, wy2)
                    if inter:
                        dist_sq = (inter[0]-cx)**2 + (inter[1]-cy)**2
                        if dist_sq < closest_dist_sq:
                            closest_dist_sq = dist_sq
                            hit_point = inter
                
                points.extend([hit_point[0], hit_point[1]])
                
            return points
        except Exception as e:
            print(f"ERROR calculating FOV: {e}")
            return [cx, cy, cx+radius, cy, cx, cy+radius] # Fallback triangle

    def _draw_cone_at(self, cx, cy, angle, length, rotation=0):
        """Dibujar cono de visión con controles de rotación y longitud"""
        try:
            # print(f"DEBUG: Drawing cone at {cx},{cy}")
            angle = float(angle)
            length = float(length)
            rotation = float(rotation)

            
            half = angle / 2.0
            rad_rot = math.radians(rotation)
            
            # Calcular los puntos del cono (FOV con raycasting)
            poly_points = self._calculate_fov_polygon(cx, cy, angle, length, rotation)
            
            # 1. Dibujar el polígono (cono visual) semi-transparente
            # stipple="gray25" simula transparencia en Tkinter estándar
            poly = self.canvas.create_polygon(
                *poly_points,
                fill="#81d4fa", stipple="gray25", outline="#0288d1", width=2,
                tags="cone"
            )
            
            # Calcular puntos de control
            # Centro del arco (Rotación)
            rot_x = cx + (length * 0.8) * math.cos(rad_rot)
            rot_y = cy + (length * 0.8) * math.sin(rad_rot)
            
            # Punta central (Longitud)
            tip_x = cx + length * math.cos(rad_rot)
            tip_y = cy + length * math.sin(rad_rot)

            # 2. Control de Rotación (Círculo Rojo)
            ctrl_rot = self.canvas.create_oval(
                rot_x - 6, rot_y - 6, rot_x + 6, rot_y + 6,
                fill="#ff5252", outline="#b71c1c", width=1,
                tags="cone_control_rot"
            )
            
            # 3. Control de Longitud (Cuadrado Azul)
            ctrl_len = self.canvas.create_rectangle(
                tip_x - 6, tip_y - 6, tip_x + 6, tip_y + 6,
                fill="#448aff", outline="#1565c0", width=1,
                tags="cone_control_len"
            )
            
            # Bindings para Rotación
            self.canvas.tag_bind(ctrl_rot, "<Button-1>", lambda e: self._start_interact(e, "rotate"))
            self.canvas.tag_bind(ctrl_rot, "<B1-Motion>", lambda e: self._interact_cone(e, "rotate"))
            self.canvas.tag_bind(ctrl_rot, "<ButtonRelease-1>", self._end_interact)
            self.canvas.tag_bind(ctrl_rot, "<Enter>", lambda e: self.canvas.config(cursor="exchange"))
            self.canvas.tag_bind(ctrl_rot, "<Leave>", lambda e: self.canvas.config(cursor=""))

            # Bindings para Longitud
            self.canvas.tag_bind(ctrl_len, "<Button-1>", lambda e: self._start_interact(e, "resize"))
            self.canvas.tag_bind(ctrl_len, "<B1-Motion>", lambda e: self._interact_cone(e, "resize"))
            self.canvas.tag_bind(ctrl_len, "<ButtonRelease-1>", self._end_interact)
            self.canvas.tag_bind(ctrl_len, "<Enter>", lambda e: self.canvas.config(cursor="sizing"))
            self.canvas.tag_bind(ctrl_len, "<Leave>", lambda e: self.canvas.config(cursor=""))
            
            return {"poly": poly, "ctrl_rot": ctrl_rot, "ctrl_len": ctrl_len, "cx": cx, "cy": cy}
            
        except Exception as e:
            print(f"Error en _draw_cone_at: {e}")
            return {"poly": None, "ctrl_rot": None, "ctrl_len": None}

    # ---------------------------
    # Cone Interaction
    # ---------------------------
    def _start_interact(self, event, mode):
        """Iniciar interacción con control de cono"""
        self.interacting_mode = mode
        # Buscar el punto de control bajo el cursor
        closest = self.canvas.find_closest(self.canvas.canvasx(event.x), self.canvas.canvasy(event.y))[0]
        
        target_el = None
        for el in self.elements:
            if not el.get("cone"): continue
            cid = el["cone"]["id"]
            if isinstance(cid, dict):
                # Verificar ambos controles
                if cid.get("ctrl_rot") == closest or cid.get("ctrl_len") == closest:
                    target_el = el
                    break
        
        self.interacting_el = target_el
        if target_el:
            self._select_element(target_el)

    def _interact_cone(self, event, mode):
        """Mover control de cono (rotación o longitud)"""
        if not getattr(self, "interacting_el", None):
            return

        el = self.interacting_el
        cx, cy = el["x"], el["y"]
        mx = self.canvas.canvasx(event.x)
        my = self.canvas.canvasy(event.y)
        
        dx = mx - cx
        dy = my - cy
        
        angle = math.degrees(math.atan2(dy, dx))
        
        if mode == "rotate":
            el["cone"]["rotation"] = angle
            try:
                self.entry_rotation.delete(0, "end")
                self.entry_rotation.insert(0, str(int(angle % 360)))
            except: pass
            
        elif mode == "resize":
            dist = math.sqrt(dx*dx + dy*dy)
            dist = max(20, min(2000, dist))
            el["cone"]["len"] = dist
            # Update angle also for natural movement
            el["cone"]["rotation"] = angle
            
            try:
                self.entry_len.delete(0, "end")
                self.entry_len.insert(0, str(int(dist)))
                self.entry_rotation.delete(0, "end")
                self.entry_rotation.insert(0, str(int(angle % 360)))
            except: pass

        # USAR UPDATE en lugar de REDRAW para evitar parpadeos y desconexiones
        self._update_cone_visuals(el)

    def _update_cone_visuals(self, el):
        """Actualizar coordenadas del cono sin destruirlo"""
        if not el.get("cone"): return
        cone = el["cone"]
        cid = cone["id"]
        
        if not isinstance(cid, dict) or not cid.get("poly"):
            # Fallback a redraw si algo está mal
            self._redraw_cone(el)
            return

        cx, cy = el["x"], el["y"]
        length = cone["len"]
        rotation = cone.get("rotation", 0)
        angle = cone["angle"]
        
        half = angle / 2.0
        rad_rot = math.radians(rotation)
        
        # Nuevos puntos polígono
        # Nuevos puntos polígono (FOV con raycasting)
        poly_points = self._calculate_fov_polygon(cx, cy, angle, length, rotation)
        self.canvas.coords(cid["poly"], *poly_points)
        
        # Nuevos puntos controles
        rot_x = cx + (length * 0.8) * math.cos(rad_rot)
        rot_y = cy + (length * 0.8) * math.sin(rad_rot)
        self.canvas.coords(cid["ctrl_rot"], rot_x - 6, rot_y - 6, rot_x + 6, rot_y + 6)
        
        tip_x = cx + length * math.cos(rad_rot)
        tip_y = cy + length * math.sin(rad_rot)
        self.canvas.coords(cid["ctrl_len"], tip_x - 6, tip_y - 6, tip_x + 6, tip_y + 6)

    def _end_interact(self, event):
        self.interacting_mode = None
        self.interacting_el = None
        self._save_state()

    def _start_rotate_cone(self, event, control_point):
        """Iniciar rotación del cono"""
        # Encontrar el elemento asociado a este punto de control
        for el in self.elements:
            if el.get("cone") and el["cone"]["id"].get("control") == control_point:
                self.rotating_element = el
                self._select_element(el)
                break

    def _rotate_cone_by_control(self, event, control_point):
        """Rotar cono arrastrando el punto de control"""
        if not hasattr(self, 'rotating_element') or not self.rotating_element:
            return
        
        el = self.rotating_element
        if not el.get("cone"):
            return
        
        # Obtener posición del vértice (punto fijo)
        cx, cy = el["x"], el["y"]
        
        # Obtener posición del mouse
        mx = self.canvas.canvasx(event.x)
        my = self.canvas.canvasy(event.y)
        
        # Calcular ángulo desde el vértice hacia el mouse
        angle = math.degrees(math.atan2(my - cy, mx - cx))
        
        # Actualizar rotación del cono
        el["cone"]["rotation"] = angle
        
        # Redibujar cono con nueva rotación
        self._redraw_cone(el)
        
        # Actualizar campo de rotación en propiedades
        self.entry_rotation.delete(0, "end")
        self.entry_rotation.insert(0, str(int(angle)))

    def _end_rotate_cone(self, event):
        """Finalizar rotación del cono"""
        if hasattr(self, 'rotating_element'):
            self._save_state()
            self.rotating_element = None

    def _redraw_cone(self, el):
        """Redibujar cono de elemento manteniendo el vértice fijo"""
        if not el.get("cone"):
            return
        
        cone = el["cone"]
        
        # Eliminar cono y controles anteriores
        try:
            if isinstance(cone["id"], dict):
                self.canvas.delete(cone["id"]["poly"])
                self.canvas.delete(cone["id"].get("ctrl_rot"))
                self.canvas.delete(cone["id"].get("ctrl_len"))
            else:
                self.canvas.delete(cone["id"])
        except:
            pass
        
        # El vértice siempre está en la posición del elemento (cx, cy)
        cx, cy = el["x"], el["y"]
        new_cone = self._draw_cone_at(cx, cy, cone["angle"], 
                                      cone["len"], cone.get("rotation", 0))
        
        if new_cone.get("poly"):
            cone["id"] = new_cone
            # Asegurar que el cono esté detrás del icono pero los controles visibles
            try:
                self.canvas.tag_lower(new_cone["poly"], el["id"])
            except:
                self.canvas.tag_lower(new_cone["poly"]) # Fallback
                
            self.canvas.tag_raise(new_cone["ctrl_rot"])
            self.canvas.tag_raise(new_cone["ctrl_len"])
        else:
            print("Fallo al redibujar cono, manteniendo estado anterior si existe")

    def _open_cone_editor(self):
        """Editor de cono de cámara/detector"""
        el = self.selected_el
        if not el or not el.get("cone"):
            messagebox.showwarning("Editar cono", 
                "Seleccione una cámara o detector volumétrico.")
            return
        
        # Mostrar info sobre controles
        info = (
            "CONTROLES DEL CONO:\n\n"
            "🔴 PUNTO ROJO: Arrastra el punto rojo para rotar el cono\n"
            "   en cualquier dirección. El vértice permanece fijo.\n\n"
            "📊 PANEL: Ajusta ángulo, longitud y rotación precisa\n\n"
            "⌨️ BOTONES: Rotación rápida a direcciones cardinales\n\n"
            "El vértice del cono siempre permanece en el icono."
        )
        messagebox.showinfo("Ayuda - Cono de Visión", info)

    # ---------------------------
    # Layers
    # ---------------------------
    def _toggle_layer(self, layer_name):
        """Alternar visibilidad de capa"""
        self.layers_visible[layer_name] = self.layer_vars[layer_name].get()
        self._redraw_all()

    # ---------------------------
    # Grid
    # ---------------------------
    def _toggle_grid(self):
        """Alternar grid"""
        self.show_grid = not self.show_grid
        if self.show_grid:
            self._draw_grid()
        else:
            self.canvas.delete("grid")

    def _draw_grid(self):
        """Dibujar grid en canvas"""
        self.canvas.delete("grid")
        
        if not self.plan_pil:
            return
        
        w, h = self.plan_pil.size
        
        # Líneas verticales
        for x in range(0, w, self.grid_size):
            self.canvas.create_line(x, 0, x, h, fill="gray", 
                                   dash=(2, 4), tags="grid")
        
        # Líneas horizontales
        for y in range(0, h, self.grid_size):
            self.canvas.create_line(0, y, w, y, fill="gray", 
                                   dash=(2, 4), tags="grid")
        
        self.canvas.lower("grid")

    # ---------------------------
    # Calibration
    # ---------------------------
    def _toggle_calibration(self):
        self.calibrating = not self.calibrating
        if self.calibrating:
            self.calibration_start = None
            self.measuring = False
            self.drawing_wall = False
            self.drawing_barrier = False
            self.drawing_barrier = False
            self.show_status("Calibración: Haga clic en dos puntos de una distancia conocida.", "blue")
            self.win.config(cursor="crosshair")
        else:
            self.win.config(cursor="")
            self.show_status("Calibración desactivada.")

    def _calibrate_click(self, event):
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        if self.calibration_start is None:
            self.calibration_start = (x, y)
        else:
            x1, y1 = self.calibration_start
            dist_px = math.sqrt((x - x1)**2 + (y - y1)**2)
            
            # Dibujar linea temporal
            line = self.canvas.create_line(x1, y1, x, y, fill="blue", width=2)
            
            real_m = simpledialog.askfloat("Calibrar", f"La distancia dibujada ({int(dist_px)} px) en METROS es:")
            self.canvas.delete(line)
            
            if real_m and real_m > 0:
                self.pixels_per_meter = dist_px / real_m
                self.show_status(f"Calibrado: 1 m = {self.pixels_per_meter:.2f} px", "green")
                # Actualizar todas las barreras existentes
                # Actualizar todas las barreras existentes
                for el in self.elements:
                    if el["tipo"] == "barrier":
                        self._update_barrier_label(el)
            
            self.calibrating = False
            self.calibration_start = None
            self.win.config(cursor="")

    # ---------------------------
    # Measurements
    # ---------------------------
    def _toggle_measure(self):
        """Alternar herramienta de medición"""
        self.measuring = not self.measuring
        if self.measuring:
            self.measure_start = None
        if self.measuring:
            self.measure_start = None
            self.show_status("Medición: Haga clic en dos puntos.", "blue")
        else:
            if self.measure_line:
                self.canvas.delete(self.measure_line)
            if self.measure_text:
                self.canvas.delete(self.measure_text)
            self.measure_line = None
            self.measure_text = None

    def _measure_click(self, event):
        """Click para medir"""
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        if self.measure_start is None:
            self.measure_start = (x, y)
            if self.measure_line:
                self.canvas.delete(self.measure_line)
            if self.measure_text:
                self.canvas.delete(self.measure_text)
        else:
            x1, y1 = self.measure_start
            distance = math.sqrt((x - x1)**2 + (y - y1)**2)
            
            # Dibujar línea
            self.measure_line = self.canvas.create_line(
                x1, y1, x, y, fill="red", width=2, arrow=tk.BOTH
            )
            
            # Dibujar texto con distancia
            mid_x = (x1 + x) / 2
            mid_y = (y1 + y) / 2
            
            if self.pixels_per_meter:
                dist_m = distance / self.pixels_per_meter
                txt = f"{dist_m:.2f} m"
            else:
                txt = f"{distance:.1f} px"
            
            self.measure_text = self.canvas.create_text(
                mid_x, mid_y - 10, 
                text=txt,
                fill="red", font=("Arial", 12, "bold")
            )
            
            self.measure_start = None
            
            self.measure_start = None
            self.show_status(f"Distancia medida: {txt}", "green")

    # ---------------------------
    # Walls
    # ---------------------------
    def _toggle_draw_wall(self):
        """Alternar modo dibujo de paredes"""
        self.drawing_wall = not self.drawing_wall
        
        if self.drawing_wall:
            self.show_status("Paredes: Click izquierdo para iniciar, Derecho para terminar, ESC para salir.", "blue")
            self.canvas.bind("<Button-1>", self._wall_click_start)
            self.canvas.bind("<Button-3>", self._wall_click_end)
            self.win.bind("<Escape>", lambda e: self._toggle_draw_wall())
        else:
            self.show_status("Dibujo de paredes desactivado.")
            self.canvas.bind("<Button-1>", self._canvas_click)
            self.canvas.unbind("<Button-3>")
            self.win.unbind("<Escape>")
            self.wall_start = None

    def _wall_click_start(self, event):
        """Iniciar punto de pared"""
        x = self.canvas.canvasx(event.x)
        y = self.canvas.canvasy(event.y)
        
        if self.wall_start is None:
            self.wall_start = (x, y)
        else:
            # Dibujar desde el último punto
            x1, y1 = self.wall_start
            line_id = self.canvas.create_line(
                x1, y1, x, y, 
                fill="gray20", width=4, tags="wall"
            )
            self.walls.append({
                "id": line_id,
                "coords": (x1, y1, x, y)
            })
            self.wall_start = (x, y)

    def _open_map_selector(self):
        """Abrir selector de mapa"""
        if not MAPVIEW_AVAILABLE:
            messagebox.showerror("Error", "La librería 'tkintermapview' no está instalada.\nInstale con: pip install tkintermapview")
            return

        map_win = tk.Toplevel(self.win)
        map_win.title("Seleccionar Ubicación")
        map_win.geometry("1000x800")
        
        # Frame superior busqueda
        top_f = tk.Frame(map_win, bg="white")
        top_f.pack(fill="x", pady=5)
        
        tk.Label(top_f, text="Buscar:", bg="white").pack(side="left", padx=5)
        entry = tk.Entry(top_f, width=40)
        entry.pack(side="left", padx=5)
        
        # Mapa
        map_frame = tk.Frame(map_win)
        map_frame.pack(fill="both", expand=True)
        
        bg_map = tkintermapview.TkinterMapView(map_frame, width=800, height=600, corner_radius=0)
        bg_map.pack(fill="both", expand=True)
        
        bg_map.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22) # Google Maps
        bg_map.set_address("Spain") # Default
        
        tk.Button(top_f, text="🔍 Ir", command=lambda: search()).pack(side="left", padx=2)
        
        status_lbl = tk.Label(top_f, text="", bg="white", fg="gray")
        status_lbl.pack(side="left", padx=10)

        import threading
        if not hasattr(self, "map_markers"): self.map_markers = []

        def search(event=None):
            addr = entry.get()
            if not addr: return
            
            # Limpiar marcadores anteriores
            bg_map.delete_all_marker()
            
            def _search_thread():
                try:
                    # Actualizar UI desde hilo principal
                    self.win.after(0, lambda: status_lbl.config(text="Buscando...", fg="blue"))
                    
                    headers = {"User-Agent": "ServiceATS/1.0"}
                    url = "https://nominatim.openstreetmap.org/search"
                    
                    # Intento 1: Búsqueda directa
                    params = {"q": addr, "format": "json", "limit": 1}
                    r = requests.get(url, params=params, headers=headers, timeout=5)
                    data = r.json()
                    
                    # Intento 2: Añadir ", España" si falla
                    if not data and "," not in addr:
                         params["q"] = f"{addr}, España"
                         r = requests.get(url, params=params, headers=headers, timeout=5)
                         data = r.json()
                    
                    if data:
                        item = data[0]
                        lat = float(item["lat"])
                        lon = float(item["lon"])
                        display_name = item.get("display_name", addr)
                        
                        # Actualizar mapa en hilo principal
                        def _update_map():
                            bg_map.set_position(lat, lon)
                            bg_map.set_zoom(16)
                            bg_map.set_marker(lat, lon, text=display_name.split(",")[0])
                            status_lbl.config(text=f"✅ Encontrado: {display_name.split(',')[0]}", fg="green")
                        
                        self.win.after(0, _update_map)
                    else:
                        self.win.after(0, lambda: status_lbl.config(text=f"❌ No encontrado: {addr}", fg="red"))
                        
                except Exception as e:
                    print(f"Error búsqueda: {e}")
                    self.win.after(0, lambda: status_lbl.config(text="❌ Error de conexión", fg="red"))

            # Ejecutar en hilo secundario
            threading.Thread(target=_search_thread, daemon=True).start()

        entry.bind("<Return>", search)
        
        def locate_me():
            
            def _locate_thread():
                try:
                    self.win.after(0, lambda: status_lbl.config(text="Detectando ubicación...", fg="blue"))
                    
                    # Intento 1: ip-api.com
                    try:
                        response = requests.get('http://ip-api.com/json/', timeout=3)
                        data = response.json()
                        success = (data.get('status') == 'success')
                        lat, lon, city = float(data.get('lat', 0)), float(data.get('lon', 0)), data.get('city', '')
                    except:
                        success = False

                    # Intento 2: ipinfo.io (Fallback)
                    if not success:
                        try:
                            response = requests.get('https://ipinfo.io/json', timeout=3)
                            data = response.json()
                            if 'loc' in data:
                                lat, lon = map(float, data['loc'].split(','))
                                city = data.get('city', 'Aproximada')
                                success = True
                        except:
                            success = False
                    
                    if success:
                        def _update_map():
                            bg_map.set_position(lat, lon)
                            bg_map.set_zoom(15)
                            bg_map.delete_all_marker()
                            bg_map.set_marker(lat, lon, text=f"Estás aquí: {city}")
                            status_lbl.config(text=f"📍 Ubicación: {city}", fg="green")
                        self.win.after(0, _update_map)
                    else:
                        self.win.after(0, lambda: status_lbl.config(text="❌ No se pudo localizar", fg="red"))
                        
                except Exception as e:
                    print(f"Error ubicación: {e}")
                    self.win.after(0, lambda: status_lbl.config(text="❌ Error de conexión", fg="red"))

            threading.Thread(target=_locate_thread, daemon=True).start()

        tk.Button(top_f, text="📍 Mi Ubicación", command=locate_me, bg="#2196f3", fg="white").pack(side="left", padx=5)
        
        # Botones de tipo de mapa
        type_f = tk.Frame(map_win, bg="white")
        type_f.pack(fill="x", pady=2)
        
        def set_map(mode):
            if mode == "std":
                bg_map.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)
            elif mode == "sat":
                bg_map.set_tile_server("https://mt0.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)
            elif mode == "hyb":
                bg_map.set_tile_server("https://mt0.google.com/vt/lyrs=y&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)

        tk.Button(type_f, text="🗺️ Mapa", command=lambda: set_map("std"), width=10).pack(side="left", padx=2)
        tk.Button(type_f, text="🛰️ Satélite", command=lambda: set_map("sat"), width=10).pack(side="left", padx=2)
        tk.Button(type_f, text="🏷️ Híbrido", command=lambda: set_map("hyb"), width=10).pack(side="left", padx=2)
        
        def capture():
            try:
                import io
                import time
                from PIL import ImageGrab
                
                # Asegurar que la ventana está visible y renderizada
                map_win.lift()
                map_win.focus_force()
                map_win.update_idletasks()
                map_win.update()
                
                # Pequeña pausa para asegurar pintado en Windows
                time.sleep(0.5)
                
                # Obtener coordenadas de pantalla del widget mapa
                x = bg_map.winfo_rootx()
                y = bg_map.winfo_rooty()
                w = bg_map.winfo_width()
                h = bg_map.winfo_height()
                
                # Capturar
                img = ImageGrab.grab(bbox=(x, y, x+w, y+h))
                
                # Guardar temporalmente
                tmp_path = os.path.join(os.path.dirname(__file__), "temp_map_capture.png")
                img.save(tmp_path)
                
                self.plan_path = tmp_path
                self.plan_pil = img
                self.plan_image = ImageTk.PhotoImage(self.plan_pil)
                
                # Reset canvas
                self.canvas.delete("all")
                self.canvas.config(scrollregion=(0, 0, w, h))
                self._render_plan_image()
                self._redraw_all()
                self.show_status("Fondo de mapa capturado correctamente.", "green")
                
                map_win.destroy()
                
            except ImportError:
                 messagebox.showerror("Error", "Se requiere Pillow para capturar el mapa.")
            except Exception as e:
                messagebox.showerror("Error", f"Fallo al capturar mapa: {e}")

        tk.Button(top_f, text="📸 Capturar esta vista", bg="#2e7d32", fg="white", 
                 font=("Segoe UI", 10, "bold"), command=capture).pack(side="right", padx=10)

    def _wall_click_end(self, event):
        """Terminar segmento de pared"""
        if self.wall_start:
            x = self.canvas.canvasx(event.x)
            y = self.canvas.canvasy(event.y)
            x1, y1 = self.wall_start
            
            line_id = self.canvas.create_line(
                x1, y1, x, y, 
                fill="gray20", width=4, tags="wall"
            )
            self.walls.append({
                "id": line_id,
                "coords": (x1, y1, x, y)
            })
        
        self.wall_start = None
        
        # Actualizar conos (re-calcular FOV)
        for el in self.elements:
            if el.get("cone"):
                self._redraw_cone(el)
                
        self._save_state()


    # ---------------------------
    # Element list management
    # ---------------------------
    def _update_element_list(self):
        """Actualizar listbox de elementos"""
        self.element_listbox.delete(0, tk.END)
        
        for i, el in enumerate(self.elements):
            name = el.get('name', 'Sin nombre')
            tipo = el['tipo'].upper()
            zone = el.get('zone', '')
            
            display = f"{i+1}. [{tipo}] {name}"
            if zone:
                display += f" - {zone}"
            
            self.element_listbox.insert(tk.END, display)
        
        # Actualizar estadísticas
        self.stats_label.config(text=f"Total: {len(self.elements)} elementos")

    def _on_listbox_select(self, event):
        """Seleccionar elemento desde listbox"""
        selection = self.element_listbox.curselection()
        if not selection:
            return
        
        idx = selection[0]
        if idx < len(self.elements):
            el = self.elements[idx]
            self._select_element(el)
            
            # Centrar vista en el elemento
            self.canvas.xview_moveto(el['x'] / self.canvas.winfo_width())
            self.canvas.yview_moveto(el['y'] / self.canvas.winfo_height())

    # ---------------------------
    # Redraw all
    # ---------------------------
    def _redraw_all(self):
        """Redibujar todos los elementos respetando capas"""
        # Redibujar plano
        if self.plan_pil:
            self._render_plan_image()
        
        # Redibujar paredes
        if self.layers_visible.get('walls', True):
            for wall in self.walls:
                if wall.get('id'):
                    self.canvas.itemconfig(wall['id'], state='normal')
        else:
            for wall in self.walls:
                if wall.get('id'):
                    self.canvas.itemconfig(wall['id'], state='hidden')
        
        # Redibujar elementos
        for el in self.elements:
            visible = self.layers_visible.get(el['tipo'], True)
            state = 'normal' if visible else 'hidden'
            
            self.canvas.itemconfig(el['id'], state=state)
            if el.get('cone'):
                self.canvas.itemconfig(el['cone']['id'], state=state)
        
        # Redibujar etiquetas
        if self.layers_visible.get('labels', True):
            for label in self.labels:
                if label.get('id'):
                    self.canvas.itemconfig(label['id'], state='normal')
        else:
            for label in self.labels:
                if label.get('id'):
                    self.canvas.itemconfig(label['id'], state='hidden')

    def _clear_elements(self):
        """Limpiar todos los elementos"""
        for el in list(self.elements):
            try:
                if el.get("cone"):
                    self.canvas.delete(el["cone"]["id"])
            except:
                pass
            try:
                self.canvas.delete(el["id"])
            except:
                pass
        
        self.elements.clear()
        self.walls.clear()
        self.labels.clear()
        
        self.canvas.delete("wall")
        self.canvas.delete("label")
        
        self._select_element(None)
        self._update_element_list()


    # ---------------------------
    # Clear elements helper
    # ---------------------------



# ---------------------------
# Alias para compatibilidad
# ---------------------------
PlanosManager = PlanosManagerPro


# ---------------------------
# Función de inicio
# ---------------------------
def iniciar_planos_manager(parent=None, current_user=None, auto_wizard=False):
    """Función para iniciar el gestor de planos"""
    if parent is None:
        root = tk.Tk()
        root.withdraw()
        parent = root
    
    app = PlanosManagerPro(parent, current_user, auto_wizard=auto_wizard)
    return app


# ---------------------------
# Prueba standalone
# ---------------------------
if __name__ == "__main__":
    root = tk.Tk()
    root.withdraw()
    
    # Usuario de prueba
    test_user = {
        "username": "Admin",
        "is_admin": 1
    }
    
    app = PlanosManagerPro(root, test_user)
    root.mainloop()