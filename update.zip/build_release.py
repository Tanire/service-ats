import zipfile
import os
from pathlib import Path

def create_release_zip():
    project_root = Path(os.getcwd())
    output_filename = "update.zip"
    
    # Exclusions
    excludes_dirs = {'.venv', '.git', '__pycache__', '.gemini', '.agent', 'tmp', 'venv', 'dist', 'build', '.idea', '.vscode', 'dev_tools', '.db_sync_repo', 'service-ats-releases-repo'}
    excludes_files = {'update.zip', 'service_ats.db', 'usuarios_backup.json'} 
    # Excluding DBs is crucial to not overwrite user data on update? 
    # Actually, main.py _download_and_apply_update overwrites everything.
    # Usually we want code, not data.
    # Let's exclude .db files from the root context or specific data folders if they are local.
    # The user's system seems to have DBs in root `service_ats.db` and inside folders. 
    # A safe update package should NOT contain production databases.
    
    excludes_exts = {'.db', '.pyc', '.log', '.exe', '.dll', '.msi', '.zip'}

    print(f"Creating {output_filename} from {project_root}...")
    
    with zipfile.ZipFile(output_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(project_root):
            # Modifier dirs list in-place to skip excluded dirs
            dirs[:] = [d for d in dirs if d not in excludes_dirs]
            
            for file in files:
                file_path = Path(root) / file
                rel_path = file_path.relative_to(project_root)
                
                # Check exclusions
                if file in excludes_files:
                    continue
                if file.endswith(tuple(excludes_exts)):
                    continue
                if any(part in excludes_dirs for part in rel_path.parts):
                    continue

                print(f"Adding: {rel_path}")
                zipf.write(file_path, rel_path)
                
    print(f"Successfully created {output_filename}")

if __name__ == "__main__":
    create_release_zip()
