# proyectos/tecnicos/kilometros.py
"""
Kilómetros y Repostajes - Service ATS
- Registra repostajes, vehículo, litros, precio y km.
- Filtro por mes y usuario.
- Reporte por email.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from pathlib import Path
import os
import webbrowser
import urllib.parse

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / "proyectos" / "tecnicos" / "gastos.db" # Shared DB with gastos

class KilometrosFrame(ttk.Frame):
    def __init__(self, parent, current_user=None):
        super().__init__(parent)
        self.parent = parent
        self.current_user = current_user or {}
        self.username = self.current_user.get("username", "Desconocido")
        self.is_admin = (self.current_user.get("is_admin", 0) == 1)
        self.selected_id = None

        os.makedirs(DB_PATH.parent, exist_ok=True)
        self._crear_tabla()
        self._crear_interfaz()
        self._cargar_registros()

    def _crear_tabla(self):
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("""
                CREATE TABLE IF NOT EXISTS kilometros (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fecha TEXT,
                    vehiculo TEXT,
                    matricula TEXT,
                    conductor TEXT,
                    litros REAL,
                    precio_litro REAL,
                    total REAL,
                    km REAL,
                    usuario TEXT
                )
            """)
            conn.commit()
            conn.close()
        except Exception as e:
            print("Error creando tabla kilometros:", e)

    def _crear_interfaz(self):
        pad = {"padx": 5, "pady": 5}
        
        # Info
        ttk.Label(self, text=f"Conductor/Usuario: {self.username}" + (" (Admin)" if self.is_admin else ""), 
                  font=("Segoe UI", 10, "italic"), foreground="blue").pack(anchor="w", padx=10, pady=(5,0))

        # --- Formulario ---
        form_frame = ttk.LabelFrame(self, text="Nuevo Repostaje / Registro Km", padding=10)
        form_frame.pack(fill="x", padx=10, pady=5)
        
        # Fila 1
        ttk.Label(form_frame, text="Fecha:").grid(row=0, column=0, sticky="w", **pad)
        self.fecha_entry = ttk.Entry(form_frame, width=15)
        self.fecha_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        self.fecha_entry.grid(row=0, column=1, sticky="w", **pad)
        
        ttk.Label(form_frame, text="Vehículo:").grid(row=0, column=2, sticky="w", **pad)
        self.vehiculo_entry = ttk.Entry(form_frame, width=20)
        self.vehiculo_entry.grid(row=0, column=3, sticky="w", **pad)

        ttk.Label(form_frame, text="Matrícula:").grid(row=0, column=4, sticky="w", **pad)
        self.matricula_entry = ttk.Entry(form_frame, width=15)
        self.matricula_entry.grid(row=0, column=5, sticky="w", **pad)

        # Fila 2
        ttk.Label(form_frame, text="Litros:").grid(row=1, column=0, sticky="w", **pad)
        self.litros_entry = ttk.Entry(form_frame, width=10)
        self.litros_entry.grid(row=1, column=1, sticky="w", **pad)
        
        ttk.Label(form_frame, text="Precio/Litro (€):").grid(row=1, column=2, sticky="w", **pad)
        self.precio_entry = ttk.Entry(form_frame, width=10)
        self.precio_entry.grid(row=1, column=3, sticky="w", **pad)
        
        ttk.Label(form_frame, text="Km Actuales:").grid(row=1, column=4, sticky="w", **pad)
        self.km_entry = ttk.Entry(form_frame, width=15)
        self.km_entry.grid(row=1, column=5, sticky="w", **pad)

        # Fila 3
        ttk.Button(form_frame, text="Guardar", command=self.guardar).grid(row=2, column=5, sticky="e", **pad)
        
        self.lbl_preview = ttk.Label(form_frame, text="Coste Total: 0.00 €", font=("Segoe UI", 9, "bold"))
        self.lbl_preview.grid(row=2, column=0, columnspan=3, sticky="w", **pad)
        
        if self.is_admin:
            admin_frame = ttk.Frame(self)
            admin_frame.pack(fill="x", padx=10, pady=2)
            ttk.Button(admin_frame, text="Eliminar Registro", command=self.eliminar).pack(side="left", padx=5)
            ttk.Button(admin_frame, text="Modificar Registro", command=self.cargar_edicion).pack(side="left", padx=5)
            ttk.Button(admin_frame, text="Limpiar Form", command=self._limpiar).pack(side="left", padx=5)
        
        self.litros_entry.bind("<KeyRelease>", self._calc_preview)
        self.precio_entry.bind("<KeyRelease>", self._calc_preview)

        # --- Filtros ---
        filter_frame = ttk.Frame(self)
        filter_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(filter_frame, text="Filtrar por Mes:").pack(side="left", padx=5)
        self.filtro_mes = ttk.Combobox(filter_frame, state="readonly", width=15)
        self.filtro_mes.pack(side="left", padx=5)
        self.filtro_mes.bind("<<ComboboxSelected>>", lambda e: self._cargar_registros())
        
        ttk.Button(filter_frame, text="✉ Enviar Reporte", command=self.enviar_reporte).pack(side="right", padx=5)

        # --- Tabla --- 
        # Cols: Fecha, Vehiculo, Matricula, Conductor, Litros, Precio, Total, Km
        cols = ["fecha", "vehiculo", "matricula", "conductor", "litros", "precio", "total", "km"]
        if self.is_admin:
            cols.insert(1, "usuario") # Insertar usuario para admin
        # If admin, conductor is redundant if we assume 'conductor' field stores name manually OR is system user.
        # Required: "identifique el conductor". I will use system user as conductor default but store it in DB col 'conductor'.
        # Actually, let's allow manual input for Conductor but default to self.username? 
        # User said "identifique el conductor". Usually implied self but maybe user inputs name?
        # I'll add 'Conductor' input field defaulted to username.
        
        # Wait, I didn't add Conductor input in form above. Adding it now.
        ttk.Label(form_frame, text="Conductor:").grid(row=2, column=2, sticky="w", **pad)
        self.conductor_entry = ttk.Entry(form_frame, width=20)
        self.conductor_entry.insert(0, self.username)
        self.conductor_entry.grid(row=2, column=3, sticky="w", **pad)

        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=10)
        
        self.tree.heading("fecha", text="Fecha")
        self.tree.column("fecha", width=90)
        
        self.tree.heading("vehiculo", text="Vehículo")
        self.tree.column("vehiculo", width=120)
        
        self.tree.heading("matricula", text="Matrícula")
        self.tree.column("matricula", width=90)
        
        self.tree.column("matricula", width=90)
        
        if self.is_admin:
            self.tree.heading("usuario", text="Usuario")
            self.tree.column("usuario", width=100)
            
        self.tree.heading("conductor", text="Conductor")
        self.tree.column("conductor", width=100)
        
        self.tree.heading("litros", text="Litros")
        self.tree.column("litros", width=60, anchor="e")
        
        self.tree.heading("precio", text="€/L")
        self.tree.column("precio", width=60, anchor="e")
        
        self.tree.heading("total", text="Total €")
        self.tree.column("total", width=70, anchor="e")
        
        self.tree.heading("km", text="Km")
        self.tree.column("km", width=80, anchor="e")
        
        self.tree.pack(fill="both", expand=True, padx=10, pady=5)
        
        self.lbl_sumario = ttk.Label(self, text="Total Gasto: 0.00 €", font=("Segoe UI", 12, "bold"))
        self.lbl_sumario.pack(anchor="e", padx=10, pady=10)
        
        self._actualizar_combo_meses()

    def _calc_preview(self, event=None):
        try:
            l = float(self.litros_entry.get())
            p = float(self.precio_entry.get())
            self.lbl_preview.config(text=f"Coste Total: {l*p:.2f} €")
        except:
            self.lbl_preview.config(text="Coste Total: - €")

    def guardar(self):
        try:
            fecha = self.fecha_entry.get()
            vehiculo = self.vehiculo_entry.get()
            matricula = self.matricula_entry.get()
            conductor = self.conductor_entry.get()
            litros = float(self.litros_entry.get())
            precio = float(self.precio_entry.get())
            km = float(self.km_entry.get())
            total = litros * precio
            
            conn = sqlite3.connect(DB_PATH)
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            
            if self.selected_id:
                # Update
                c.execute("""UPDATE kilometros SET fecha=?, vehiculo=?, matricula=?, conductor=?, litros=?, precio_litro=?, total=?, km=? WHERE id=?""",
                          (fecha, vehiculo, matricula, conductor, litros, precio, total, km, self.selected_id))
                messagebox.showinfo("Actualizado", "Registro actualizado.")
            else:
                # Insert
                c.execute("""
                    INSERT INTO kilometros (fecha, vehiculo, matricula, conductor, litros, precio_litro, total, km, usuario)
                    VALUES (?,?,?,?,?,?,?,?,?)
                """, (fecha, vehiculo, matricula, conductor, litros, precio, total, km, self.username))
                messagebox.showinfo("Guardado", "Registro añadido.")
                
            conn.commit()
            conn.close()
            
            self._limpiar()
            self._actualizar_combo_meses()
            self._cargar_registros()
        except ValueError:
            messagebox.showerror("Error", "Revisa los campos numéricos (Litros, Precio, Km).")
        except Exception as e:
            messagebox.showerror("Error", f"Error BD: {e}")

    def eliminar(self):
        sel = self.tree.selection()
        if not sel: return
        iid = sel[0]
        try:
            db_id = int(iid)
            if messagebox.askyesno("Confirmar", "¿Eliminar este registro?"):
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute("DELETE FROM kilometros WHERE id=?", (db_id,))
                conn.commit()
                conn.close()
                self._cargar_registros()
                self._limpiar()
        except Exception as e:
            messagebox.showerror("Error", f"Fallo al eliminar: {e}")

    def cargar_edicion(self):
        sel = self.tree.selection()
        if not sel: return
        iid = sel[0]
        try:
            self.selected_id = int(iid)
            vals = self.tree.item(iid)['values']
            # Normal: fecha, vehiculo, matricula, conductor, litros, precio, total, km
            # Admin:  fecha, usuario, vehiculo, matricula, conductor, litros, precio, total, km
            
            # Mapear indices según si es admin
            # indices en vals:
            if self.is_admin:
                # 0=f, 1=u, 2=veh, 3=mat, 4=cond, 5=lit, 6=prec, 7=tot, 8=km
                f, _, veh, mat, cond, lit, pre, _, k = vals
            else:
                # 0=f, 1=veh, 2=mat, 3=cond, 4=lit, 5=prec, 6=tot, 7=km
                f, veh, mat, cond, lit, pre, _, k = vals
            
            self.fecha_entry.delete(0, tk.END); self.fecha_entry.insert(0, f)
            self.vehiculo_entry.delete(0, tk.END); self.vehiculo_entry.insert(0, veh)
            self.matricula_entry.delete(0, tk.END); self.matricula_entry.insert(0, mat)
            self.conductor_entry.delete(0, tk.END); self.conductor_entry.insert(0, cond)
            self.litros_entry.delete(0, tk.END); self.litros_entry.insert(0, lit)
            self.precio_entry.delete(0, tk.END); self.precio_entry.insert(0, pre)
            self.km_entry.delete(0, tk.END); self.km_entry.insert(0, k)
            self._calc_preview()
        except Exception as e:
            print("Error cargar edicion km:", e)

    def _limpiar(self):
        self.selected_id = None
        self.litros_entry.delete(0, tk.END)
        self.precio_entry.delete(0, tk.END)
        self.km_entry.delete(0, tk.END)
        self.lbl_preview.config(text="Coste: 0.00 €")

    def _actualizar_combo_meses(self):
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            query = "SELECT DISTINCT substr(fecha, 1, 7) FROM kilometros"
            if not self.is_admin:
                query += " WHERE usuario=?"
                c.execute(query + " ORDER BY fecha DESC", (self.username,))
            else:
                c.execute(query + " ORDER BY fecha DESC")
            
            meses = [r[0] for r in c.fetchall() if r[0]]
            conn.close()
            
            self.filtro_mes["values"] = ["Todos"] + meses
            if not self.filtro_mes.get(): self.filtro_mes.set("Todos")
        except: pass

    def _cargar_registros(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        filtro = self.filtro_mes.get()
        total_gasto = 0.0
        
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            cols_sel = "id, fecha, vehiculo, matricula, conductor, litros, precio_litro, total, km"
            if self.is_admin:
                cols_sel = "id, fecha, usuario, vehiculo, matricula, conductor, litros, precio_litro, total, km"
            
            query = f"SELECT {cols_sel} FROM kilometros WHERE 1=1"
            params = []
            
            if not self.is_admin:
                query += " AND usuario=?"
                params.append(self.username)
                
            if filtro and filtro != "Todos":
                query += " AND fecha LIKE ?"
                params.append(f"{filtro}%")
            
            query += " ORDER BY fecha DESC"
            c.execute(query, params)
            
            for row in c.fetchall():
                # row[0] is ID
                self.tree.insert("", "end", iid=str(row[0]), values=row[1:])
                # total is index 7(admin) or 6(user) in values (row[1:]), but lets use known index relative to row
                # if admin: 0=id, ..., 8=total. index in values: 7
                # if user: 0=id, ..., 7=total. index in values: 6
                idx_total = 8 if self.is_admin else 7
                total_gasto += row[idx_total]
            conn.close()
        except Exception as e: print("Error loading km:", e)
        
        self.lbl_sumario.config(text=f"Total Gasto: {total_gasto:.2f} €")

    def enviar_reporte(self):
        items = self.tree.get_children()
        if not items: return
        
        periodo = self.filtro_mes.get()
        body = f"Reporte Kilómetros/Combustible - {self.username}\nPeriodo: {periodo}\n\n"
        
        body += f"{'FECHA':<12} | {'MATRICULA':<10} | {'CONDUCTOR':<15} | {'LITROS':>6} | {'PRECIO':>6} | {'TOTAL':>8} | {'KM':>8}\n"
        body += "-"*90 + "\n"
        
        total = 0
        for item in items:
            v = self.tree.item(item)['values']
            # fecha, vehiculo, matricula, conductor, litros, precio, total, km
            t = float(v[6])
            total += t
            body += f"{v[0]:<12} | {v[2]:<10} | {v[3]:<15} | {v[4]:>6} | {v[5]:>6} | {t:>8.2f} | {v[7]:>8}\n"
            
        body += "-"*90 + "\n"
        body += f"TOTAL GASTO: {total:.2f} €\n"
        
        s = urllib.parse.quote(f"Reporte Km {self.username} - {periodo}")
        b = urllib.parse.quote(body)
        webbrowser.open(f"mailto:?subject={s}&body={b}")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Km Prueba")
    KilometrosFrame(root).pack(fill="both", expand=True)
    root.mainloop()
