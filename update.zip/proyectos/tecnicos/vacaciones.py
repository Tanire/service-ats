# proyectos/tecnicos/vacaciones.py
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import json

from datetime import datetime, timedelta
from pathlib import Path
import os
import calendar

# Rutas
PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / "proyectos" / "tecnicos" / "vacaciones.db"

MONTHS_ES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", 
             "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

class VacacionesFrame(tk.Frame):
    def __init__(self, parent, current_user=None, log_manager=None, drive_sync=None):
        super().__init__(parent)
        self.parent = parent
        self.current_user = current_user or {}
        self.log_manager = log_manager
        self.drive_sync = drive_sync
        self.username = self.current_user.get("username", "Desconocido")
        self.is_admin = (self.current_user.get("is_admin", 0) == 1)
        
        self.year = datetime.now().year
        self.selected_dates = set() # Set de strings "YYYY-MM-DD"
        self.max_laborables = 23
        self.request_id = None
        self.request_status = "Sin solicitud"
        
        self._ensure_db()
        self._build_ui()
        
        # Si es usuario normal, cargamos sus datos. Si es admin, mostramos panel de gestión.
        if self.is_admin:
            self._show_admin_panel()
        else:
            self._show_user_panel()

    def _ensure_db(self):
        os.makedirs(DB_PATH.parent, exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS solicitudes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario TEXT,
                anio INTEGER,
                fechas TEXT,
                dias_totales INTEGER,
                estado TEXT DEFAULT 'Pendiente',
                fecha_solicitud TEXT
            )
        """)
        conn.commit()
        conn.close()

    def _sync_upload(self):
        """Sube la DB a Drive inmediatamente."""
        if not self.drive_sync: return
        try:
            self.config(cursor="watch")
            self.update()
            # str(DB_PATH) es necesario si es Path object
            self.drive_sync.upload_file(str(DB_PATH), "vacaciones.db", "databases")
            print("Vacaciones Sync: Uploaded")
        except Exception as e:
            print("Error uploading vacaciones db:", e)
        finally:
            self.config(cursor="")

    def _sync_download(self):
        """Descarga la DB de Drive (Refresco)."""
        if not self.drive_sync: return
        try:
            self.config(cursor="watch")
            self.update()
            res = self.drive_sync.download_file("vacaciones.db", str(DB_PATH), "databases")
            if res.get("status") == "downloaded":
                print("Vacaciones Sync: Downloaded")
                return True
        except Exception as e:
            print("Error downloading vacaciones db:", e)
        finally:
            self.config(cursor="")
        return False

    def _build_ui(self):
        # Header
        header = ttk.Frame(self)
        header.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(header, text=f"Gestión de Vacaciones - {self.year}", 
                 font=("Segoe UI", 16, "bold"), foreground="#004080").pack(side="left")
        
        ttk.Label(header, text=f"Usuario: {self.username}" + (" (Admin)" if self.is_admin else ""),
                 font=("Segoe UI", 10, "italic")).pack(side="right", padx=10)

        # Contenedor principal
        self.main_container = ttk.Frame(self)
        self.main_container.pack(fill="both", expand=True, padx=10, pady=5)

    # ---------------------------
    # VISTA USUARIO (Multiple Requests & History)
    # ---------------------------
    def _show_user_panel(self):
        for w in self.main_container.winfo_children(): w.destroy()
        
        # --- Top: Resumen Global ---
        summary_frame = ttk.LabelFrame(self.main_container, text="Resumen Anual", padding=10)
        summary_frame.pack(fill="x", pady=5)

        # Botón sync user
        ttk.Button(summary_frame, text="🔄 Sincronizar (Ver Aprobaciones)", 
                   command=lambda: [self._sync_download(), self._load_user_history()],
                   style="info.TButton" if hasattr(ttk, "BootStyle") else None).pack(side="right", padx=5)
        
        self.lbl_global_count = ttk.Label(summary_frame, text="Días Totales Consumidos (Aprobados/Pendientes): 0 / 23", font=("Segoe UI", 11, "bold"))
        self.lbl_global_count.pack(anchor="w")

        # --- Middle: Historial ---
        hist_frame = ttk.LabelFrame(self.main_container, text="Mis Solicitudes (Historial)", padding=10)
        hist_frame.pack(fill="both", expand=True, pady=5)
        
        cols = ("id", "fechas", "dias", "estado")
        self.user_tree = ttk.Treeview(hist_frame, columns=cols, show="headings", height=5)
        self.user_tree.heading("id", text="ID")
        self.user_tree.column("id", width=30)
        self.user_tree.heading("fechas", text="Fechas (Resumen)")
        self.user_tree.column("fechas", width=250)
        self.user_tree.heading("dias", text="Días")
        self.user_tree.column("dias", width=50)
        self.user_tree.heading("estado", text="Estado")
        self.user_tree.column("estado", width=100)
        
        self.user_tree.pack(side="left", fill="both", expand=True)
        self.user_tree.bind("<<TreeviewSelect>>", self._on_user_request_select)
        
        # Tags de color
        self.user_tree.tag_configure("Aprobado", foreground="green")
        self.user_tree.tag_configure("Rechazado", foreground="red")
        self.user_tree.tag_configure("Pendiente", foreground="#FF8C00") # Dark Orange

        # --- Bottom: Editor de Solicitud ---
        self.editor_frame = ttk.LabelFrame(self.main_container, text="Editor de Solicitud", padding=10)
        self.editor_frame.pack(fill="both", expand=True, pady=5)
        
        # Toolbar Editor
        tb_frame = ttk.Frame(self.editor_frame)
        tb_frame.pack(fill="x", pady=5)
        
        ttk.Button(tb_frame, text="✨ Nueva Solicitud", command=self._reset_editor).pack(side="left")
        self.btn_save = ttk.Button(tb_frame, text="💾 Guardar Solicitud", command=self._save_request)
        self.btn_save.pack(side="right", padx=5)
        self.btn_del_user = ttk.Button(tb_frame, text="🗑 Borrar", state="disabled", style="Danger.TButton", command=self._delete_request_user)
        self.btn_del_user.pack(side="right", padx=5)
        # Fallback tkinter standard
        if not hasattr(ttk, "BootStyle"): 
             self.btn_del_user.configure(command=self._delete_request_user)

        self.lbl_editor_status = ttk.Label(tb_frame, text="Modo: Nueva Solicitud", font=("Segoe UI", 9, "italic"), foreground="gray")
        self.lbl_editor_status.pack(side="right", padx=20)

        # Split Editor
        split_frame = ttk.Frame(self.editor_frame)
        split_frame.pack(fill="both", expand=True)
        
        # Input (Left)
        input_frame = ttk.Frame(split_frame)
        input_frame.pack(side="left", fill="both", padx=5)
        
        # --- DESDE ---
        ttk.Label(input_frame, text="DESDE:", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, columnspan=2, sticky="w", pady=5)
        ttk.Label(input_frame, text="Día:").grid(row=1, column=0)
        self.cb_day_start = ttk.Combobox(input_frame, values=[str(i) for i in range(1, 32)], width=4, state="readonly")
        self.cb_day_start.grid(row=1, column=1)
        self.cb_day_start.set(str(datetime.now().day))
        
        self.cb_month_start = ttk.Combobox(input_frame, values=MONTHS_ES, width=10, state="readonly")
        self.cb_month_start.grid(row=1, column=2, padx=5)
        self.cb_month_start.current(datetime.now().month - 1)
        
        self.cb_year_start = ttk.Combobox(input_frame, values=[str(self.year), str(self.year+1)], width=5, state="readonly")
        self.cb_year_start.grid(row=1, column=3)
        self.cb_year_start.set(str(self.year))

        # --- HASTA ---
        self.use_range = tk.BooleanVar(value=False)
        ttk.Checkbutton(input_frame, text="Rango (HASTA)", variable=self.use_range, command=self._toggle_end_date).grid(row=2, column=0, columnspan=2, sticky="w", pady=5)
        
        ttk.Label(input_frame, text="Día:").grid(row=3, column=0)
        self.cb_day_end = ttk.Combobox(input_frame, values=[str(i) for i in range(1, 32)], width=4, state="disabled")
        self.cb_day_end.grid(row=3, column=1)
        
        self.cb_month_end = ttk.Combobox(input_frame, values=MONTHS_ES, width=10, state="disabled")
        self.cb_month_end.grid(row=3, column=2, padx=5)
        
        self.cb_year_end = ttk.Combobox(input_frame, values=[str(self.year), str(self.year+1)], width=5, state="disabled")
        self.cb_year_end.grid(row=3, column=3)
        
        self.btn_add = ttk.Button(input_frame, text="➕ Añadir", command=self._add_date_range_user)
        self.btn_add.grid(row=4, column=0, columnspan=4, pady=10, sticky="ew")

        # List (Right)
        list_frame = ttk.Frame(split_frame)
        list_frame.pack(side="right", fill="both", expand=True, padx=5)
        
        cols_d = ("fecha", "dia", "tipo")
        self.dates_tree = ttk.Treeview(list_frame, columns=cols_d, show="headings", height=8)
        self.dates_tree.heading("fecha", text="Fecha")
        self.dates_tree.column("fecha", width=100)
        self.dates_tree.heading("dia", text="Dia")
        self.dates_tree.column("dia", width=80)
        self.dates_tree.heading("tipo", text="Tipo")
        self.dates_tree.column("tipo", width=80)
        self.dates_tree.pack(side="left", fill="both", expand=True)
        
        sb = ttk.Scrollbar(list_frame, orient="vertical", command=self.dates_tree.yview)
        sb.pack(side="right", fill="y")
        self.dates_tree.configure(yscrollcommand=sb.set)
        
        self.btn_remove = ttk.Button(list_frame, text="❌ Quitar", command=self._remove_date_user)
        self.btn_remove.pack(pady=5)

        self._load_user_history()

    def _load_user_history(self):
        # 1. Clear tree
        for i in self.user_tree.get_children(): self.user_tree.delete(i)
        
        self.accumulated_days = 0
        
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("SELECT id, fechas, dias_totales, estado FROM solicitudes WHERE usuario=? AND anio=? ORDER BY id DESC", 
                      (self.username, self.year))
            rows = c.fetchall()
            conn.close()
            
            for row in rows:
                r_id, f_json, dias, estado = row
                
                # Check accumulated (Approved or Pending count towards limit visible?) 
                # Usually Pending counts as "reserved". Rejected returns to pool.
                if estado in ["Aprobado", "Pendiente"]:
                    self.accumulated_days += dias
                
                # Summary dates
                f_str = ""
                try:
                    f_list = sorted(json.loads(f_json))
                    if f_list:
                        s = datetime.strptime(f_list[0], "%Y-%m-%d").strftime("%d/%m")
                        e = datetime.strptime(f_list[-1], "%Y-%m-%d").strftime("%d/%m")
                        f_str = f"{s} - {e} ({len(f_list)} días)"
                except:
                    f_str = "Error fechas"

                self.user_tree.insert("", "end", iid=str(r_id), values=(r_id, f_str, dias, estado), tags=(estado,))
            
            self.lbl_global_count.config(text=f"Días Consumidos/Reservados: {self.accumulated_days} / {self.max_laborables}")
            
        except Exception as e:
            print("Error history:", e)

    def _on_user_request_select(self, event):
        sel = self.user_tree.selection()
        if not sel: return
        r_id = sel[0]
        
        # Load into editor
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("SELECT id, fechas, estado FROM solicitudes WHERE id=?", (r_id,))
            row = c.fetchone()
            conn.close()
            
            if row:
                self.request_id = row[0]
                self.selected_dates = set(json.loads(row[1]))
                self.request_status = row[2]
                
                self._refresh_date_list()
                
                # UI State Logic
                if self.request_status == "Pendiente":
                    self._set_editor_state("normal", f"Editando Solicitud #{self.request_id}")
                    self.btn_del_user.config(state="normal")
                else:
                    self._set_editor_state("disabled", f"Viendo Solicitud #{self.request_id} ({self.request_status})")
                    self.btn_del_user.config(state="disabled")

        except Exception as e:
            print("Error loading request:", e)

    def _reset_editor(self):
        self.request_id = None
        self.request_status = "Nueva"
        self.selected_dates = set()
        self._refresh_date_list()
        self.user_tree.selection_remove(self.user_tree.selection())
        
        self._set_editor_state("normal", "Modo: Nueva Solicitud")
        self.btn_del_user.config(state="disabled")

    def _set_editor_state(self, state, label_text):
        self.lbl_editor_status.config(text=label_text)
        self.btn_save.config(state=state)
        self.btn_add.config(state=state)
        self.btn_remove.config(state=state)
        
        # Inputs
        self.cb_day_start.config(state="readonly" if state=="normal" else "disabled")
        self.cb_month_start.config(state="readonly" if state=="normal" else "disabled")
        self.cb_year_start.config(state="readonly" if state=="normal" else "disabled")
        # Range check?
        # If disabled, force disable range inputs too
        if state == "disabled":
             self.cb_day_end.config(state="disabled")
             self.cb_month_end.config(state="disabled")
             self.cb_year_end.config(state="disabled")
        else:
             self._toggle_end_date() # Restore based on checkbox

    def _toggle_end_date(self):
        # ... (same as before) ...
        state = "readonly" if self.use_range.get() else "disabled"
        self.cb_day_end.config(state=state)
        self.cb_month_end.config(state=state)
        self.cb_year_end.config(state=state)
        if self.use_range.get():
             if not self.cb_day_end.get(): self.cb_day_end.set(self.cb_day_start.get())
             if not self.cb_month_end.get(): self.cb_month_end.set(self.cb_month_start.get())
             if not self.cb_year_end.get(): self.cb_year_end.set(self.cb_year_start.get())

    def _parse_date_input(self, d_str, m_str, y_str):
        try:
            d = int(d_str)
            m = MONTHS_ES.index(m_str) + 1
            y = int(y_str)
            return datetime(y, m, d)
        except:
            return None

    def _add_date_range_user(self):
        # Parse Start
        start_date = self._parse_date_input(self.cb_day_start.get(), self.cb_month_start.get(), self.cb_year_start.get())
        if not start_date:
            messagebox.showerror("Error", "Fecha de inicio inválida.")
            return

        dates_to_add = []
        
        if self.use_range.get():
            end_date = self._parse_date_input(self.cb_day_end.get(), self.cb_month_end.get(), self.cb_year_end.get())
            if not end_date:
                messagebox.showerror("Error", "Fecha de fin inválida.")
                return
            
            if end_date < start_date:
                messagebox.showerror("Error", "La fecha fin debe ser posterior a la fecha inicio.")
                return
            
            # Iterate
            curr = start_date
            while curr <= end_date:
                dates_to_add.append(curr)
                curr += timedelta(days=1)
        else:
            dates_to_add.append(start_date)
            
        # Process additions
        added_count = 0
        skipped_weekend = 0
        skipped_dup = 0
        
        # Calculate limit base.
        # If we are EDITING, we exclude THIS request's current days from the "global accumulated" to verify limit correctly?
        # Actually easier: current_lab = self.accumulated_days (excludes this one if we substract? or we sum on fly?)
        # Let's simple check:
        # Limit = 23.
        # Used by Others = (Total Accumulated - Current Request Database Consumed).
        # But if we are adding dynamically, complex logic.
        # Simplified: Check limit against (Accumulated + New). 
        # CAREFUL: accumulated_days includes THIS request if it was loaded.
        
        # Recalculate 'other_requests_days'
        other_days = 0
        try:
             conn = sqlite3.connect(DB_PATH)
             c = conn.cursor()
             # Sum days of all requests EXCEPT current ID
             query = "SELECT SUM(dias_totales) FROM solicitudes WHERE usuario=? AND anio=? AND estado IN ('Aprobado', 'Pendiente')"
             params = [self.username, self.year]
             if self.request_id:
                 query += " AND id != ?"
                 params.append(self.request_id)
             
             c.execute(query, params)
             res = c.fetchone()[0]
             other_days = res if res else 0
             conn.close()
        except:
             pass
        
        # Now count LOCAL current days
        current_lab_local = self._count_laborables() # Based on self.selected_dates
        
        for dt in dates_to_add:
            d_str = dt.strftime("%Y-%m-%d")
            
            if d_str in self.selected_dates:
                skipped_dup += 1
                continue
                
            is_weekend = (dt.weekday() >= 5)
            if is_weekend:
                skipped_weekend += 1
                # Add anyway (no cost)
                self.selected_dates.add(d_str)
                added_count += 1
            else:
                if (other_days + current_lab_local + 1) <= self.max_laborables:
                    self.selected_dates.add(d_str)
                    current_lab_local += 1
                    added_count += 1
                else:
                    break # Limit reached
        
        if added_count > 0:
            self._refresh_date_list()
            msg = f"Se añadieron {added_count} fechas."
            if skipped_weekend > 0: msg += f"\n({skipped_weekend} fines de semana incluidos)."
            if (other_days + current_lab_local) >= self.max_laborables: msg += "\n⚠️ Límite de días laborables alcanzado."
            messagebox.showinfo("Resumen", msg)
        else:
             if (other_days + current_lab_local) >= self.max_laborables:
                 messagebox.showwarning("Límite", "No se añadieron fechas: Límite de días laborables alcanzado.")
             else:
                 messagebox.showinfo("Info", "No se añadieron nuevas fechas (posibles duplicados).")

    def _remove_date_user(self):
        sel = self.dates_tree.selection()
        if not sel: return
        
        for item in sel:
            vals = self.dates_tree.item(item)["values"]
            d_str_display = vals[0]
            dt = datetime.strptime(d_str_display, "%d/%m/%Y")
            d_str_db = dt.strftime("%Y-%m-%d")
            
            if d_str_db in self.selected_dates:
                self.selected_dates.remove(d_str_db)
        
        self._refresh_date_list()

    def _refresh_date_list(self):
        for i in self.dates_tree.get_children(): self.dates_tree.delete(i)
        sorted_dates = sorted(list(self.selected_dates))
        for d_str in sorted_dates:
            dt = datetime.strptime(d_str, "%Y-%m-%d")
            display_str = dt.strftime("%d/%m/%Y")
            wd = dt.weekday()
            days_es = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
            tipo = "Festivo" if wd >= 5 else "Laborable"
            self.dates_tree.insert("", "end", values=(display_str, days_es[wd], tipo))

    def _load_user_request(self):
        # Alias to init load
        self._load_user_history()
        self._reset_editor()

    def _count_laborables(self):
        count = 0
        for d_str in self.selected_dates:
            dt = datetime.strptime(d_str, "%Y-%m-%d")
            if dt.weekday() < 5: 
                count += 1
        return count

    def _update_counter(self):
        # Deprecated logic, now handled in history summary
        pass

    def _save_request(self):
        if not self.selected_dates:
             messagebox.showwarning("Atención", "La lista de fechas está vacía.")
             return
             
        laborables = self._count_laborables()
        fechas_json = json.dumps(list(self.selected_dates))
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            
            if self.request_id:
                # Update existing
                c.execute("UPDATE solicitudes SET fechas=?, dias_totales=?, fecha_solicitud=?, estado='Pendiente' WHERE id=?",
                          (fechas_json, laborables, now, self.request_id))
            else:
                # Insert NEW
                c.execute("INSERT INTO solicitudes (usuario, anio, fechas, dias_totales, fecha_solicitud) VALUES (?,?,?,?,?)",
                          (self.username, self.year, fechas_json, laborables, now))
                          
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Éxito", "Solicitud guardada correctamente.")
            
            if self.log_manager:
                action = "EDIT_REQUEST" if self.request_id else "NEW_REQUEST"
                self.log_manager.log(self.username, action, f"Días: {laborables}")

            self._load_user_history()
            self._load_user_history()
            self._reset_editor()
            
            # Auto-Upload
            self.after(100, self._sync_upload)
            
        except Exception as e:
            messagebox.showerror("Error", f"Error guardando: {e}")

    def _delete_request_user(self):
        if not self.request_id: return
        if not messagebox.askyesno("Confirmar", "¿Borrar esta solicitud?"): return
            
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("DELETE FROM solicitudes WHERE id=?", (self.request_id,))
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Borrado", "Solicitud eliminada.")

            if self.log_manager:
                self.log_manager.log(self.username, "DELETE_REQUEST", f"ID: {self.request_id}")

            self._load_user_history()
            self._load_user_history()
            self._reset_editor()
            
            # Auto-Upload
            self.after(100, self._sync_upload)
            
        except Exception as e:
            messagebox.showerror("Error", f"Error borrando: {e}")

    # ---------------------------
    # VISTA ADMIN (Simplified)
    # ---------------------------
    def _show_admin_panel(self):
        for w in self.main_container.winfo_children(): w.destroy()
        
        # Split: Lista izquierda (Solicitudes), Detalle derecha (Lista fechas)
        pane = ttk.PanedWindow(self.main_container, orient="horizontal")
        pane.pack(fill="both", expand=True)
        
        left_frame = ttk.Frame(pane)
        right_frame = ttk.Frame(pane)
        pane.add(left_frame, weight=1)
        pane.add(right_frame, weight=1)
        
        # --- Lista de Solicitudes (Izquierda) ---
        ttk.Label(left_frame, text="Solicitudes Pendientes / Global", font=("Segoe UI", 10, "bold")).pack(pady=5)
        
        cols = ["id", "usuario", "fechas_resumen", "dias", "estado"]
        self.tree_reqs = ttk.Treeview(left_frame, columns=cols, show="headings")
        self.tree_reqs.heading("usuario", text="Usuario")
        self.tree_reqs.column("usuario", width=100)
        self.tree_reqs.heading("fechas_resumen", text="Fechas")
        self.tree_reqs.column("fechas_resumen", width=120)
        self.tree_reqs.heading("dias", text="Días")
        self.tree_reqs.column("dias", width=40)
        self.tree_reqs.heading("estado", text="Estado")
        self.tree_reqs.column("estado", width=70)
        self.tree_reqs.pack(fill="both", expand=True, padx=5)
        
        self.tree_reqs.bind("<<TreeviewSelect>>", self._on_admin_select)
        
        btn_frame = ttk.Frame(left_frame)
        btn_frame.pack(fill="x", pady=5)
        btn_frame = ttk.Frame(left_frame)
        btn_frame.pack(fill="x", pady=5)
        ttk.Button(btn_frame, text="🔄 Sincronizar Nube (Descargar)", 
                   command=lambda: [self._sync_download(), self._load_all_requests()]).pack(side="left", fill="x", expand=True, padx=2)
        ttk.Button(btn_frame, text="Refrescar Local", command=self._load_all_requests).pack(side="right", fill="x", expand=True, padx=2)

        # --- Detalle Solicitud (Derecha) ---
        self.admin_detail_frame = ttk.LabelFrame(right_frame, text="Detalle de Días", padding=10)
        self.admin_detail_frame.pack(fill="both", expand=True, padx=5, pady=5)
        
        self.lbl_admin_info = ttk.Label(self.admin_detail_frame, text="Seleccione una solicitud")
        self.lbl_admin_info.pack(pady=5)
        
        # Lista de fechas readonly
        cols_d = ("fecha", "dia", "tipo")
        self.admin_dates_list = ttk.Treeview(self.admin_detail_frame, columns=cols_d, show="headings")
        self.admin_dates_list.heading("fecha", text="Fecha")
        self.admin_dates_list.heading("dia", text="Día")
        self.admin_dates_list.heading("tipo", text="Tipo")
        self.admin_dates_list.pack(fill="both", expand=True, pady=5)
        
        ctrl_frame = ttk.Frame(self.admin_detail_frame)
        ctrl_frame.pack(fill="x", pady=5)
        
        self.btn_approve = ttk.Button(ctrl_frame, text="✅ Aprobar", state="disabled", command=lambda: self._set_status("Aprobado"))
        self.btn_approve.pack(side="left", padx=5)
        
        self.btn_reject = ttk.Button(ctrl_frame, text="❌ Rechazar", state="disabled", command=lambda: self._set_status("Rechazado"))
        self.btn_reject.pack(side="left", padx=5)

        self.btn_del_admin = ttk.Button(ctrl_frame, text="🗑 Eliminar", state="disabled", style="Danger.TButton", command=self._delete_request_admin)
        self.btn_del_admin.pack(side="right", padx=5)
        
        self._load_all_requests()

    def _load_all_requests(self):
        for i in self.tree_reqs.get_children(): self.tree_reqs.delete(i)
        
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("SELECT id, usuario, dias_totales, estado, fechas FROM solicitudes WHERE anio=? ORDER BY estado DESC, fecha_solicitud DESC", (self.year,))
            rows = c.fetchall()
            conn.close()
            
            for row in rows:
                req_id, user, dias, estado, fechas_json = row
                
                # Calcular resumen
                fechas_str = ""
                try:
                    f_list = sorted(json.loads(fechas_json))
                    if f_list:
                        d_start = datetime.strptime(f_list[0], "%Y-%m-%d").strftime("%d/%m")
                        d_end = datetime.strptime(f_list[-1], "%Y-%m-%d").strftime("%d/%m")
                        fechas_str = f"{d_start} - {d_end}"
                except:
                    fechas_str = "Error"

                self.tree_reqs.insert("", "end", iid=str(req_id), values=(req_id, user, fechas_str, dias, estado))

        except Exception as e:
            print("Error admin load:", e)

    def _on_admin_select(self, event):
        sel = self.tree_reqs.selection()
        if not sel: return
        req_id = sel[0]
        self.selected_request_id = req_id
        
        # Cargar detalle y poblar lista derecha
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("SELECT usuario, fechas, dias_totales, estado FROM solicitudes WHERE id=?", (req_id,))
            row = c.fetchone()
            conn.close()
            
            if row:
                user, fechas_json, dias, estado = row
                self.lbl_admin_info.config(text=f"Solicitante: {user} | Días: {dias} | Estado: {estado}")
                
                # Poblar lista fechas
                for i in self.admin_dates_list.get_children(): self.admin_dates_list.delete(i)
                
                f_list = sorted(json.loads(fechas_json))
                days_es = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
                
                for d_str in f_list:
                    dt = datetime.strptime(d_str, "%Y-%m-%d")
                    display_str = dt.strftime("%d/%m/%Y")
                    wd = dt.weekday()
                    day_name = days_es[wd]
                    tipo = "Festivo" if wd >= 5 else "Laborable"
                    self.admin_dates_list.insert("", "end", values=(display_str, day_name, tipo))
                
                self.btn_approve.config(state="normal")
                self.btn_reject.config(state="normal")
                self.btn_del_admin.config(state="normal")

        except Exception as e:
            print("Error loading detail:", e)

    def _set_status(self, new_status):
        if not hasattr(self, 'selected_request_id'): return
        
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("UPDATE solicitudes SET estado=? WHERE id=?", (new_status, self.selected_request_id))
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Actualizado", f"Solicitud marcada como {new_status}")
            
            if self.log_manager:
                self.log_manager.log(self.username, f"ADMIN_{new_status.upper()}", f"Request ID: {self.selected_request_id}")

            self._load_all_requests()
            
            # Auto-Upload
            self.after(100, self._sync_upload)
            # Refresh selection
            self._on_admin_select(None)
        except Exception as e:
            messagebox.showerror("Error", f"Fallo al actualizar: {e}")

    def _delete_request_admin(self):
        if not hasattr(self, 'selected_request_id') or not self.selected_request_id: return
        
        if not messagebox.askyesno("Confirmar Eliminación", 
                                  "¿Seguro que deseas eliminar DEFINITIVAMENTE esta solicitud de la base de datos?\nEsta acción no se puede deshacer."):
            return

        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("DELETE FROM solicitudes WHERE id=?", (self.selected_request_id,))
            conn.commit()
            conn.close()
            
            messagebox.showinfo("Eliminado", "La solicitud ha sido eliminada.")
            
            if self.log_manager:
                self.log_manager.log(self.username, "ADMIN_DELETE_REQUEST", f"Request ID: {self.selected_request_id}")

            self._load_all_requests()
            
            # Auto-Upload
            self.after(100, self._sync_upload)
            
            # Reset UI
            self.lbl_admin_info.config(text="Seleccione una solicitud")
            for i in self.admin_dates_list.get_children(): self.admin_dates_list.delete(i)
            self.btn_approve.config(state="disabled")
            self.btn_reject.config(state="disabled")
            self.btn_del_admin.config(state="disabled")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error eliminando solicitud: {e}")


