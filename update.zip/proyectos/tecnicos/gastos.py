# proyectos/tecnicos/gastos.py
"""
Gastos Mensuales - Service ATS
- Registra gastos varios (Herramienta, Material, Comida, Gasoil, etc.)
- Filtro por mes y usuario.
- Reporte por email.
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from pathlib import Path
import os
import webbrowser
import urllib.parse

# Rutas
PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / "proyectos" / "tecnicos" / "gastos.db"

class GastosFrame(ttk.Frame):
    def __init__(self, parent, current_user=None):
        super().__init__(parent)
        self.parent = parent
        self.current_user = current_user or {}
        self.username = self.current_user.get("username", "Desconocido")
        self.is_admin = (self.current_user.get("is_admin", 0) == 1)
        self.selected_id = None

        os.makedirs(DB_PATH.parent, exist_ok=True)
        self._crear_tabla()
        self._crear_interfaz()
        self._cargar_registros()

    def _crear_tabla(self):
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("""
                CREATE TABLE IF NOT EXISTS gastos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    fecha TEXT,
                    tipo TEXT,
                    detalle TEXT,
                    importe REAL,
                    usuario TEXT
                )
            """)
            conn.commit()
            conn.close()
        except Exception as e:
            print("Error creando tabla gastos:", e)

    def _crear_interfaz(self):
        pad = {"padx": 5, "pady": 5}
        
        # Info usuario
        ttk.Label(self, text=f"Usuario: {self.username}" + (" (Admin)" if self.is_admin else ""), 
                  font=("Segoe UI", 10, "italic"), foreground="blue").pack(anchor="w", padx=10, pady=(5,0))

        # --- Formulario ---
        form_frame = ttk.LabelFrame(self, text="Nuevo Gasto", padding=10)
        form_frame.pack(fill="x", padx=10, pady=5)
        
        # Fila 1
        ttk.Label(form_frame, text="Fecha:").grid(row=0, column=0, sticky="w", **pad)
        self.fecha_entry = ttk.Entry(form_frame, width=15)
        self.fecha_entry.insert(0, datetime.now().strftime("%Y-%m-%d"))
        self.fecha_entry.grid(row=0, column=1, sticky="w", **pad)
        
        ttk.Label(form_frame, text="Tipo:").grid(row=0, column=2, sticky="w", **pad)
        tipos = ["Herramienta", "Material", "Comida", "Gasoil", "Hotel", "Otros"]
        self.tipo_combo = ttk.Combobox(form_frame, values=tipos, state="readonly", width=15)
        self.tipo_combo.set("Material")
        self.tipo_combo.grid(row=0, column=3, sticky="w", **pad)

        ttk.Label(form_frame, text="Importe (€):").grid(row=0, column=4, sticky="w", **pad)
        self.importe_entry = ttk.Entry(form_frame, width=10)
        self.importe_entry.grid(row=0, column=5, sticky="w", **pad)
        
        # Fila 2
        ttk.Label(form_frame, text="Detalle/Concepto:").grid(row=1, column=0, sticky="w", **pad)
        self.detalle_entry = ttk.Entry(form_frame, width=50)
        self.detalle_entry.grid(row=1, column=1, columnspan=4, sticky="w", **pad)
        
        ttk.Button(form_frame, text="Guardar", command=self.guardar).grid(row=1, column=5, sticky="w", **pad)
        
        if self.is_admin:
            admin_frame = ttk.Frame(self)
            admin_frame.pack(fill="x", padx=10, pady=2)
            ttk.Button(admin_frame, text="Eliminar Gasto", command=self.eliminar).pack(side="left", padx=5)
            ttk.Button(admin_frame, text="Modificar Gasto", command=self.cargar_edicion).pack(side="left", padx=5)
            ttk.Button(admin_frame, text="Limpiar Form", command=self._limpiar).pack(side="left", padx=5)

        # --- Filtros ---
        filter_frame = ttk.Frame(self)
        filter_frame.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(filter_frame, text="Filtrar por Mes:").pack(side="left", padx=5)
        self.filtro_mes = ttk.Combobox(filter_frame, state="readonly", width=15)
        self.filtro_mes.pack(side="left", padx=5)
        self.filtro_mes.bind("<<ComboboxSelected>>", lambda e: self._cargar_registros())
        
        ttk.Button(filter_frame, text="✉ Enviar Reporte", command=self.enviar_reporte).pack(side="right", padx=5)

        # --- Tabla ---
        cols = ["fecha", "tipo", "detalle", "importe"]
        if self.is_admin: cols.insert(1, "usuario")
        
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=12)
        
        self.tree.heading("fecha", text="Fecha")
        self.tree.column("fecha", width=90)
        
        if self.is_admin:
            self.tree.heading("usuario", text="Usuario")
            self.tree.column("usuario", width=100)
            
        self.tree.heading("tipo", text="Tipo")
        self.tree.column("tipo", width=100)
        
        self.tree.heading("detalle", text="Detalle")
        self.tree.column("detalle", width=250)
        
        self.tree.heading("importe", text="Importe (€)")
        self.tree.column("importe", width=80, anchor="e")
        
        self.tree.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Sumario
        self.lbl_total = ttk.Label(self, text="Total Mes: 0.00 €", font=("Segoe UI", 12, "bold"))
        self.lbl_total.pack(anchor="e", padx=10, pady=10)
        
        self._actualizar_combo_meses()

    def guardar(self):
        fecha = self.fecha_entry.get().strip()
        tipo = self.tipo_combo.get()
        detalle = self.detalle_entry.get().strip()
        importe_str = self.importe_entry.get().strip()
        
        if not importe_str:
            messagebox.showerror("Error", "Introduce un importe.")
            return
            
        try:
            importe = float(importe_str)
        except:
            messagebox.showerror("Error", "Importe inválido.")
            return
            
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            
            if self.selected_id:
                # Update
                c.execute("UPDATE gastos SET fecha=?, tipo=?, detalle=?, importe=? WHERE id=?",
                          (fecha, tipo, detalle, importe, self.selected_id))
                messagebox.showinfo("Actualizado", "Gasto actualizado.")
            else:
                # Insert
                c.execute("INSERT INTO gastos (fecha, tipo, detalle, importe, usuario) VALUES (?,?,?,?,?)",
                          (fecha, tipo, detalle, importe, self.username))
                messagebox.showinfo("Guardado", "Gasto registrado.")

            conn.commit()
            conn.close()
            
            self._limpiar()
            self._actualizar_combo_meses()
            self._cargar_registros()
        except Exception as e:
            messagebox.showerror("Error", f"Error BD: {e}")

    def eliminar(self):
        sel = self.tree.selection()
        if not sel: return
        iid = sel[0]
        try:
            db_id = int(iid)
            if messagebox.askyesno("Confirmar", "¿Eliminar este gasto?"):
                conn = sqlite3.connect(DB_PATH)
                c = conn.cursor()
                c.execute("DELETE FROM gastos WHERE id=?", (db_id,))
                conn.commit()
                conn.close()
                self._cargar_registros()
                self._limpiar()
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo eliminar: {e}")

    def cargar_edicion(self):
        sel = self.tree.selection()
        if not sel: return
        iid = sel[0]
        try:
            self.selected_id = int(iid)
            vals = self.tree.item(iid)['values']
            # Cols admin: 0=fecha, 1=usuario, 2=tipo, 3=detalle, 4=importe
            # Cols user:  0=fecha, 1=tipo, 2=detalle, 3=importe
            if self.is_admin:
                f, _, t, d, i = vals
            else:
                f, t, d, i = vals
                
            self.fecha_entry.delete(0, tk.END); self.fecha_entry.insert(0, f)
            self.tipo_combo.set(t)
            self.detalle_entry.delete(0, tk.END); self.detalle_entry.insert(0, d)
            self.importe_entry.delete(0, tk.END); self.importe_entry.insert(0, i)
        except:
            pass

    def _limpiar(self):
        self.selected_id = None
        self.detalle_entry.delete(0, tk.END)
        self.importe_entry.delete(0, tk.END)

    def _actualizar_combo_meses(self):
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            query = "SELECT DISTINCT substr(fecha, 1, 7) FROM gastos"
            if not self.is_admin:
                query += " WHERE usuario=?"
                c.execute(query + " ORDER BY fecha DESC", (self.username,))
            else:
                c.execute(query + " ORDER BY fecha DESC")
                
            meses = [row[0] for row in c.fetchall() if row[0]]
            conn.close()
            
            vals = ["Todos"] + meses
            self.filtro_mes["values"] = vals
            if not self.filtro_mes.get() and meses:
                curr = datetime.now().strftime("%Y-%m")
                self.filtro_mes.set(curr if curr in meses else "Todos")
            elif not self.filtro_mes.get():
                self.filtro_mes.set("Todos")
        except: pass

    def _cargar_registros(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        
        filtro = self.filtro_mes.get()
        total = 0.0
        
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            
            cols_sel = "id, fecha, tipo, detalle, importe"
            if self.is_admin: cols_sel = "id, fecha, usuario, tipo, detalle, importe"
            
            query = f"SELECT {cols_sel} FROM gastos WHERE 1=1"
            params = []
            
            if not self.is_admin:
                query += " AND usuario=?"
                params.append(self.username)
                
            if filtro and filtro != "Todos":
                query += " AND fecha LIKE ?"
                params.append(f"{filtro}%")
            
            query += " ORDER BY fecha DESC"
            c.execute(query, params)
            
            for row in c.fetchall():
                # row[0] is ID
                self.tree.insert("", "end", iid=str(row[0]), values=row[1:])
                # importe is last column in values (row[1:]) -> row[-1]
                total += row[-1]
                
            conn.close()
        except Exception as e: print("Error loading gastos:", e)
        
        self.lbl_total.config(text=f"Total Filtrado: {total:.2f} €")

    def enviar_reporte(self):
        items = self.tree.get_children()
        if not items: return
        
        periodo = self.filtro_mes.get()
        body = f"Reporte de Gastos - {self.username}\nPeriodo: {periodo}\n\n"
        
        if self.is_admin:
             body += f"{'FECHA':<12} | {'USUARIO':<15} | {'TIPO':<12} | {'DETALLE':<25} | {'IMPORTE':>8}\n"
        else:
             body += f"{'FECHA':<12} | {'TIPO':<12} | {'DETALLE':<30} | {'IMPORTE':>8}\n"
        body += "-"*80 + "\n"
        
        total = 0
        for item in items:
            vals = self.tree.item(item)['values']
            imp = float(vals[-1])
            total += imp
            line = " | ".join(str(v) for v in vals[:-1])
            body += f"{line} | {imp:.2f}\n"
            
        body += "-"*80 + "\n"
        body += f"TOTAL: {total:.2f} €\n"
        
        safe_subject = urllib.parse.quote(f"Gastos {self.username} - {periodo}")
        safe_body = urllib.parse.quote(body)
        webbrowser.open(f"mailto:?subject={safe_subject}&body={safe_body}")

if __name__ == "__main__":
    root = tk.Tk()
    root.title("Gastos Prueba")
    GastosFrame(root).pack(fill="both", expand=True)
    root.mainloop()
