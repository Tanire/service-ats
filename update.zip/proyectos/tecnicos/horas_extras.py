# proyectos/tecnicos/horas_extras.py
"""
Horas Extras - UI integrado para Service ATS v1.10
- No realiza sincronización con Drive (esa responsabilidad la tiene main.py / GoogleDriveSync)
- Diseñado para montarse dentro de un contenedor (no abre nuevas ventanas)
"""

import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime
from pathlib import Path
import os

# Rutas (calculadas relativas al archivo)
PROJECT_ROOT = Path(__file__).resolve().parents[2]
DB_PATH = PROJECT_ROOT / "proyectos" / "tecnicos" / "horas_extras.db"
CONFIG_DB = PROJECT_ROOT / "config" / "config.db"

class HorasExtrasFrame(ttk.Frame):
    def __init__(self, parent, current_user=None):
        super().__init__(parent)
        self.parent = parent
        self.current_user = current_user or {}
        self.username = self.current_user.get("username", "Desconocido")
        self.is_admin = (self.current_user.get("is_admin", 0) == 1)

        # asegurar directorios
        os.makedirs(DB_PATH.parent, exist_ok=True)
        os.makedirs(CONFIG_DB.parent, exist_ok=True)

        self.precio_hora = 0.0
        self.selected_id = None # ID para edición

        # crear tablas si no existen
        self._crear_tablas_locales()

        # obtener precio por hora (desde config)
        self.precio_hora = self._obtener_precio_hora()

        # construir UI (no gestionar pack/grid aquí; lo hará main.py)
        self._crear_interfaz()
        self._cargar_registros_en_tabla()

    # -------------------------
    # BASE DE DATOS (LOCAL)
    # -------------------------
    def _crear_tablas_locales(self):
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute("""
            CREATE TABLE IF NOT EXISTS horas_extras (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                fecha TEXT,
                motivo TEXT,
                cliente TEXT,
                horas REAL,
                total REAL,
                tipo TEXT DEFAULT 'Hora Extra',
                usuario TEXT DEFAULT ''
            )
        """)
        
        # Migración: Añadir columna 'tipo' si no existe
        c.execute("PRAGMA table_info(horas_extras)")
        cols = [info[1] for info in c.fetchall()]
        
        if "tipo" not in cols:
            print("Migrating horas_extras DB: Adding 'tipo' column")
            c.execute("ALTER TABLE horas_extras ADD COLUMN tipo TEXT DEFAULT 'Hora Extra'")

        if "usuario" not in cols:
            print("Migrating horas_extras DB: Adding 'usuario' column")
            c.execute("ALTER TABLE horas_extras ADD COLUMN usuario TEXT DEFAULT ''")

        conn.commit()
        conn.close()

        conn2 = sqlite3.connect(CONFIG_DB)
        c2 = conn2.cursor()
        c2.execute("CREATE TABLE IF NOT EXISTS configuracion (clave TEXT PRIMARY KEY, valor REAL)")
        conn2.commit()
        conn2.close()

    def _obtener_precio_hora(self):
        try:
            conn = sqlite3.connect(CONFIG_DB)
            c = conn.cursor()
            c.execute("SELECT valor FROM configuracion WHERE clave='precio_hora'")
            row = c.fetchone()
            conn.close()
            return float(row[0]) if row else 0.0
        except Exception as e:
            print("Error leyendo precio_hora:", e)
            return 0.0

    def refrescar_precio(self):
        """Llamar si la configuración ha cambiado (por ejemplo desde Configuración)."""
        self.precio_hora = self._obtener_precio_hora()
        # actualizar etiqueta total con 0 o recalculado
        self.total_lbl.config(text="Total: 0.00 €")

    # -------------------------
    # INTERFAZ
    # -------------------------
    def _crear_interfaz(self):
        pad = {"padx": 5, "pady": 5}
        
        # Info usuario
        lbl_info = ttk.Label(self, text=f"Registrando como: {self.username}" + (" (Admin)" if self.is_admin else ""), 
                             font=("Segoe UI", 10, "italic"), foreground="blue")
        lbl_info.grid(row=0, column=0, columnspan=4, sticky="w", padx=10, pady=(5,0))

        # --- Formulario ---
        form_frame = ttk.LabelFrame(self, text="Nuevo Registro", padding=10)
        form_frame.grid(row=1, column=0, columnspan=4, sticky="ew", padx=10, pady=5)
        
        # Fila 1: Fecha y Tipo
        ttk.Label(form_frame, text="Fecha y hora:").grid(row=0, column=0, sticky="w", **pad)
        self.fecha_entry = ttk.Entry(form_frame, width=20)
        self.fecha_entry.insert(0, datetime.now().strftime("%Y-%m-%d %H:%M"))
        self.fecha_entry.grid(row=0, column=1, sticky="w", **pad)
        
        ttk.Label(form_frame, text="Tipo:").grid(row=0, column=2, sticky="w", **pad)
        self.tipo_var = tk.StringVar(value="Hora Extra")
        tipos = ["Hora Extra", "Gasto Material", "Dieta", "Kilometraje", "Parkings/Peajes", "Otros"]
        self.tipo_combo = ttk.Combobox(form_frame, textvariable=self.tipo_var, values=tipos, state="readonly", width=15)
        self.tipo_combo.grid(row=0, column=3, sticky="w", **pad)
        self.tipo_combo.bind("<<ComboboxSelected>>", self._on_tipo_change)

        # Fila 2: Motivo y Cliente
        ttk.Label(form_frame, text="Concepto/Motivo:").grid(row=1, column=0, sticky="w", **pad)
        self.motivo_entry = ttk.Entry(form_frame, width=50)
        self.motivo_entry.grid(row=1, column=1, columnspan=3, sticky="w", **pad)
        
        ttk.Label(form_frame, text="Cliente/Obra:").grid(row=2, column=0, sticky="w", **pad)
        self.cliente_entry = ttk.Entry(form_frame, width=50)
        self.cliente_entry.grid(row=2, column=1, columnspan=3, sticky="w", **pad)

        # Fila 3: Cantidad/Importe
        self.lbl_cantidad = ttk.Label(form_frame, text="Horas:")
        self.lbl_cantidad.grid(row=3, column=0, sticky="w", **pad)
        self.horas_entry = ttk.Entry(form_frame, width=10)
        self.horas_entry.grid(row=3, column=1, sticky="w", **pad)
        
        ttk.Button(form_frame, text="Guardar Registro", command=self.guardar_registro).grid(row=3, column=2, **pad)
        
        self.total_lbl = ttk.Label(form_frame, text="Total: 0.00 €", font=("Segoe UI", 10, "bold"))
        self.total_lbl.grid(row=3, column=3, sticky="w", **pad)

        if self.is_admin:
            ttk.Button(form_frame, text="Eliminar Seleccionado", command=self.eliminar_registro).grid(row=4, column=2, **pad)
            ttk.Button(form_frame, text="Modificar Seleccionado", command=self.cargar_para_editar).grid(row=4, column=3, **pad)
            ttk.Button(form_frame, text="Limpiar Form", command=self._limpiar_campos).grid(row=4, column=0, **pad)

        # --- Filtros y Reportes ---
        filter_frame = ttk.Frame(self)
        filter_frame.grid(row=2, column=0, columnspan=4, sticky="ew", padx=10, pady=(0,5))
        
        ttk.Label(filter_frame, text="Filtrar por Mes:").pack(side="left", padx=5)
        self.filtro_mes = ttk.Combobox(filter_frame, state="readonly", width=15)
        self.filtro_mes.pack(side="left", padx=5)
        self.filtro_mes.bind("<<ComboboxSelected>>", lambda e: self._cargar_registros_en_tabla())
        
        ttk.Button(filter_frame, text="✉ Enviar Reporte por Email", command=self.enviar_reporte).pack(side="right", padx=5)
        ttk.Button(filter_frame, text="Refrescar Precio Hora", command=self.refrescar_precio).pack(side="right", padx=5)

        # Tabla de registros
        # Si es Admin, mostramos columna "Usuario"
        columns = ["fecha", "tipo", "motivo", "cliente", "cantidad", "total"]
        if self.is_admin:
            columns.insert(1, "usuario") # Insertar col usuario
            
        self.tree = ttk.Treeview(self, columns=columns, show="headings", height=12)
        
        self.tree.heading("fecha", text="Fecha")
        self.tree.column("fecha", width=110)
        
        if self.is_admin:
            self.tree.heading("usuario", text="Técnico")
            self.tree.column("usuario", width=120)

        self.tree.heading("tipo", text="Tipo")
        self.tree.column("tipo", width=100)
        
        self.tree.heading("motivo", text="Concepto")
        self.tree.column("motivo", width=200)
        
        self.tree.heading("cliente", text="Cliente")
        self.tree.column("cliente", width=150)
        
        self.tree.heading("cantidad", text="Cant./Horas")
        self.tree.column("cantidad", width=80, anchor="e")
        
        self.tree.heading("total", text="Total (€)")
        self.tree.column("total", width=80, anchor="e")
        
        self.tree.grid(row=3, column=0, columnspan=4, sticky="nsew", padx=10, pady=5)

        # Totales del mes
        self.lbl_sumario = ttk.Label(self, text="Total Mes: 0.00 €", font=("Segoe UI", 12, "bold"))
        self.lbl_sumario.grid(row=4, column=0, columnspan=4, sticky="e", padx=10, pady=10)

        # Layout weights
        self.rowconfigure(3, weight=1)
        self.columnconfigure(1, weight=1)
        
        # Init listeners
        self.horas_entry.bind("<KeyRelease>", self._calcular_preview)
        
        self._actualizar_combo_meses()

    # -------------------------
    # LÓGICA
    # -------------------------
    def _on_tipo_change(self, event=None):
        tipo = self.tipo_var.get()
        if tipo == "Hora Extra":
            self.lbl_cantidad.config(text="Horas:")
        else:
            self.lbl_cantidad.config(text="Importe (€):")
        self._calcular_preview()

    def _calcular_preview(self, event=None):
        try:
            val = float(self.horas_entry.get())
        except:
            self.total_lbl.config(text="Total: - €")
            return 0.0
            
        tipo = self.tipo_var.get()
        if tipo == "Hora Extra":
            total = val * self.precio_hora
            txt = f"{val}h x {self.precio_hora}€/h = {total:.2f} €"
        else:
            total = val
            txt = f"{total:.2f} €"
            
        return total

    def guardar_registro(self):
        fecha = self.fecha_entry.get().strip()
        motivo = self.motivo_entry.get().strip()
        cliente = self.cliente_entry.get().strip()
        tipo = self.tipo_var.get()
        
        try:
            cantidad = float(self.horas_entry.get())
        except ValueError:
            messagebox.showerror("Error", "Debes introducir un número válido.")
            return

        # Calcular total final
        if tipo == "Hora Extra":
            total = cantidad * self.precio_hora
        else:
            total = cantidad

        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            
            if self.selected_id:
                # Actualizar
                c.execute("UPDATE horas_extras SET fecha=?, motivo=?, cliente=?, horas=?, total=?, tipo=? WHERE id=?",
                          (fecha, motivo, cliente, cantidad, total, tipo, self.selected_id))
                messagebox.showinfo("Actualizado", "Registro actualizado.")
            else:
                # Insertar
                c.execute("INSERT INTO horas_extras (fecha, motivo, cliente, horas, total, tipo, usuario) VALUES (?, ?, ?, ?, ?, ?, ?)",
                          (fecha, motivo, cliente, cantidad, total, tipo, self.username))
                messagebox.showinfo("Guardado", "Registro añadido.")
            
            conn.commit()
            conn.close()
        except Exception as e:
            messagebox.showerror("Error BD", f"No se pudo guardar el registro: {e}")
            return

        self._limpiar_campos()
        self._actualizar_combo_meses() # por si es un mes nuevo
        self._cargar_registros_en_tabla()

    def eliminar_registro(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showerror("Error", "Selecciona un registro.")
            return
        
        if not messagebox.askyesno("Confirmar", "¿Eliminar registro?"):
            return

        # Obtener ID desde tag o hidden col?
        # Treeview inserta iid = row[0] (id).
        iid = sel[0]
        try:
            db_id = int(iid)
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            c.execute("DELETE FROM horas_extras WHERE id=?", (db_id,))
            conn.commit()
            conn.close()
            messagebox.showinfo("Eliminado", "Registro eliminado correctamente.")
            self._cargar_registros_en_tabla()
            self._limpiar_campos()
        except Exception as e:
            messagebox.showerror("Error", f"Error al eliminar: {e}")

    def cargar_para_editar(self):
        sel = self.tree.selection()
        if not sel: return
        iid = sel[0]
        # Necesitamos el ID. Modificaremos carga para usar iid=id
        try:
            self.selected_id = int(iid)
        except:
            return

        # Leer valores del tree
        vals = self.tree.item(iid)['values']
        # Admin: 0=fecha, 1=user, 2=tipo, 3=motivo, 4=cliente, 5=horas, 6=total
        
        self.fecha_entry.delete(0, tk.END); self.fecha_entry.insert(0, vals[0])
        self.tipo_var.set(vals[2])
        self.motivo_entry.delete(0, tk.END); self.motivo_entry.insert(0, vals[3])
        self.cliente_entry.delete(0, tk.END); self.cliente_entry.insert(0, vals[4])
        self.horas_entry.delete(0, tk.END); self.horas_entry.insert(0, vals[5])
        self._on_tipo_change() # actualizar label cantidad

    def _limpiar_campos(self):
        self.selected_id = None
        self.motivo_entry.delete(0, tk.END)
        self.cliente_entry.delete(0, tk.END)
        self.horas_entry.delete(0, tk.END)
        self.total_lbl.config(text="Total: 0.00 €")
        # Fecha se mantiene para facilitar entradas consecutivas

    def _actualizar_combo_meses(self):
        # Obtener meses disponibles en BD
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            query = "SELECT DISTINCT substr(fecha, 1, 7) FROM horas_extras"
            
            # Si no es admin, solo mostrar meses donde hay registros del usuario
            if not self.is_admin:
                query += " WHERE usuario=?"
                c.execute(query + " ORDER BY fecha DESC", (self.username,))
            else:
                c.execute(query + " ORDER BY fecha DESC")
                
            meses = [row[0] for row in c.fetchall() if row[0]]
            conn.close()
            
            vals = ["Todos"] + meses
            self.filtro_mes["values"] = vals
            if not self.filtro_mes.get():
                # Seleccionar mes actual por defecto si existe, si no Todos
                curr = datetime.now().strftime("%Y-%m")
                self.filtro_mes.set(curr if curr in meses else "Todos")
        except:
            pass

    def _cargar_registros_en_tabla(self):
        for r in self.tree.get_children():
            self.tree.delete(r)
            
        filtro = self.filtro_mes.get()
        total_acumulado = 0.0
        
        try:
            conn = sqlite3.connect(DB_PATH)
            c = conn.cursor()
            
            # Ajustar SELECT y WHERE según admin y filtro
            # Necesitamos ID para editar/borrar -> SELECT id, ...
            base_cols = "id, fecha, tipo, motivo, cliente, horas, total"
            if self.is_admin:
                base_cols = "id, fecha, usuario, tipo, motivo, cliente, horas, total"
            
            query = f"SELECT {base_cols} FROM horas_extras WHERE 1=1"
            params = []
            
            if not self.is_admin:
                query += " AND usuario=?"
                params.append(self.username)
            
            if filtro and filtro != "Todos":
                query += " AND fecha LIKE ?"
                params.append(f"{filtro}%")
            
            query += " ORDER BY fecha DESC"
            c.execute(query, params)
            rows = c.fetchall()
            conn.close()
            
            for row in rows:
                # row[0] es ID. Usamos iid=str(row[0])
                # values son row[1:]
                self.tree.insert("", tk.END, iid=str(row[0]), values=row[1:])
                # El índice del total varía si insertamos columna usuario
                # Admin: row[7] (total es el ultimo de 8 campos: id, fecha, user, tipo, motivo, cliente, horas, total)
                # User: row[6] ( total es ultimo de 7 campos: id, fecha, tipo, motivo, cliente, horas, total)
                idx_total = 7 if self.is_admin else 6
                total_acumulado += (row[idx_total] if row[idx_total] else 0.0)
                
        except Exception as e:
            print("Error cargando registros:", e)

        self.lbl_sumario.config(text=f"Total Filtrado: {total_acumulado:.2f} €")

    def enviar_reporte(self):
        # Obtener datos actuales de la tabla (solo lo que se ve filtrado)
        items = self.tree.get_children()
        if not items:
            messagebox.showinfo("Información", "No hay datos para reportar.")
            return
            
        filtro = self.filtro_mes.get()
        periodo = filtro if filtro != "Todos" else "Completo"
        
        # Construir cuerpo del correo
        body = f"Reporte de Gastos y Horas - Usuario: {self.username}\n"
        if self.is_admin:
            body += "(Vista Administrador - Todos los usuarios filtrados)\n"
        body += f"Periodo: {periodo}\n\n"
        
        # Header tabla texto
        if self.is_admin:
             body += f"{'FECHA':<16} | {'TECNICO':<15} | {'TIPO':<10} | {'CONCEPTO':<25} | {'TOTAL':>8}\n"
        else:
             body += f"{'FECHA':<18} | {'TIPO':<15} | {'CONCEPTO':<30} | {'TOTAL (€)':>10}\n"
             
        body += "-"*90 + "\n"
        
        total = 0
        for item in items:
            vals = self.tree.item(item)['values']
            # Admin: fecha(0), usuario(1), tipo(2), motivo(3), cliente(4), horas(5), total(6)
            # User:  fecha(0), tipo(1), motivo(2), cliente(3), horas(4), total(5)
            
            if self.is_admin:
                f, u, t, m = str(vals[0]), str(vals[1]), str(vals[2]), str(vals[3])
                imp = float(vals[6])
                body += f"{f:<16} | {u:<15} | {t:<10} | {m:<25} | {imp:>8.2f}\n"
            else:
                f, t, m = str(vals[0]), str(vals[1]), str(vals[2])
                imp = float(vals[5])
                body += f"{f:<18} | {t:<15} | {m:<30} | {imp:>10.2f}\n"

            total += imp
            
        body += "-"*90 + "\n"
        body += f"{'TOTAL':<75} | {total:>10.2f} €\n"
        
        import urllib.parse
        subject = f"Reporte {self.username} - {periodo}"
        safe_subject = urllib.parse.quote(subject)
        safe_body = urllib.parse.quote(body)
        
        import webbrowser
        webbrowser.open(f"mailto:?subject={safe_subject}&body={safe_body}")

# Ejecución standalone para pruebas
if __name__ == "__main__":
    root = tk.Tk()
    root.title("Horas Extras - Prueba")
    root.geometry("900x600")
    frame = HorasExtrasFrame(root)
    frame.pack(expand=True, fill="both")
    root.mainloop()
