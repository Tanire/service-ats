import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import sqlite3
import os
from datetime import datetime
from pathlib import Path
import requests # For OSRM fallback
import openpyxl
try:
    from docx import Document
    from docx.shared import Pt, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    HAS_DOCX = True
except ImportError:
    HAS_DOCX = False



# DB Path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
VALORACIONES_DB = str(PROJECT_ROOT / "tecnicos" / "valoraciones.db")

class ValoracionesApp:
    def __init__(self, parent, current_user=None):
        self.parent = parent
        self.current_user = current_user
        
        # UI
        self.win = ttk.Frame(self.parent)
        self.win.pack(fill="both", expand=True)
        
        # DB Setup
        self._check_db()
        self._crear_tablas()
        
        # Build
        self._build_ui()
        self._cargar_valoraciones()

def ensure_tables():
    os.makedirs(os.path.dirname(VALORACIONES_DB), exist_ok=True)
    conn = sqlite3.connect(VALORACIONES_DB)
    c = conn.cursor()
    
    # Tabla Configuracion Precios
    c.execute("""CREATE TABLE IF NOT EXISTS config_precios (
        clave TEXT PRIMARY KEY,
        valor REAL
    )""")
    # Insertar defaults si vacía
    c.execute("INSERT OR IGNORE INTO config_precios (clave, valor) VALUES ('precio_hora', 30.0)")
    c.execute("INSERT OR IGNORE INTO config_precios (clave, valor) VALUES ('precio_km', 0.35)")
    c.execute("INSERT OR IGNORE INTO config_precios (clave, valor) VALUES ('tiempo_camara', 45)")
    c.execute("INSERT OR IGNORE INTO config_precios (clave, valor) VALUES ('tiempo_grabador', 60)")
    c.execute("INSERT OR IGNORE INTO config_precios (clave, valor) VALUES ('tiempo_sensor', 30)")
    
    # Cabecera Valoracion
    c.execute("""CREATE TABLE IF NOT EXISTS valoraciones (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        cliente TEXT,
        fecha TEXT,
        ubicacion TEXT,
        distancia_km REAL,
        tiempo_viaje_min INTEGER,
        total_material REAL,
        total_mano_obra REAL,
        total_desplazamiento REAL,
        total_global REAL,
        notas TEXT
    )""")
    
    # Detalles (Lineas)
    c.execute("""CREATE TABLE IF NOT EXISTS detalles_valoracion (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        valoracion_id INTEGER,
        articulo TEXT,
        cantidad INTEGER,
        coste_unitario REAL,
        tipo_standar TEXT,
        tiempo_total_min INTEGER,
        FOREIGN KEY(valoracion_id) REFERENCES valoraciones(id)
    )""")
    
    # Tabla Articulos (Base de Datos) - Ampliada
    c.execute("""CREATE TABLE IF NOT EXISTS articulos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT,
        tipo TEXT,
        marca TEXT,
        modelo TEXT,
        ref_proveedor TEXT,
        proveedor TEXT,
        precio_base REAL,
        tiempo_instalacion_min INTEGER
    )""")
    
    # Migracion: Añadir columnas si no existen
    try:
        c.execute("ALTER TABLE articulos ADD COLUMN ref_proveedor TEXT")
    except: pass
    try:
        c.execute("ALTER TABLE articulos ADD COLUMN proveedor TEXT")
    except: pass
    
    
    conn.commit()
    conn.close()

class ValoracionesApp:
    def __init__(self, parent, current_user=None):
        self.parent = parent
        self.current_user = current_user
        
        # UI
        self.win = ttk.Frame(self.parent)
        self.win.pack(fill="both", expand=True)
        
        # DB Setup
        ensure_tables()
        
        # Build
        self._build_ui()
        self._cargar_valoraciones()

    def _check_db(self):
        # Moved to ensure_tables
        pass

    def _crear_tablas(self):
        # Moved to ensure_tables
        pass

    def _build_ui(self):
        # Header
        top_frame = tk.Frame(self.win, bg="#f5f5f5", padx=10, pady=10)
        top_frame.pack(fill="x")
        
        tk.Label(top_frame, text="Valoraciones y Presupuestos", font=("Segoe UI", 16, "bold"), bg="#f5f5f5").pack(side="left")
        
        # Ocultar config aqui, se mueve a Ajustes global pero dejamos funcion por compatibilidad si se requiere
        # tk.Button(top_frame, text="⚙️ Configurar Precios", command=self.abrir_config_precios, bg="#e0e0e0").pack(side="right", padx=5)
        
        tk.Button(top_frame, text="📄 Nueva Valoración", command=self.nueva_valoracion, bg="#4caf50", fg="white").pack(side="right", padx=5)

        # Filtros
        filter_frame = ttk.Frame(self.win, padding=5)
        filter_frame.pack(fill="x")
        
        # Lista
        tree_frame = ttk.Frame(self.win, padding=10)
        tree_frame.pack(fill="both", expand=True)
        
        self.tree = ttk.Treeview(tree_frame, columns=("ID", "Cliente", "Fecha", "Total"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.column("ID", width=50)
        self.tree.heading("Cliente", text="Cliente")
        self.tree.column("Cliente", width=200)
        self.tree.heading("Fecha", text="Fecha")
        self.tree.column("Fecha", width=100)
        self.tree.heading("Total", text="Total (€)")
        self.tree.column("Total", width=100, anchor="e")
        
        self.tree.pack(side="left", fill="both", expand=True)
        
        # Events
        self.tree.bind("<Double-1>", self._on_dbl_click)

    def _cargar_valoraciones(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        conn = sqlite3.connect(VALORACIONES_DB)
        c = conn.cursor()
        c.execute("SELECT id, cliente, fecha, total_global FROM valoraciones ORDER BY id DESC")
        rows = c.fetchall()
        conn.close()
        for r in rows:
            self.tree.insert("", "end", values=r)

    def abrir_config_precios(self):
        # Deprecated local call, now Global
        ConfiguracionProyectos(self.win)

    def nueva_valoracion(self):
        EditorValoracion(self.win, on_close=self._cargar_valoraciones)

    def _on_dbl_click(self, event):
        item = self.tree.selection()
        if not item: return
        val_id = self.tree.item(item, "values")[0]
        EditorValoracion(self.win, val_id=val_id, on_close=self._cargar_valoraciones)


class ConfiguracionProyectos(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.title("Ajustes de Proyectos (Admin)")
        self.geometry("800x600")
        
        ensure_tables()
        
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Tab 1: Precios Generales
        self.tab_precios = ttk.Frame(notebook)
        notebook.add(self.tab_precios, text="Precios y Tiempos Estándar")
        self._build_tab_precios()
        
        # Tab 2: Base de Datos Articulos
        self.tab_db = ttk.Frame(notebook)
        notebook.add(self.tab_db, text="Base de Datos Materiales")
        self._build_tab_db()

    def _build_tab_precios(self):
        pad = {"padx": 5, "pady": 5}
        
        lf_costes = ttk.LabelFrame(self.tab_precios, text="Costes Base", padding=10)
        lf_costes.pack(fill="x", padx=10, pady=5)
        
        ttk.Label(lf_costes, text="Precio Hora M.O. (€):").grid(row=0, column=0, **pad)
        self.ent_precio_hora = ttk.Entry(lf_costes, width=10)
        self.ent_precio_hora.grid(row=0, column=1, **pad)
        
        ttk.Label(lf_costes, text="Precio Kilómetro (€):").grid(row=1, column=0, **pad)
        self.ent_precio_km = ttk.Entry(lf_costes, width=10)
        self.ent_precio_km.grid(row=1, column=1, **pad)
        
        # Tiempos Estándar (Legacy / Info)
        lf_tiempos = ttk.LabelFrame(self.tab_precios, text="Información Tiempos", padding=10)
        lf_tiempos.pack(fill="both", expand=True, padx=10, pady=5)
        
        self.tiempos_frame = ttk.Frame(lf_tiempos)
        self.tiempos_frame.pack(fill="both", expand=True)
        self.entries_tiempos = {} 

        btn_frame = ttk.Frame(self.tab_precios)
        btn_frame.pack(pady=10)
        ttk.Button(btn_frame, text="Guardar Precios", command=self._guardar_precios).pack()
        
        self._cargar_precios()

    def _cargar_precios(self):
        conn = sqlite3.connect(VALORACIONES_DB)
        c = conn.cursor()
        c.execute("SELECT clave, valor FROM config_precios")
        data = {k: v for k, v in c.fetchall()}
        conn.close()
        
        self.ent_precio_hora.delete(0, tk.END); self.ent_precio_hora.insert(0, data.get("precio_hora", 0))
        self.ent_precio_km.delete(0, tk.END); self.ent_precio_km.insert(0, data.get("precio_km", 0))
        
        keys_tiempos = [k for k in data.keys() if k.startswith("tiempo_")]
            
        # ELIMINADO: Grid dinámico de Tiempos (ahora se gestiona por artículo)
        # Se mantiene visualización solo informativa o se elimina del todo.
        # Eliminando interfaz de tiempos estandard
        for w in self.tiempos_frame.winfo_children(): w.destroy()
        ttk.Label(self.tiempos_frame, text="Los tiempos de instalación se definen\ahora individualmente en la Base de Datos de Artículos.", 
                  foreground="gray").pack(pady=20)

    def _guardar_precios(self):
        try:
            conn = sqlite3.connect(VALORACIONES_DB)
            c = conn.cursor()
            ph = float(self.ent_precio_hora.get().replace(",", "."))
            pkm = float(self.ent_precio_km.get().replace(",", "."))
            c.execute("UPDATE config_precios SET valor=? WHERE clave='precio_hora'", (ph,))
            c.execute("UPDATE config_precios SET valor=? WHERE clave='precio_km'", (pkm,))
            conn.commit(); conn.close()
            messagebox.showinfo("Guardado", "Precios actualizados.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _build_tab_db(self):
        # Filtros
        f_filtros = ttk.Frame(self.tab_db)
        f_filtros.pack(fill="x", padx=5, pady=5)
        ttk.Label(f_filtros, text="Buscar:").pack(side="left")
        self.ent_busq_db = ttk.Entry(f_filtros)
        self.ent_busq_db.pack(side="left", fill="x", expand=True, padx=5)
        ttk.Button(f_filtros, text="🔍", command=self._cargar_articulos).pack(side="left")
        
        # Tabla
        cols = ("ID", "Nombre", "Tipo", "Marca", "Modelo", "Ref. Prov", "Proveedor", "Precio", "Tiempo(min)")
        self.tree_db = ttk.Treeview(self.tab_db, columns=cols, show="headings")
        for c in cols: self.tree_db.heading(c, text=c); self.tree_db.column(c, width=100)
        self.tree_db.column("Nombre", width=150)
        self.tree_db.column("Marca", width=80)
        self.tree_db.column("Modelo", width=80)
        self.tree_db.pack(fill="both", expand=True, padx=5)
        
        # Botones CRUD
        f_btns = ttk.Frame(self.tab_db)
        f_btns.pack(fill="x", pady=5)

        # Verificar permisos (add_articles)
        # self.parent es ServiceATSApp
        curr_user = self.parent.current_user
        is_admin = curr_user.get("is_admin", 0) == 1
        perms = curr_user.get("permissions", [])
        # Permiso: Admin, 'all', o 'add_articles'
        can_edit = is_admin or "all" in perms or "add_articles" in perms
        
        state_btn = "normal" if can_edit else "disabled"

        ttk.Button(f_btns, text="➕ Nuevo Artículo", command=self._nuevo_articulo, state=state_btn).pack(side="left", padx=5)
        ttk.Button(f_btns, text="✏️ Editar", command=self._editar_articulo, state=state_btn).pack(side="left", padx=5)
        ttk.Button(f_btns, text="❌ Eliminar", command=self._eliminar_articulo, state=state_btn).pack(side="left", padx=5)
        
        ttk.Separator(f_btns, orient="vertical").pack(side="left", padx=10, fill="y")
        
        ttk.Button(f_btns, text="📥 Importar Excel", command=self._importar_excel, state=state_btn).pack(side="left", padx=5)
        ttk.Button(f_btns, text="📤 Exportar Excel", command=self._exportar_excel).pack(side="left", padx=5)
        
        self._cargar_articulos()

    def _cargar_articulos(self):
        busq = self.ent_busq_db.get().strip()
        for i in self.tree_db.get_children(): self.tree_db.delete(i)
        
        conn = sqlite3.connect(VALORACIONES_DB)
        c = conn.cursor()
        query = "SELECT * FROM articulos WHERE nombre LIKE ? OR tipo LIKE ? OR marca LIKE ?"
        param = f"%{busq}%"
        c.execute(query, (param, param, param))
        rows = c.fetchall()
        conn.close()
        for r in rows:
            self.tree_db.insert("", "end", values=r)

    def _nuevo_articulo(self):
        self._editor_dialog()

    def _editar_articulo(self):
        sel = self.tree_db.selection()
        if not sel: return
        item_id = self.tree_db.item(sel[0], "values")[0]
        
        conn = sqlite3.connect(VALORACIONES_DB)
        conn.row_factory = sqlite3.Row
        c = conn.cursor()
        c.execute("SELECT * FROM articulos WHERE id=?", (item_id,))
        row = c.fetchone()
        conn.close()
        
        if row:
            self._editor_dialog(dict(row))

    def _eliminar_articulo(self):
        sel = self.tree_db.selection()
        if not sel: return
        msg = messagebox.askyesno("Confirmar", "¿Eliminar artículo seleccionado?")
        if msg:
            aid = self.tree_db.item(sel[0], "values")[0]
            conn = sqlite3.connect(VALORACIONES_DB)
            conn.cursor().execute("DELETE FROM articulos WHERE id=?", (aid,))
            conn.commit(); conn.close()
            self._cargar_articulos()

    def _editor_dialog(self, data=None):
        dlg = tk.Toplevel(self)
        dlg.title("Editor Artículo")
        dlg.geometry("450x450") # Asegurar tamaño suficiente (+50 px)
        
        # Frame botonera (Pack bottom FIRST to reserve space)
        btn_frame = ttk.Frame(dlg, padding=10)
        btn_frame.pack(fill="x", side="bottom")

        # Frame para inputs (Grid) - Pack AFTER bottom
        input_frame = ttk.Frame(dlg, padding=10)
        input_frame.pack(fill="both", expand=True)

        fields = ["Nombre", "Tipo", "Marca", "Modelo", "Ref. Prov", "Proveedor", "Precio Base (€)", "Tiempo (min)"]
        entries = {}
        for i, f in enumerate(fields):
            label = ttk.Label(input_frame, text=f)
            label.grid(row=i, column=0, sticky="w", padx=5, pady=5)
            
            if f == "Tipo":
                # Combobox para Tipo
                e = ttk.Combobox(input_frame, width=33, values=["CCTV", "INTRUSION", "INCENDIO", "CCAA", "OTROS"])
                e.grid(row=i, column=1, sticky="ew", padx=5, pady=5)
            else:
                e = ttk.Entry(input_frame, width=35)
                e.grid(row=i, column=1, sticky="ew", padx=5, pady=5)
            
            entries[f] = e
            
        # Configurar grid weight
        input_frame.columnconfigure(1, weight=1)
            
        if data:
            entries["Nombre"].insert(0, data.get("nombre", ""))
            
            # Tipo es Combobox
            entries["Tipo"].set(data.get("tipo", "")) # Combobox uses set, or insert works if not readonly, but set is safer
            
            entries["Marca"].insert(0, data.get("marca", ""))
            entries["Modelo"].insert(0, data.get("modelo", ""))
            entries["Ref. Prov"].insert(0, data.get("ref_proveedor", ""))
            entries["Proveedor"].insert(0, data.get("proveedor", ""))
            entries["Precio Base (€)"].insert(0, data.get("precio_base", 0))
            entries["Tiempo (min)"].insert(0, data.get("tiempo_instalacion_min", 0))
            
        def _save():
            try:
                nom = entries["Nombre"].get()
                tip = entries["Tipo"].get()
                mar = entries["Marca"].get()
                mod = entries["Modelo"].get()
                ref = entries["Ref. Prov"].get()
                prov = entries["Proveedor"].get()
                
                # Validación segura de números
                val_precio = entries["Precio Base (€)"].get().replace(",", ".").strip()
                val_tiempo = entries["Tiempo (min)"].get().strip()
                
                try:
                    pre = float(val_precio) if val_precio else 0.0
                except ValueError:
                    messagebox.showerror("Error", "El Precio debe ser un número válido.")
                    return
                    
                try:
                    tie = int(val_tiempo) if val_tiempo else 0
                except ValueError:
                    messagebox.showerror("Error", "El Tiempo debe ser un número entero (minutos).")
                    return
                
                conn = sqlite3.connect(VALORACIONES_DB)
                c = conn.cursor()
                if data: # Update
                    c.execute("""UPDATE articulos SET 
                        nombre=?, tipo=?, marca=?, modelo=?, ref_proveedor=?, proveedor=?, 
                        precio_base=?, tiempo_instalacion_min=? WHERE id=?""", 
                              (nom, tip, mar, mod, ref, prov, pre, tie, data["id"]))
                else: # Insert
                    c.execute("""INSERT INTO articulos 
                        (nombre, tipo, marca, modelo, ref_proveedor, proveedor, precio_base, tiempo_instalacion_min) 
                        VALUES (?,?,?,?,?,?,?,?)""", 
                              (nom, tip, mar, mod, ref, prov, pre, tie))
                
                conn.commit()
                conn.close()
                self._cargar_articulos()
                dlg.destroy()
                messagebox.showinfo("Guardar", "Artículo guardado correctamente.")
                
            except Exception as e:
                import traceback
                traceback.print_exc()
                messagebox.showerror("Error Guardando", f"Ocurrió un error inesperado:\n{e}")
        
        ttk.Button(btn_frame, text="💾 GUARDAR", command=_save).pack(fill="x", ipady=5)

    def _exportar_excel(self):
        try:
            conn = sqlite3.connect(VALORACIONES_DB)
            c = conn.cursor()
            c.execute("SELECT nombre, tipo, marca, modelo, ref_proveedor, proveedor, precio_base, tiempo_instalacion_min FROM articulos")
            rows = c.fetchall()
            conn.close()
            
            f = tk.filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
            if not f: return
            
            wb = openpyxl.Workbook()
            ws = wb.active
            headers = ["Nombre", "Tipo", "Marca", "Modelo", "Ref_Prov", "Proveedor", "Precio", "Tiempo_Min"]
            ws.append(headers)
            
            for r in rows:
                ws.append(r)
                
            wb.save(f)
            messagebox.showinfo("Exportar", "Datos exportados correctamente.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _importar_excel(self):
        msg = "El Excel debe tener estas columnas (orden indistinto si usas cabecera, o este orden si no):\n"
        msg += "Nombre, Tipo, Marca, Modelo, Ref_Prov, Proveedor, Precio, Tiempo_Min\n\n"
        msg += "¿Continuar importando?"
        if not messagebox.askyesno("Info", msg): return
        
        f = tk.filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx")])
        if not f: return
        
        try:
            wb = openpyxl.load_workbook(f)
            ws = wb.active
            
            # Simple assumption: Row 1 headers, Data from Row 2
            # Mapping columns by index for simplicity based on required format
            # Or try to find headers
            
            headers_map = {}
            for cell in ws[1]:
                if cell.value:
                    h = str(cell.value).lower().strip()
                    headers_map[h] = cell.column - 1
            
            # Required keys mapping
            required = {
                "nombre": ["nombre", "name", "producto"],
                "tipo": ["tipo", "type", "familia"],
                "marca": ["marca", "brand"],
                "modelo": ["modelo", "model"],
                "ref_proveedor": ["ref", "referencia", "ref_prov"],
                "proveedor": ["proveedor", "supplier"],
                "precio_base": ["precio", "price", "pvp", "coste"],
                "tiempo_instalacion_min": ["tiempo", "time", "minutos"]
            }
            
            col_indices = {}
            for k, aliases in required.items():
                col_indices[k] = -1
                for alias in aliases:
                    for h_txt, h_idx in headers_map.items():
                        if alias in h_txt:
                            col_indices[k] = h_idx
                            break
                    if col_indices[k] != -1: break
            
            conn = sqlite3.connect(VALORACIONES_DB)
            c = conn.cursor()
            
            count = 0
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row[0]: continue # Skip empty rows
                
                # Helper to get val safely
                def get_val(key, default):
                    idx = col_indices.get(key, -1)
                    if idx != -1 and idx < len(row):
                        return row[idx]
                    return default
                    
                nombre = get_val("nombre", "") or "Nuevo Articulo"
                tipo = get_val("tipo", "")
                marca = get_val("marca", "")
                modelo = get_val("modelo", "")
                ref = get_val("ref_proveedor", "")
                prov = get_val("proveedor", "")
                
                try:
                    p_val = get_val("precio_base", 0)
                    precio = float(p_val) if p_val else 0.0
                except: precio = 0.0
                
                try:
                    t_val = get_val("tiempo_instalacion_min", 0)
                    tiempo = int(t_val) if t_val else 0
                except: tiempo = 0
                
                # Check duplicate strategy:
                # Priority: 1. Ref, 2. Modelo, 3. Nombre
                existing_id = None
                
                # 1. Por Referencia (Si existe)
                if ref:
                    c.execute("SELECT id FROM articulos WHERE ref_proveedor=?", (ref,))
                    row_data = c.fetchone()
                    if row_data: existing_id = row_data[0]
                
                # 2. Por Modelo (Si no encontrado y hay modelo)
                if not existing_id and modelo:
                    c.execute("SELECT id FROM articulos WHERE modelo=?", (modelo,))
                    row_data = c.fetchone()
                    if row_data: existing_id = row_data[0]
                    
                # 3. Por Nombre (Exacto) + Marca (Si existe)
                if not existing_id and nombre:
                    # Intentar acotar con marca si la tenemos
                    sql = "SELECT id FROM articulos WHERE nombre=?"
                    params = [nombre]
                    if marca:
                        sql += " AND marca=?"
                        params.append(marca)
                    
                    c.execute(sql, tuple(params))
                    row_data = c.fetchone()
                    if row_data: existing_id = row_data[0]
                
                if existing_id:
                    # Update
                     c.execute("""UPDATE articulos SET 
                        nombre=?, tipo=?, marca=?, modelo=?, ref_proveedor=?, proveedor=?, 
                        precio_base=?, tiempo_instalacion_min=? WHERE id=?""", 
                              (nombre, tipo, marca, modelo, ref, prov, precio, tiempo, existing_id))
                else:
                    c.execute("""INSERT INTO articulos 
                        (nombre, tipo, marca, modelo, ref_proveedor, proveedor, precio_base, tiempo_instalacion_min) 
                        VALUES (?,?,?,?,?,?,?,?)""", 
                              (nombre, tipo, marca, modelo, ref, prov, precio, tiempo))
                count += 1
                
            conn.commit(); conn.close()
            self._cargar_articulos()
            messagebox.showinfo("Importar", f"Proceso finalizado. {count} registros procesados.")
            
        except Exception as e:
            messagebox.showerror("Error", f"Error importando: {e}")


class SelectorArticulos(tk.Toplevel):
    def __init__(self, parent, callback):
        super().__init__(parent)
        self.title("Buscar Artículo")
        self.geometry("600x400")
        self.callback = callback
        
        # Filtros
        f_top = ttk.Frame(self)
        f_top.pack(fill="x", padx=5, pady=5)
        
        self.ent_search = ttk.Entry(f_top)
        self.ent_search.pack(side="left", fill="x", expand=True)
        self.ent_search.bind("<Return>", lambda e: self._buscar())
        ttk.Button(f_top, text="Buscar", command=self._buscar).pack(side="left", padx=5)
        
        # Tabla
        cols = ("Nombre", "Tipo", "Marca", "Modelo", "Precio", "Tiempo")
        self.tree = ttk.Treeview(self, columns=cols, show="headings")
        for c in cols: self.tree.heading(c, text=c); self.tree.column(c, width=80)
        self.tree.column("Nombre", width=150)
        self.tree.pack(fill="both", expand=True, padx=5, pady=5)
        self.tree.bind("<Double-1>", self._seleccionar)
        
        self._buscar()
        
    def _buscar(self):
        q = self.ent_search.get()
        for i in self.tree.get_children(): self.tree.delete(i)
        conn = sqlite3.connect(VALORACIONES_DB)
        query = "SELECT nombre, tipo, marca, modelo, precio_base, tiempo_instalacion_min FROM articulos WHERE nombre LIKE ? OR marca LIKE ? OR tipo LIKE ?"
        p = f"%{q}%"
        rows = conn.cursor().execute(query, (p, p, p)).fetchall()
        conn.close()
        for r in rows: self.tree.insert("", "end", values=r)

    def _seleccionar(self, event):
        sel = self.tree.selection()
        if not sel: return
        vals = self.tree.item(sel[0], "values")
        # vals: Nom, Tip, Mar, Mod, Pre, Tie
        res = {
            "nombre": vals[0], "tipo": vals[1], "marca": vals[2], "modelo": vals[3],
            "precio": vals[4], "tiempo": vals[5]
        }
        self.callback(res)
        self.destroy()


class EditorValoracion(tk.Toplevel):
    def __init__(self, parent, val_id=None, on_close=None):
        super().__init__(parent)
        self.title("Editor de Valoración")
        self.state("zoomed")
        self.val_id = val_id
        self.on_close_cb = on_close
        
        self.items = [] # List of dicts: {articulo, cant, coste, tipo, tiempo, total_mat, total_mo}
        
        self._cargar_config()
        self._crear_ui()
        if val_id:
            self._cargar_datos()

    def _cargar_config(self):
        conn = sqlite3.connect(VALORACIONES_DB)
        c = conn.cursor()
        c.execute("SELECT clave, valor FROM config_precios")
        self.precios = {k: v for k, v in c.fetchall()}
        conn.close()

    def _crear_ui(self):
        # --- HEADER ---
        header_frame = ttk.LabelFrame(self, text="Datos Generales", padding=10)
        header_frame.pack(fill="x", padx=10, pady=5)
        
        # Fila 1: Cliente y Fecha
        ttk.Label(header_frame, text="Cliente:").grid(row=0, column=0, sticky="e")
        self.ent_cliente = ttk.Entry(header_frame, width=40)
        self.ent_cliente.grid(row=0, column=1, sticky="w", padx=5)
        
        ttk.Label(header_frame, text="Fecha:").grid(row=0, column=2, sticky="e")
        self.ent_fecha = ttk.Entry(header_frame, width=15)
        self.ent_fecha.insert(0, datetime.now().strftime("%Y-%m-%d"))
        self.ent_fecha.grid(row=0, column=3, sticky="w", padx=5)
        
        # Fila 2: Ubicación y Desplazamiento
        ttk.Label(header_frame, text="Ubicación:").grid(row=1, column=0, sticky="e", pady=10)
        self.ent_ubicacion = ttk.Entry(header_frame, width=40)
        self.ent_ubicacion.grid(row=1, column=1, sticky="w", padx=5)
        
        ttk.Button(header_frame, text="📍 Seleccionar / Calcular Ruta", command=self._abrir_selector_ubicacion).grid(row=1, column=2, columnspan=2, sticky="w", padx=5)
        
        # Info Desplazamiento
        self.lbl_distancia = ttk.Label(header_frame, text="Distancia: 0 km")
        self.lbl_distancia.grid(row=2, column=1, sticky="w", padx=5)
        self.lbl_tiempo_viaje = ttk.Label(header_frame, text="Tiempo Viaje: 0 min (ida)")
        self.lbl_tiempo_viaje.grid(row=2, column=2, sticky="w", padx=5)
        
        self.distancia_km = 0.0
        self.tiempo_viaje_min = 0

        # --- BODY (MATERIALES) ---
        body_frame = ttk.Frame(self)
        body_frame.pack(fill="both", expand=True, padx=10, pady=5)
        
        # Formulario Añadir
        add_frame = ttk.LabelFrame(body_frame, text="Añadir Material / Sistema", padding=5)
        add_frame.pack(fill="x", pady=5)
        
        ttk.Label(add_frame, text="Artículo:").pack(side="left")
        self.ent_art = ttk.Entry(add_frame, width=30)
        self.ent_art.pack(side="left", padx=5)
        
        # Boton buscar (Lupa)
        ttk.Button(add_frame, text="🔍", width=3, command=self._buscar_articulo).pack(side="left", padx=2)
        
        ttk.Label(add_frame, text="Cant:").pack(side="left")
        self.ent_cant = ttk.Entry(add_frame, width=5)
        self.ent_cant.pack(side="left", padx=5)
        
        ttk.Label(add_frame, text="Coste Unit (€):").pack(side="left")
        self.ent_coste = ttk.Entry(add_frame, width=8)
        self.ent_coste.pack(side="left", padx=5)
        
        ttk.Label(add_frame, text="Tipo (Estándar):").pack(side="left")
        # Obtener claves de tiempos para combobox
        tipos_disponibles = [k.replace("tiempo_", "").capitalize() for k in self.precios.keys() if k.startswith("tiempo_")]
        self.cb_tipo = ttk.Combobox(add_frame, values=tipos_disponibles, state="readonly", width=15)
        self.cb_tipo.pack(side="left", padx=5)
        
        ttk.Button(add_frame, text="➕ Añadir", command=self._add_item).pack(side="left", padx=10)
        ttk.Button(add_frame, text="✏️ Modificar", command=self._edit_item).pack(side="left", padx=5)
        ttk.Button(add_frame, text="❌ Borrar Seleccionado", command=self._del_item).pack(side="left")
        
        # Tabla
        cols = ("Articulo", "Cant", "Coste U.", "Tipo", "M.O. Calc (min)", "Total Mat (€)", "Total M.O. (€)")
        self.tree_items = ttk.Treeview(body_frame, columns=cols, show="headings", height=10)
        for c in cols: self.tree_items.heading(c, text=c)
        self.tree_items.column("Articulo", width=200)
        self.tree_items.column("Cant", width=50)
        
        self.tree_items.pack(side="left", fill="both", expand=True)
        self.tree_items.bind("<Double-1>", lambda e: self._edit_item())
        
        vsb = ttk.Scrollbar(body_frame, orient="vertical", command=self.tree_items.yview)
        vsb.pack(side="right", fill="y")
        self.tree_items.configure(yscrollcommand=vsb.set)
        
        # --- FOOTER (TOTALES) ---
        footer_frame = ttk.LabelFrame(self, text="Resumen Económico", padding=10)
        footer_frame.pack(fill="x", padx=10, pady=10)
        
        lbl_font = ("Segoe UI", 10)
        val_font = ("Segoe UI", 10, "bold")
        
        tk.Label(footer_frame, text="Total Materiales:", font=lbl_font).grid(row=0, column=0, sticky="e")
        self.lbl_tot_mat = tk.Label(footer_frame, text="0.00 €", font=val_font, fg="#333")
        self.lbl_tot_mat.grid(row=0, column=1, sticky="w", padx=10)
        
        tk.Label(footer_frame, text="Total Mano de Obra (Instalación):", font=lbl_font).grid(row=1, column=0, sticky="e")
        self.lbl_tot_mo = tk.Label(footer_frame, text="0.00 €", font=val_font, fg="#1976d2")
        self.lbl_tot_mo.grid(row=1, column=1, sticky="w", padx=10)
        
        tk.Label(footer_frame, text="Total Desplazamiento (Km + Tiempo):", font=lbl_font).grid(row=2, column=0, sticky="e")
        self.lbl_tot_desp = tk.Label(footer_frame, text="0.00 €", font=val_font, fg="#e65100")
        self.lbl_tot_desp.grid(row=2, column=1, sticky="w", padx=10)
        
        tk.Label(footer_frame, text="TOTAL PRESUPUESTO:", font=("Segoe UI", 14, "bold")).grid(row=0, column=2, rowspan=3, padx=40)
        self.lbl_gran_total = tk.Label(footer_frame, text="0.00 €", font=("Segoe UI", 20, "bold"), fg="#2e7d32")
        self.lbl_gran_total.grid(row=0, column=3, rowspan=3)

        # Botonera Final
        bf = ttk.Frame(self)
        bf.pack(pady=10)
        
        ttk.Button(bf, text="💾 GUARDAR VALORACIÓN", command=self._guardar_todo).pack(side="left", padx=10, ipadx=10)
        
        ttk.Separator(bf, orient="vertical").pack(side="left", fill="y", padx=10)
        
        ttk.Button(bf, text="📄 Exportar Word", command=self._exportar_word).pack(side="left", padx=5)
        ttk.Button(bf, text="📊 Exportar Excel", command=self._exportar_excel).pack(side="left", padx=5)

    def _exportar_excel(self):
        if not hasattr(self, "current_totals"): self._recalcular_totales()
        
        f = tk.filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")],
                                            initialfile=f"Presupuesto {self.ent_cliente.get()}.xlsx")
        if not f: return
        
        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Presupuesto"
            
            # Header Info
            ws["A1"] = "Software ATS - Presupuesto"
            ws["A1"].font = openpyxl.styles.Font(bold=True, size=14)
            ws["A3"] = f"Cliente: {self.ent_cliente.get()}"
            ws["A4"] = f"Fecha: {self.ent_fecha.get()}"
            ws["A5"] = f"Ubicación: {self.ent_ubicacion.get()}"
            
            # Table Header
            headers = ["Artículo", "Cant", "Precio U.", "Tipo", "Total Mat", "Total M.O."]
            for col, h in enumerate(headers, 1):
                c = ws.cell(row=7, column=col, value=h)
                c.font = openpyxl.styles.Font(bold=True)
                c.border = openpyxl.styles.Border(bottom=openpyxl.styles.Side(style='thin'))
            
            # Items
            r = 8
            for i in self.items:
                ws.cell(row=r, column=1, value=i["articulo"])
                ws.cell(row=r, column=2, value=i["cant"])
                ws.cell(row=r, column=3, value=float(i["coste_unit"]))
                ws.cell(row=r, column=4, value=i["tipo"])
                ws.cell(row=r, column=5, value=i["total_mat"])
                ws.cell(row=r, column=6, value=i["total_mo"])
                r += 1
                
            # Totals
            r += 2
            ws.cell(row=r, column=5, value="Materiales:").font = openpyxl.styles.Font(bold=True)
            ws.cell(row=r, column=6, value=self.current_totals["mat"])
            r += 1
            ws.cell(row=r, column=5, value="Mano de Obra:").font = openpyxl.styles.Font(bold=True)
            ws.cell(row=r, column=6, value=self.current_totals["mo"])
            r += 1
            ws.cell(row=r, column=5, value="Desplazamiento:").font = openpyxl.styles.Font(bold=True)
            ws.cell(row=r, column=6, value=self.current_totals["desp"])
            r += 1
            ws.cell(row=r, column=5, value="TOTAL:").font = openpyxl.styles.Font(bold=True, size=12)
            c = ws.cell(row=r, column=6, value=self.current_totals["global"])
            c.font = openpyxl.styles.Font(bold=True, size=12)
            
            wb.save(f)
            messagebox.showinfo("Exportar", "Presupuesto exportado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _exportar_word(self):
        if not HAS_DOCX:
            messagebox.showerror("Error", "La librería 'python-docx' no está instalada.\nNo se puede generar el informe Word.")
            return

        if not hasattr(self, "current_totals"): self._recalcular_totales()
        
        f = tk.filedialog.asksaveasfilename(defaultextension=".docx", filetypes=[("Word", "*.docx")],
                                            initialfile=f"Presupuesto {self.ent_cliente.get()}.docx")
        if not f: return
        
        try:
            doc = Document()
            
            # Logo (Try to find assets/logo.png or ignore)
            logo_path = os.path.join(str(PROJECT_ROOT), "assets", "logo_empresa.png")
            if os.path.exists(logo_path):
                try:
                    doc.add_picture(logo_path, width=Cm(6))
                except: pass
            
            # Title
            h = doc.add_heading(f"Presupuesto: {self.ent_cliente.get()}", 0)
            h.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # Info
            p = doc.add_paragraph()
            p.add_run(f"Fecha: {self.ent_fecha.get()}\n").bold = True
            p.add_run(f"Ubicación: {self.ent_ubicacion.get()}")
            
            doc.add_heading("Detalle de Valoración", level=2)
            
            # Table
            table = doc.add_table(rows=1, cols=4)
            table.style = 'Table Grid'
            hdr = table.rows[0].cells
            hdr[0].text = "Descripción"
            hdr[1].text = "Cant"
            hdr[2].text = "Precio Unit."
            hdr[3].text = "Total"
            
            for item in self.items:
                row = table.add_row().cells
                row[0].text = item["articulo"]
                row[1].text = str(item["cant"])
                row[2].text = f"{item['coste_unit']:.2f} €"
                # Total line (Mat + MO for that item? or separates? User usually wants total per line item including MO or just Mat?)
                # Standard budget usually shows Price Unit and Total Price.
                # Here we have item total cost (mat + mo). Let's show Mat Cost for now or just item Total.
                # Let's show Total Mat for simplicity as standard budget item line.
                row[3].text = f"{item['total_mat']:.2f} €"
                
            # Totals
            doc.add_paragraph("\n")
            tp = doc.add_paragraph()
            tp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            tp.add_run(f"Total Materiales: {self.current_totals['mat']:.2f} €\n")
            tp.add_run(f"Mano de Obra (Instalación): {self.current_totals['mo']:.2f} €\n")
            tp.add_run(f"Desplazamiento y Viaje: {self.current_totals['desp']:.2f} €\n")
            run = tp.add_run(f"TOTAL PRESUPUESTO: {self.current_totals['global']:.2f} €")
            run.bold = True
            run.font.size = Pt(14)
            
            doc.save(f)
            messagebox.showinfo("Exportar", "Informe Word generado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def _abrir_selector_ubicacion(self):
        # Importar y abrir Kilometrajes en modo selector
        # Como KilometrajesApp es un Frame, lo instanciamos en un Toplevel
        top = tk.Toplevel(self)
        top.title("Seleccionar Destino")
        top.geometry("1000x700")
        
        from proyectos.kilometrajes import KilometrajesApp
        app = KilometrajesApp(top, current_user=self.master.current_user if hasattr(self.master, "current_user") else None)
        
        # Inyectar boton de seleccion
        def _seleccionar():
            sel = app.tree.selection()
            if not sel: return
            vals = app.tree.item(sel[0], "values")
            # Vals: (Busq, Dir, CP, Dist, Time, Lat, Lon)
            
            addr = vals[1]
            try:
                # Si no hay distancia calculada, intentamos calcularla aqui si tenemos origen
                dist_str = str(vals[3])
                if (dist_str == "---" or dist_str == "0.0") and app.mi_ubicacion and vals[5] and vals[6]:
                    try:
                        orig_lat = app.mi_ubicacion["lat"]
                        orig_lon = app.mi_ubicacion["lon"]
                        dest_lat = vals[5]
                        dest_lon = vals[6]
                        
                        # OSRM Call
                        url = f"http://router.project-osrm.org/route/v1/driving/{orig_lon},{orig_lat};{dest_lon},{dest_lat}?overview=false"
                        r = requests.get(url, timeout=3)
                        data = r.json()
                        if data.get("code") == "Ok" and data.get("routes"):
                            route = data["routes"][0]
                            dist_km = route["distance"] / 1000
                            dur_s = route["duration"]
                            
                            hours = int(dur_s // 3600)
                            mm = int((dur_s % 3600) // 60)
                            time_str = f"{hours}h {mm}m" if hours > 0 else f"{mm}m"
                            
                            # Update Vals mimic
                            vals = list(vals)
                            vals[3] = f"{dist_km:.2f}"
                            vals[4] = time_str
                    except Exception as e:
                        print(f"Fallback OSRM failed: {e}")

                dist = float(vals[3]) if vals[3] != "---" else 0.0
                # Parsear tiempo "1h 30m" o "45m"
                t_str = vals[4]
                mins = 0
                if "h" in t_str:
                    parts = t_str.split("h")
                    mins += int(parts[0]) * 60
                    if "m" in parts[1]:
                        mins += int(parts[1].replace("m","").strip())
                elif "m" in t_str:
                    mins += int(t_str.replace("m","").strip())
                    
                self.ent_ubicacion.delete(0, tk.END)
                self.ent_ubicacion.insert(0, addr)
                self.distancia_km = dist
                self.tiempo_viaje_min = mins
                
                self.lbl_distancia.config(text=f"Distancia: {dist} km")
                self.lbl_tiempo_viaje.config(text=f"Tiempo Viaje: {mins} min (ida)")
                
                self._recalcular_totales()
                top.destroy()
            except Exception as e:
                messagebox.showerror("Error", f"Datos de ruta inválidos (calcula la ruta primero en la lista).\n{e}")

        btn_sel = tk.Button(top, text="✅ USAR ESTA UBICACIÓN (Calcula Ruta Auto)", bg="#66bb6a", fg="white", font=("Segoe UI", 12, "bold"), command=_seleccionar)
        btn_sel.pack(side="bottom", fill="x", pady=10)

    def _buscar_articulo(self):
        def _on_sel(item):
            # item: {nombre, tipo, marca, modelo, precio, tiempo}
            self.ent_art.delete(0, tk.END)
            self.ent_art.insert(0, item["nombre"])
            
            self.ent_coste.delete(0, tk.END)
            self.ent_coste.insert(0, str(item["precio"]))
            
            # Guardamos el tiempo especifico para usarlo en _add_item
            self.selected_item_time = item["tiempo"]
            
            # Intentar seleccionar Tipo
            if item["tipo"]:
                # Normalizar para buscar en combobox
                target = item["tipo"].replace("tiempo_", "").capitalize()
                if target in self.cb_tipo["values"]:
                    self.cb_tipo.set(target)
                else:
                    # Si no esta en la lista, quizás es nuevo, pero intentamos machear
                    pass
            
            self.ent_cant.focus()
            
        selector = SelectorArticulos(self, _on_sel)
        
    def _add_item(self):
        art = self.ent_art.get()
        cant = self.ent_cant.get()
        coste = self.ent_coste.get()
        tipo = self.cb_tipo.get()
        
        if not art or not cant: return
        
        try:
            cant = int(cant)
            coste = float(coste.replace(",", ".") or 0)
        except:
            return
            
            
        # Prioridad: Tiempo específico del artículo > Tiempo estándar global > 0
        if hasattr(self, "selected_item_time") and self.selected_item_time is not None:
             try:
                 std_time = float(self.selected_item_time)
             except:
                 std_time = 0.0
             # Reset para el siguiente
             self.selected_item_time = None
        else:
             try:
                 std_time = float(self.precios.get(f"tiempo_{tipo.lower()}", 0))
             except:
                 std_time = 0.0

        total_time_min = cant * std_time
        
        try:
            ph = float(self.precios.get("precio_hora", 30))
        except: ph = 30.0
            
        mo_coste = (total_time_min / 60) * ph
        mat_coste = cant * coste
        
        item = {
            "articulo": art,
            "cant": cant,
            "coste_unit": coste,
            "tipo": tipo,
            "tiempo_std": std_time,
            "total_mo": mo_coste,
            "total_mat": mat_coste,
            "tiempo_total": total_time_min
        }
        
        self.items.append(item)
        self._refresh_table()
        
        # Clear inputs
        self.ent_art.delete(0, tk.END)
        self.ent_cant.delete(0, tk.END)
        # self.ent_coste.delete(0, tk.END) # keep cost maybe?

        # self.ent_coste.delete(0, tk.END) # keep cost maybe?

    def _edit_item(self):
        sel = self.tree_items.selection()
        if not sel: 
            messagebox.showinfo("Editar", "Selecciona una línea para modificar.")
            return
            
        idx = self.tree_items.index(sel[0])
        item = self.items[idx]
        
        # Cargar datos en formulario
        self.ent_art.delete(0, tk.END); self.ent_art.insert(0, item["articulo"])
        self.ent_cant.delete(0, tk.END); self.ent_cant.insert(0, str(item["cant"]))
        self.ent_coste.delete(0, tk.END); self.ent_coste.insert(0, str(item["coste_unit"]))
        
        if item["tipo"]:
             self.cb_tipo.set(item["tipo"])
        
        # Si tenía tiempo std custom, preservarlo para el recalculo
        # (Aunque _add_item volverá a intentar leer de DB si selected_item_time es None, 
        #  aquí forzamos que use el que ya tenía este item)
        self.selected_item_time = item["tiempo_std"]

        # Eliminar de la lista (para que al dar Añadir se cree de nuevo actualizado)
        del self.items[idx]
        self._refresh_table()
        
        messagebox.showinfo("Editar", "Item cargado. Modifica los valores y pulsa 'Añadir'.")
        self.ent_cant.focus()

    def _del_item(self):
        sel = self.tree_items.selection()
        if not sel: return
        idx = self.tree_items.index(sel[0])
        del self.items[idx]
        self._refresh_table()

    def _refresh_table(self):
        for i in self.tree_items.get_children(): self.tree_items.delete(i)
        for it in self.items:
            vals = (it["articulo"], it["cant"], f"{it['coste_unit']:.2f}", it["tipo"], 
                    it["tiempo_total"], f"{it['total_mat']:.2f}", f"{it['total_mo']:.2f}")
            self.tree_items.insert("", "end", values=vals)
        self._recalcular_totales()

    def _recalcular_totales(self):
        tot_mat = sum(i["total_mat"] for i in self.items)
        tot_mo = sum(i["total_mo"] for i in self.items)
        
        # Desplazamiento
        # Coste Km = (km_ida * 2) * precio_km
        # Coste Tiempo Viaje = (mins_ida * 2 / 60) * precio_hora
        
        p_km = self.precios.get("precio_km", 0.35)
        p_hora = self.precios.get("precio_hora", 30)
        
        coste_km = (self.distancia_km * 2) * p_km
        coste_t_viaje = (self.tiempo_viaje_min * 2 / 60) * p_hora
        
        tot_desp = coste_km + coste_t_viaje
        
        self.lbl_tot_mat.config(text=f"{tot_mat:.2f} €")
        self.lbl_tot_mo.config(text=f"{tot_mo:.2f} €")
        self.lbl_tot_desp.config(text=f"{tot_desp:.2f} €")
        
        gran_total = tot_mat + tot_mo + tot_desp
        self.lbl_gran_total.config(text=f"{gran_total:.2f} €")
        
        self.current_totals = {
            "mat": tot_mat, "mo": tot_mo, "desp": tot_desp, "global": gran_total
        }

    def _guardar_todo(self):
        if not self.ent_cliente.get():
            messagebox.showwarning("Faltan datos", "Indica el Cliente.")
            return
            
        conn = sqlite3.connect(VALORACIONES_DB)
        c = conn.cursor()
        
        if not hasattr(self, "current_totals"): self._recalcular_totales()
        
        # Update or Insert
        if self.val_id:
            c.execute("""UPDATE valoraciones SET 
                cliente=?, fecha=?, ubicacion=?, distancia_km=?, tiempo_viaje_min=?, 
                total_material=?, total_mano_obra=?, total_desplazamiento=?, total_global=?
                WHERE id=?""", (
                    self.ent_cliente.get(), self.ent_fecha.get(), self.ent_ubicacion.get(),
                    self.distancia_km, self.tiempo_viaje_min,
                    self.current_totals["mat"], self.current_totals["mo"], self.current_totals["desp"], self.current_totals["global"],
                    self.val_id
                ))
            # Delete details to re-insert
            c.execute("DELETE FROM detalles_valoracion WHERE valoracion_id=?", (self.val_id,))
            vid = self.val_id
        else:
            c.execute("""INSERT INTO valoraciones (
                cliente, fecha, ubicacion, distancia_km, tiempo_viaje_min, 
                total_material, total_mano_obra, total_desplazamiento, total_global
            ) VALUES (?,?,?,?,?,?,?,?,?)""", (
                self.ent_cliente.get(), self.ent_fecha.get(), self.ent_ubicacion.get(),
                self.distancia_km, self.tiempo_viaje_min,
                self.current_totals["mat"], self.current_totals["mo"], self.current_totals["desp"], self.current_totals["global"]
            ))
            vid = c.lastrowid
            
        # Insert items
        for i in self.items:
            c.execute("""INSERT INTO detalles_valoracion (
                valoracion_id, articulo, cantidad, coste_unitario, tipo_standar, tiempo_total_min
            ) VALUES (?,?,?,?,?,?)""", (
                vid, i["articulo"], i["cant"], i["coste_unit"], i["tipo"], i["tiempo_total"]
            ))
            
        conn.commit()
        conn.close()
        messagebox.showinfo("Guardado", "Valoración guardada correctamente.")
        if self.on_close_cb: self.on_close_cb()
        self.destroy()

    def _cargar_datos(self):
        conn = sqlite3.connect(VALORACIONES_DB)
        c = conn.cursor()
        c.execute("SELECT * FROM valoraciones WHERE id=?", (self.val_id,))
        head = c.fetchone()
        
        c.execute("SELECT articulo, cantidad, coste_unitario, tipo_standar, tiempo_total_min FROM detalles_valoracion WHERE valoracion_id=?", (self.val_id,))
        det = c.fetchall()
        conn.close()
        
        if head:
            # head: id, cliente, fecha, ubicacion, dist, t_viaje, tot_mat, tot_mo, tot_desp, tot_glob, notas
            self.ent_cliente.insert(0, head[1])
            self.ent_fecha.delete(0, tk.END); self.ent_fecha.insert(0, head[2])
            self.ent_ubicacion.insert(0, head[3])
            
            self.distancia_km = head[4]
            self.tiempo_viaje_min = head[5]
            self.lbl_distancia.config(text=f"Distancia: {self.distancia_km} km")
            self.lbl_tiempo_viaje.config(text=f"Tiempo Viaje: {self.tiempo_viaje_min} min (ida)")
            
        for d in det:
            # Reconstruct item dict (coste MO is approximate if price changed, but we recalc)
            tipo = d[3]
            cant = d[1]
            std_time = self.precios.get(f"tiempo_{tipo.lower()}", 0)
            
            item = {
                "articulo": d[0],
                "cant": cant,
                "coste_unit": d[2],
                "tipo": tipo,
                "tiempo_std": std_time,
                "total_mo": (d[4]/60) * self.precios.get("precio_hora", 30),
                "total_mat": cant * d[2],
                "tiempo_total": d[4]
            }
            self.items.append(item)
            
        self._refresh_table()
