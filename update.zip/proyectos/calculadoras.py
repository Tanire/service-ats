import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import math
from datetime import datetime

# ReportLab Imports
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas as pdf_canvas
    from reportlab.lib import colors
    from reportlab.platypus import Table, TableStyle
except ImportError:
    pdf_canvas = None

class HDDCalculatorFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="white")
        self.pack(fill="both", expand=True)
        
        # Header
        ttk.Label(self, text="Calculadora de Disco Duro (CCTV)", font=("Segoe UI", 16, "bold"), background="white").pack(pady=20)
        
        container = tk.Frame(self, bg="white")
        container.pack(pady=10)

        # Database de Modelos
        self.cam_db = {
            "Hikvision": {
                "HiLook Bullet 2MP": {"res": "2MP (1080p)", "codec": "H.265+", "fps": "25"},
                "Value Series 4MP": {"res": "4MP (2K)", "codec": "H.265+", "fps": "20"},
                "AcuSense 4MP": {"res": "4MP (2K)", "codec": "H.265+", "fps": "25"},
                "ColorVu 4MP": {"res": "4MP (2K)", "codec": "H.265+", "fps": "25"},
                "AcuSense 8MP (4K)": {"res": "8MP (4K)", "codec": "H.265+", "fps": "20"},
            },
            "Dahua": {
                "Cooper Series 2MP": {"res": "2MP (1080p)", "codec": "H.265", "fps": "25"},
                "Entry Series 4MP": {"res": "4MP (2K)", "codec": "H.265", "fps": "20"},
                "TiOC 5MP": {"res": "5MP", "codec": "H.265+", "fps": "25"},
                "WizSense 4K": {"res": "8MP (4K)", "codec": "H.265+", "fps": "25"},
            }
        }

        # Selectors (Top)
        tk.Label(container, text="Marca:", bg="white", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="e", padx=5)
        self.cb_brand = ttk.Combobox(container, values=["Manual"] + list(self.cam_db.keys()), state="readonly", width=15)
        self.cb_brand.grid(row=0, column=1, padx=5, pady=5)
        self.cb_brand.current(0)
        self.cb_brand.bind("<<ComboboxSelected>>", self._on_brand_change)
        
        tk.Label(container, text="Modelo:", bg="white", font=("Segoe UI", 9, "bold")).grid(row=1, column=0, sticky="e", padx=5)
        self.cb_model = ttk.Combobox(container, state="disabled", width=20)
        self.cb_model.grid(row=1, column=1, padx=5, pady=5)
        self.cb_model.bind("<<ComboboxSelected>>", self._on_model_change)

        ttk.Separator(container, orient="horizontal").grid(row=2, column=0, columnspan=2, sticky="ew", pady=10)
        
        # Inputs (Shifted Rows)
        self._create_row(container, "Número de Cámaras:", 3)
        self.entry_cams = ttk.Entry(container, width=10)
        self.entry_cams.grid(row=3, column=1, padx=10, pady=5)
        
        self._create_row(container, "Resolución (MP):", 4)
        self.combo_res = ttk.Combobox(container, values=["2MP (1080p)", "4MP (2K)", "5MP", "8MP (4K)"], state="readonly", width=15)
        self.combo_res.grid(row=4, column=1, padx=10, pady=5)
        self.combo_res.current(0)
        
        self._create_row(container, "FPS (cuadros/seg):", 5)
        self.combo_fps = ttk.Combobox(container, values=["15", "20", "25", "30"], state="readonly", width=10)
        self.combo_fps.grid(row=5, column=1, padx=10, pady=5)
        self.combo_fps.current(0) # 15 fps default
        
        self._create_row(container, "Días de Grabación:", 6)
        self.entry_days = ttk.Entry(container, width=10)
        self.entry_days.grid(row=6, column=1, padx=10, pady=5)
        
        self._create_row(container, "Compresión:", 7)
        self.combo_codec = ttk.Combobox(container, values=["H.264", "H.265", "H.265+"], state="readonly", width=10)
        self.combo_codec.grid(row=7, column=1, padx=10, pady=5)
        self.combo_codec.current(1) # H.265
        
        # Button
        ttk.Button(self, text="Calcular Almacenamiento", command=self._calculate).pack(pady=20)
        
        # Result
        self.lbl_result = ttk.Label(self, text="Resultado: ---", font=("Segoe UI", 14, "bold"), background="white", foreground="#004080")
        self.lbl_result.pack(pady=10)
        
        self.lbl_info = ttk.Label(self, text="*Nota: Estimación aproximada basada en bitrate promedio.", font=("Segoe UI", 8, "italic"), background="white", foreground="gray")
        self.lbl_info.pack(side="bottom", pady=20)

    def _create_row(self, parent, label_text, r):
        ttk.Label(parent, text=label_text, background="white", font=("Segoe UI", 11)).grid(row=r, column=0, sticky="e", padx=10, pady=5)

    def _on_brand_change(self, event):
        brand = self.cb_brand.get()
        if brand == "Manual":
            self.cb_model.set("")
            self.cb_model.config(state="disabled")
            self.combo_res.state(["!disabled"])
            self.combo_fps.state(["!disabled"])
            self.combo_codec.state(["!disabled"])
        else:
            models = list(self.cam_db.get(brand, {}).keys())
            self.cb_model.config(state="readonly", values=models)
            self.cb_model.current(0)
            self._on_model_change(None)

    def _on_model_change(self, event):
        brand = self.cb_brand.get()
        model = self.cb_model.get()
        if brand == "Manual" or not model: return
        
        data = self.cam_db.get(brand, {}).get(model, {})
        if data:
            self.combo_res.set(data.get("res", ""))
            self.combo_codec.set(data.get("codec", ""))
            self.combo_fps.set(data.get("fps", ""))

    def _calculate(self):
        try:
            cams = int(self.entry_cams.get())
            days = int(self.entry_days.get())
            if cams <= 0 or days <= 0: raise ValueError
            
            res_map = {"2MP (1080p)": 2048, "4MP (2K)": 4096, "5MP": 5120, "8MP (4K)": 8192} # Bitrate base kbps (est)
            selected_res = self.combo_res.get()
            base_bitrate = res_map.get(selected_res, 2048)
            
            fps = int(self.combo_fps.get())
            bitrate = base_bitrate * (fps / 25.0)
            
            codec = self.combo_codec.get()
            if codec == "H.265": bitrate *= 0.5
            elif codec == "H.265+": bitrate *= 0.35
            
            total_bitrate_kbps = bitrate * cams
            
            # Mbps = bitrate / 1024 (aprox) or 1000
            mbps_total = (total_bitrate_kbps / 1024.0) 
            
            # Storage in GB
            # 1 day = 86400 seconds
            # MB per day = mbps_total / 8 * 86400
            mb_day = (mbps_total / 8) * 86400
            gb_total = (mb_day * days) / 1024
            tb_total = gb_total / 1024
            
            self.lbl_result.config(text=f"Espacio Requerido: {tb_total:.2f} TB ({gb_total:.0f} GB)")
            
        except ValueError:
            messagebox.showerror("Error", "Por favor ingrese números válidos para cámaras y días.")

class PowerCalculatorFrame(tk.Frame):
    def __init__(self, parent):
        super().__init__(parent, bg="white")
        self.pack(fill="both", expand=True)
        
        # --- TOP: Listado de Dispositivos ---
        top_frame = tk.Frame(self, bg="white")
        top_frame.pack(side="top", fill="both", expand=True, padx=10, pady=10)
        
        ttk.Label(top_frame, text="Calculadora de Consumo (Dispositivos)", font=("Segoe UI", 14, "bold"), background="white").pack(anchor="w")
        
        # Treeview
        cols = ("Device", "Watts", "Qty", "Subtotal")
        self.tree = ttk.Treeview(top_frame, columns=cols, show="headings", height=6)
        self.tree.heading("Device", text="Dispositivo")
        self.tree.column("Device", width=200)
        self.tree.heading("Watts", text="W / Unidad")
        self.tree.column("Watts", width=80)
        self.tree.heading("Qty", text="Cant.")
        self.tree.column("Qty", width=50)
        self.tree.heading("Subtotal", text="Total (W)")
        self.tree.column("Subtotal", width=80)
        self.tree.pack(fill="both", expand=True, pady=5)
        
        # Add controls
        add_frame = tk.Frame(top_frame, bg="white")
        add_frame.pack(fill="x", pady=5)
        
        ttk.Label(add_frame, text="Disp:", background="white").pack(side="left")
        self.ent_dev = ttk.Entry(add_frame, width=15)
        self.ent_dev.pack(side="left", padx=2)
        
        ttk.Label(add_frame, text="W:", background="white").pack(side="left", padx=(5,0))
        self.ent_watts = ttk.Entry(add_frame, width=6)
        self.ent_watts.pack(side="left", padx=2)
        
        ttk.Label(add_frame, text="Cant:", background="white").pack(side="left", padx=(5,0))
        self.ent_qty = ttk.Entry(add_frame, width=4)
        self.ent_qty.pack(side="left", padx=2)
        self.ent_qty.insert(0, "1")
        
        ttk.Button(add_frame, text="Añadir", command=self._add_device).pack(side="left", padx=10)
        ttk.Button(add_frame, text="Borrar Todo", command=self._clear_devices).pack(side="right")

        # --- MIDDLE: Total Consumo ---
        mid_frame = tk.Frame(self, bg="#f5f5f5", pady=5)
        mid_frame.pack(fill="x", padx=10)
        
        self.lbl_total_watts = tk.Label(mid_frame, text="Consumo Total: 0.0 W", font=("Segoe UI", 12, "bold"), bg="#f5f5f5", fg="#d32f2f")
        self.lbl_total_watts.pack(side="left", padx=20)
        
        self.lbl_amps = tk.Label(mid_frame, text="(0.0A @ 12V)", font=("Segoe UI", 10), bg="#f5f5f5")
        self.lbl_amps.pack(side="left")
        
        self.total_watts = 0.0

        # --- BOTTOM: Análisis Solar / Autonomía ---
        self.analysis_frame = tk.LabelFrame(self, text="🌞 Análisis de Sistema Autónomo / Solar", bg="white")
        self.analysis_frame.pack(side="bottom", fill="both", expand=True, padx=10, pady=10)

        # Botón Exportar PDF (al fondo a la derecha)
        tk.Button(self.analysis_frame, text="📄 Exportar Informe PDF", command=self._export_pdf, 
                 bg="#d32f2f", fg="white", font=("Segoe UI", 9, "bold")).pack(side="bottom", anchor="e", padx=10, pady=5)
        
        # Inputs Solar/Bat
        inputs_grid = tk.Frame(self.analysis_frame, bg="white")
        inputs_grid.pack(fill="x", pady=5)
        
        # Batería
        tk.Label(inputs_grid, text="Batería (Capacidad):", bg="white", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="e", padx=5)
        
        self.bat_presets = {
            "Personalizado": 0,
            "EcoFlow River 2 (256Wh)": 256,
            "EcoFlow River 2 Max (512Wh)": 512,
            "EcoFlow River 2 Pro (768Wh)": 768,
            "EcoFlow Delta 2 (1024Wh)": 1024,
            "EcoFlow Delta Max (2016Wh)": 2016,
            "EcoFlow Delta Pro (3600Wh)": 3600,
            "Batería GEL 12V 100Ah (~1200Wh)": 1200,
            "Batería GEL 12V 200Ah (~2400Wh)": 2400
        }
        
        self.cb_bat = ttk.Combobox(inputs_grid, values=list(self.bat_presets.keys()), state="readonly", width=30)
        self.cb_bat.grid(row=0, column=1, padx=5)
        self.cb_bat.current(0)
        self.cb_bat.bind("<<ComboboxSelected>>", self._on_bat_change)
        
        self.ent_bat_wh = ttk.Entry(inputs_grid, width=10)
        self.ent_bat_wh.grid(row=0, column=2, padx=5)
        tk.Label(inputs_grid, text="Wh", bg="white").grid(row=0, column=3, sticky="w")
        
        # Solar
        tk.Label(inputs_grid, text="Panel (W/Unidad):", bg="white", font=("Segoe UI", 9, "bold")).grid(row=1, column=0, sticky="e", padx=5, pady=5)
        
        # Frame para W y Cantidad juntos
        solar_frame = tk.Frame(inputs_grid, bg="white")
        solar_frame.grid(row=1, column=1, sticky="w")
        
        self.ent_solar_w = ttk.Entry(solar_frame, width=7)
        self.ent_solar_w.pack(side="left", padx=2)
        self.ent_solar_w.insert(0, "400")
        
        tk.Label(solar_frame, text="x", bg="white").pack(side="left")
        self.ent_solar_qty = ttk.Entry(solar_frame, width=4)
        self.ent_solar_qty.pack(side="left", padx=2)
        self.ent_solar_qty.insert(0, "1")
        
        tk.Label(inputs_grid, text="Horas Sol (HSP):", bg="white").grid(row=1, column=2, sticky="e", padx=5)
        self.ent_sun_hours = ttk.Entry(inputs_grid, width=5)
        self.ent_sun_hours.grid(row=1, column=3, padx=5)
        self.ent_sun_hours.insert(0, "5") # España sur media
        
        ttk.Button(inputs_grid, text="🔄 Analizar Sistema", command=self._analyze).grid(row=0, column=4, rowspan=2, padx=20, sticky="ns")

        # Resultados
        self.res_txt = tk.Text(self.analysis_frame, height=8, bg="#f0f0f0", font=("Consolas", 10))
        self.res_txt.pack(fill="both", expand=True, pady=5)
        self.res_txt.insert("1.0", "Ingrese dispositivos y datos del sistema para ver el análisis...")
        self.res_txt.config(state="disabled")

    def _add_device(self):
        try:
            dev = self.ent_dev.get() or "Dispositivo"
            w = float(self.ent_watts.get())
            q = int(self.ent_qty.get())
            if w < 0 or q <= 0: raise ValueError
            
            sub = w * q
            self.tree.insert("", "end", values=(dev, w, q, sub))
            self._recalc_total()
            
            self.ent_dev.delete(0, "end")
            self.ent_watts.delete(0, "end")
            self.ent_qty.delete(0, "end")
            self.ent_qty.insert(0, "1")
            self.ent_dev.focus()
        except ValueError:
            messagebox.showerror("Error", "Revise los valores numéricos.")

    def _clear_devices(self):
        for i in self.tree.get_children(): self.tree.delete(i)
        self._recalc_total()

    def _recalc_total(self):
        self.total_watts = 0.0
        for i in self.tree.get_children():
            self.total_watts += float(self.tree.item(i)["values"][3])
            
        self.lbl_total_watts.config(text=f"Consumo Total: {self.total_watts:.2f} W")
        self.lbl_amps.config(text=f"({(self.total_watts/12.0):.1f}A @ 12V  |  {(self.total_watts/220.0):.2f}A @ 220V)")

    def _on_bat_change(self, event):
        sel = self.cb_bat.get()
        val = self.bat_presets.get(sel, 0)
        self.ent_bat_wh.delete(0, "end")
        if val > 0:
            self.ent_bat_wh.insert(0, str(val))

    def _analyze(self):
        try:
            bat_wh = float(self.ent_bat_wh.get() or 0)
            panel_w = float(self.ent_solar_w.get() or 0)
            panel_qty = float(self.ent_solar_qty.get() or 0)
            solar_w = panel_w * panel_qty
            hsp = float(self.ent_sun_hours.get() or 0)
        except ValueError:
            messagebox.showerror("Error", "Valores de batería o solar inválidos.")
            return

        total_w = self.total_watts
        
        lines = []
        lines.append(f"--- RESULTADOS DEL ANÁLISIS ---")
        lines.append(f"Consumo Continuo: {total_w:.2f} W")
        
        # 1. Consumo Diario
        daily_consumption_wh = total_w * 24
        lines.append(f"Consumo Diario (24h): {daily_consumption_wh:.0f} Wh")
        
        # 2. Autonomía Batería (Sin sol)
        if bat_wh > 0 and total_w > 0:
            autonomy_h = bat_wh / total_w
            # Factor de descarga profunda (ej: 90% útil en Litio, 50% en Plomo/AGM)
            # Asumimos Litio/EcoFlow (90% usable aprox)
            autonomy_real = autonomy_h * 0.90
            lines.append(f"Autonomía Batería (Sin Carga): ~{autonomy_real:.1f} Horas")
            if autonomy_real < 12:
                lines.append(f"⚠️ ¡ATENCIÓN! La batería no dura una noche entera (12h).")
            else:
                lines.append(f"✅ La batería soporta una noche completa.")
        elif total_w == 0:
            lines.append("Autonomía: Infinita (Sin consumo).")
        else:
            lines.append("Autonomía: N/A (Defina Batería).")
            
        lines.append("-" * 30)
        
        # 3. Solar
        if solar_w > 0:
            # Generación diaria estimada
            # Eficiencia sistema 0.85 (perdidas cables, regulador...)
            daily_gen = solar_w * hsp * 0.85
            lines.append(f"Generación Solar Est. ({hsp}h sol): {daily_gen:.0f} Wh/día")
            
            balance = daily_gen - daily_consumption_wh
            lines.append(f"Balance Energético: {balance:+.0f} Wh/día")
            
            if balance >= 0:
                lines.append(f"✅ EL SISTEMA ES AUTOSUFICIENTE.")
                lines.append(f"   (Sobran {balance:.0f} Wh para cargar batería)")
            else:
                lines.append(f"❌ DÉFICIT DE ENERGÍA.")
                lines.append(f"   (Faltan {-balance:.0f} Wh diarios. La batería se agotará eventualmente).")
                lines.append(f"   -> Necesitas más paneles o reducir consumo.")
        else:
            lines.append("Sin aporte solar configurado.")

        lines.append("-" * 30)

        # 4. Recomendación EcoFlow
        if total_w > 0:
            lines.append("🤖 RECOMENDACIÓN INTELIGENTE:")
            
            # Criterio: Aguantar la noche (14 horas de seguridad) con descarga al 90%
            required_night_wh = (total_w * 14) / 0.90
            
            best_fit = None
            min_diff = float('inf')
            
            # Presets EcoFlow ordenados por capacidad
            ef_models = [
                ("EcoFlow River 2", 256),
                ("EcoFlow River 2 Max", 512),
                ("EcoFlow River 2 Pro", 768),
                ("EcoFlow Delta 2", 1024),
                ("EcoFlow Delta Max", 2016),
                ("EcoFlow Delta Pro", 3600),
                ("EcoFlow Delta Pro Ultra", 6000)
            ]
            
            for name, cap in ef_models:
                if cap >= required_night_wh:
                    best_fit = (name, cap)
                    break
            
            if best_fit:
                lines.append(f"🔋 Modelo Sugerido: {best_fit[0]}")
                lines.append(f"   (Capacidad: {best_fit[1]}Wh > Necesario Noche: {required_night_wh:.0f}Wh)")
            else:
                lines.append("⚠️ Consumo muy alto. Necesitas banco de baterías custom (>6kWh).")
                
            # Chequeo Solar para el sugerido
            if best_fit and solar_w > 0:
                # Cuanto tarda en cargar esa batería con el sol disponible?
                daily_gen = solar_w * hsp * 0.85
                if daily_gen < daily_consumption_wh:
                    lines.append(f"☀️ FALTAN PANELES: {best_fit[0]} se descargará en unos días.")
                    lines.append(f"   Necesitas generar min {daily_consumption_wh:.0f}Wh/día.")
                    recommended_solar = daily_consumption_wh / (hsp * 0.85)
                    lines.append(f"   -> Instala al menos {recommended_solar:.0f}W de paneles.")
                else:
                     lines.append(f"✅ Los paneles actuales mantienen el sistema cargado.")
            
        self.res_txt.config(state="normal")
        self.res_txt.delete("1.0", "end")
        self.res_txt.insert("1.0", "\n".join(lines))
        self.res_txt.config(state="disabled")

    def _export_pdf(self):
        if not pdf_canvas:
            messagebox.showerror("Error", "Librería reportlab no encontrada.")
            return

        if not self.tree.get_children():
            messagebox.showwarning("Aviso", "No hay dispositivos en la lista para exportar.")
            return

        filename = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF Files", "*.pdf")], title="Guardar Informe")
        if not filename: return

        try:
            c = pdf_canvas.Canvas(filename, pagesize=A4)
            width, height = A4
            
            # Header
            c.setFont("Helvetica-Bold", 18)
            c.drawString(50, height - 50, "Informe de Sistema de Alimentación")
            
            c.setFont("Helvetica", 10)
            c.drawString(50, height - 70, f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}")
            c.drawString(50, height - 85, "Generado por: Software ATS")

            # --- Tabla Dispositivos ---
            data = [["Dispositivo", "Watts", "Cant.", "Total (W)"]]
            for i in self.tree.get_children():
                row = self.tree.item(i)["values"]
                data.append([str(row[0]), f"{row[1]} W", str(row[2]), f"{row[3]} W"])
            
            # Totals row
            data.append(["", "", "TOTAL:", f"{self.total_watts:.2f} W"])

            table = Table(data, colWidths=[250, 80, 60, 100])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.darkblue),
                ('TEXTCOLOR', (0,0), (-1,0), colors.whitesmoke),
                ('ALIGN', (0,0), (-1,-1), 'CENTER'),
                ('ALIGN', (0,0), (0,-1), 'LEFT'), # Left align device names
                ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
                ('BOTTOMPADDING', (0,0), (-1,0), 12),
                ('BACKGROUND', (0,-1), (-1,-1), colors.beige),
                ('GRID', (0,0), (-1,-1), 1, colors.black),
                ('FONTNAME', (0,-1), (-1,-1), 'Helvetica-Bold'),
            ]))
            
            # Draw Table
            table.wrapOn(c, width, height)
            table.drawOn(c, 50, height - 120 - (len(data) * 20))
            
            table_bottom_y = height - 120 - (len(data) * 20)
            
            # --- Analysis Section ---
            y = table_bottom_y - 40
            c.setFont("Helvetica-Bold", 14)
            c.drawString(50, y, "Análisis de Energía y Autonomía")
            y -= 20
            
            analysis_text = self.res_txt.get("1.0", "end").strip()
            
            text_object = c.beginText(50, y)
            text_object.setFont("Courier", 10)
            
            for line in analysis_text.split("\n"):
                if "RECOMENDACIÓN" in line:
                    text_object.setFont("Courier-Bold", 10)
                    text_object.setFillColor(colors.darkblue)
                elif "Faltan Paneles" in line or "DÉFICIT" in line or "ATENCIÓN" in line:
                    text_object.setFillColor(colors.red)
                elif "Suficiente" in line or "AUTOSUFICIENTE" in line or "soporta" in line:
                    text_object.setFillColor(colors.green)
                else:
                    text_object.setFillColor(colors.black)
                    text_object.setFont("Courier", 10)
                
                text_object.textLine(line)
                
            c.drawText(text_object)
            
            c.showPage()
            c.save()
            messagebox.showinfo("Exportar", "Informe guardado correctamente.")
            
            # Intentar abrir
            try:
                import os
                os.startfile(filename)
            except: pass

        except Exception as e:
            messagebox.showerror("Error", f"Fallo al exportar PDF: {e}")
