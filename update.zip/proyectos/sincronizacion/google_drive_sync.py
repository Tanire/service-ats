import os
import json
import time
import socket
import hashlib
from pathlib import Path
from pydrive2.auth import GoogleAuth
from pydrive2.drive import GoogleDrive


class GoogleDriveSync:
    """
    Sincronización completa con:
    Mi unidad / SOFTWARE ATS/
        updates/
        databases/
        backups/
        logs/

    Features:
    - Autenticación automática
    - Verificación de conexión a Internet
    - Cola offline (sync_queue.json)
    - Descargar / subir archivos
    - Acceder a subcarpetas por nombre
    """

    BASE_FOLDER_ID = "1tEIWr38op6Kcb3WeG2OUXtcnCpnIUYuF"  # SOFTWARE ATS

    def __init__(self, client_secrets_path, drive_folder_id=None):
        self.client_secrets_path = client_secrets_path
        self.drive = None
        self.gauth = None

        # Carpeta base (SOFTWARE ATS)
        self.base_folder_id = drive_folder_id or self.BASE_FOLDER_ID

        # Archivo de cola offline
        self.queue_file = Path("sync_queue.json")
        
        # Cache de carpetas para evitar llamadas repetidas a la API
        self.folder_cache = {}

    # ---------------------------------------------------
    #   INTERNET CHECK
    # ---------------------------------------------------
    def has_connection(self):
        try:
            # No tocar el timeout global con setdefaulttimeout
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except:
            return False

    # ---------------------------------------------------
    #   AUTENTICACIÓN
    # ---------------------------------------------------
    # ---------------------------------------------------
    #   AUTENTICACIÓN
    # ---------------------------------------------------
    def authenticate(self, interactive=True):
        """
        Autentica Google Drive.
        Prioridad 1: Service Account (service_account.json) -> Auth automática server-to-server.
        Prioridad 2: User OAuth (client_secrets.json) -> Auth usuario interactiva.
        """
        t0 = time.time()
        base_path = Path(__file__).resolve().parents[2]
        
        # 1. INTENTAR SERVICE ACCOUNT (Autologin multi-usuario)
        sa_path = base_path / "config" / "drive_auth" / "service_account.json"
        
        if sa_path.exists():
            try:
                from oauth2client.service_account import ServiceAccountCredentials
                
                scope = ["https://www.googleapis.com/auth/drive"]
                creds = ServiceAccountCredentials.from_json_keyfile_name(str(sa_path), scope)
                
                # Inyectar credenciales en GoogleAuth de pydrive2 manualmente
                self.gauth = GoogleAuth()
                self.gauth.credentials = creds
                self.drive = GoogleDrive(self.gauth)
                return True
            except Exception as e:
                print("Error Service Account:", e)
                # Si falla, cae al método normal
        
        # 2. MÉTODO TRADICIONAL (User OAuth)
        if not os.path.exists(self.client_secrets_path):
            print("ERROR: Falta client_secrets.json")
            return False

        self.gauth = GoogleAuth()
        self.gauth.settings["client_config_file"] = self.client_secrets_path

        # Rutas absolutas para evitar errores
        token_dir = base_path / "config" / "drive_auth"
        token_path = token_dir / "token.json"
        
        os.makedirs(token_dir, exist_ok=True)
        self.gauth.LoadCredentialsFile(str(token_path))

        # Si no hay token o está expirado
        if self.gauth.credentials is None:
            if not interactive:
                # print("Auth requerida pero modo interactivo desactivado.")
                print(f"  [GDRIVE] Auth fail: No interactive ({time.time()-t0:.2f}s)")
                return False
                
            print("Primer inicio: intentando autenticación web...")
            try:
                self.gauth.LocalWebserverAuth()
            except Exception as e:
                print("Fallo web, intentando consola:", e)
                try:
                    self.gauth.CommandLineAuth()
                except Exception as e2:
                    print("Error autenticando:", e2)
                    return False

        elif self.gauth.access_token_expired:
            try:
                self.gauth.Refresh()
            except Exception:
                if not interactive:
                    print(f"  [GDRIVE] Auth fail: Expired & No interactive ({time.time()-t0:.2f}s)")
                    return False
                try:
                    self.gauth.LocalWebserverAuth()
                except:
                    return False
        else:
            try:
                self.gauth.Authorize()
            except Exception:
                if not interactive:
                    print(f"  [GDRIVE] Auth fail: Authorize error ({time.time()-t0:.2f}s)")
                    return False
                return False

        # Guardar token
        self.gauth.SaveCredentialsFile(str(token_path))

        try:
            self.drive = GoogleDrive(self.gauth)
            print(f"  [GDRIVE] OAuth OK ({time.time()-t0:.2f}s)")
            return True
        except Exception as e:
            print("Error al crear GoogleDrive:", e)
            return False

    # ---------------------------------------------------
    #   GESTIÓN DE CARPETAS
    # ---------------------------------------------------
    def find_folder(self, parent_id, name):
        cache_key = f"{parent_id}_{name}"
        if cache_key in self.folder_cache:
            return self.folder_cache[cache_key]
        
        files = self.drive.ListFile({
            "q": f"'{parent_id}' in parents and trashed=false and mimeType='application/vnd.google-apps.folder'"
        }).GetList()

        for f in files:
            if f["title"] == name:
                self.folder_cache[cache_key] = f["id"]
                return f["id"]
        
        return None



    # ---------------------------------------------------
    #   HELPER MD5
    # ---------------------------------------------------
    def get_md5(self, path):
        if not os.path.exists(path): return None
        try:
            hash_md5 = hashlib.md5()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_md5.update(chunk)
            return hash_md5.hexdigest()
        except:
            return None

    # ---------------------------------------------------
    #   DESCARGAR ARCHIVOS
    # ---------------------------------------------------
    def download_file(self, title, dest_path, subfolder=None):
        """
        Descarga un archivo por nombre desde SOFTWARE ATS o subcarpeta.
        Optimización: Comprueba MD5 antes de descargar.
        """
        if not self.has_connection():
            return {"status": "offline"}

        if not self.drive:
            return {"status": "no_auth"}

        folder_id = self.base_folder_id

        if subfolder:
            folder_id = self.find_folder(self.base_folder_id, subfolder)
            if not folder_id:
                return {"status": "not_found"}

        query = f"'{folder_id}' in parents and trashed=false and title='{title}'"
        results = self.drive.ListFile({"q": query}).GetList()

        if not results:
            return {"status": "not_found"}

        file_drive = results[0]
        
        # CHEQUEO MD5 (Optimización)
        remote_md5 = file_drive.get("md5Checksum")
        local_md5 = self.get_md5(dest_path)
        
        if remote_md5 and local_md5 and remote_md5.lower() == local_md5.lower():
            # No descargar si es idéntico
            return {"status": "skipped_identical", "path": dest_path}

        # Crear carpeta destino
        os.makedirs(os.path.dirname(dest_path), exist_ok=True)

        # Descargar
        # Descargar con reintentos
        # Asegurar timeout generoso para archivos grandes
        socket.setdefaulttimeout(120) 
        max_retries = 3
        for attempt in range(max_retries):
            try:
                print(f"Descargando {title}, intento {attempt+1}/{max_retries}...")
                file_drive.GetContentFile(dest_path)
                return {"status": "downloaded", "path": dest_path}
            except Exception as e:
                err_str = str(e).lower()
                if "abuse" in err_str or "malware" in err_str:
                    print(f"Detectado bloqueo de Drive (Abuse/Malware). Intentando bypass con acknowledgeAbuse=True...")
                    try:
                        # Bypass usando el servicio de bajo nivel
                        drive_service = self.drive.auth.service
                        # execute() descarga todo en memoria (cuidado con archivos gigantes, pero ok para 50mb)
                        content = drive_service.files().get_media(fileId=file_drive['id'], acknowledgeAbuse=True).execute()
                        with open(dest_path, "wb") as f:
                            f.write(content)
                        return {"status": "downloaded", "path": dest_path}
                    except Exception as e2:
                        print(f"Fallo bypass abuse: {e2}")
                        return {"status": "error", "cause": f"Abuse bypass failed: {e2}"}
                
                print(f"Intento {attempt+1} fallido: {e}")
                if attempt < max_retries - 1:
                    time.sleep(2) # Esperar antes de reintentar
                else:
                    return {"status": "error", "cause": str(e)}

    # ---------------------------------------------------
    #   SUBIR ARCHIVOS
    # ---------------------------------------------------
    def upload_file(self, local_path, remote_title=None, subfolder=None):
        """
        Sube archivo a SOFTWARE ATS (o subcarpeta) sustituyéndolo si existe.
        """
        if not self.has_connection():
            self.enqueue(local_path, remote_title, subfolder)
            return {"status": "queued_offline"}

        if not self.drive:
            # guardar en cola si offline
            self.enqueue(local_path, remote_title, subfolder)
            return {"status": "queued"}

        if not os.path.exists(local_path):
            return {"status": "not_found"}

        remote_title = remote_title or os.path.basename(local_path)

        folder_id = self.base_folder_id
        if subfolder:
            folder_id = self.find_folder(self.base_folder_id, subfolder)
            if not folder_id:
                return {"status": "no_subfolder"}

        # Buscar archivo existente
        query = f"'{folder_id}' in parents and trashed=false and title='{remote_title}'"
        results = self.drive.ListFile({"q": query}).GetList()

        # Si existe → comprobar MD5 y reemplazar si es diferente
        if results:
            file_drive = results[0]
            # OPTIMIZACION MD5: Comprobar si es idéntico
            remote_md5 = file_drive.get("md5Checksum")
            local_md5 = self.get_md5(local_path)
            
            if remote_md5 and local_md5 and remote_md5.lower() == local_md5.lower():
                # print(f"Skipping {remote_title} (Identical MD5)")
                return {"status": "skipped", "path": local_path}
                
        else:
            file_drive = self.drive.CreateFile({
                "title": remote_title,
                "parents": [{"id": folder_id}]
            })

        file_drive.SetContentFile(local_path)

        try:
            file_drive.Upload()
            return {"status": "uploaded"}
        except:
            # fallo → se encola
            self.enqueue(local_path, remote_title, subfolder)
            return {"status": "queued"}

    # ---------------------------------------------------
    #   COLA OFFLINE
    # ---------------------------------------------------
    def enqueue(self, local_path, remote_title, subfolder):
        """
        Guarda operación para ejecutar cuando vuelva la conexión.
        """
        queue = []

        if self.queue_file.exists():
            try:
                queue = json.loads(self.queue_file.read_text())
            except:
                queue = []
        
        # Optimización: eliminar entradas previas del mismo archivo para evitar duplicados
        # Filtramos todo lo que NO coincida con el nuevo item
        queue = [item for item in queue if not (item["remote_title"] == remote_title and item["subfolder"] == subfolder)]

        queue.append({
            "local_path": local_path,
            "remote_title": remote_title,
            "subfolder": subfolder
        })

        self.queue_file.write_text(json.dumps(queue, indent=2))

    def process_queue(self):
        """
        Procesa todas las operaciones pendientes si hay conexión.
        """
        if not self.drive:
            return False

        if not self.queue_file.exists():
            return True

        try:
            queue = json.loads(self.queue_file.read_text())
        except:
            return False

        # DEDUPLICACIÓN: Solo nos interesa la última versión de cada archivo
        # Convertimos la lista en un dict con clave (remote_title, subfolder) -> item
        # Como iteramos en orden, el último sobreescribe al anterior.
        dedup_map = {}
        for item in queue:
            key = (item["remote_title"], item["subfolder"])
            dedup_map[key] = item
            
        queue_dedup = list(dedup_map.values())

        new_queue = []

        for item in queue_dedup:
            res = self.upload_file(
                local_path=item["local_path"],
                remote_title=item["remote_title"],
                subfolder=item["subfolder"]
            )
            if res["status"] != "uploaded" and res["status"] != "skipped":
                 # Considerar 'skipped' como éxito para sacarlo de la cola
                new_queue.append(item)
        
        # Guardar cola restante
        self.queue_file.write_text(json.dumps(new_queue, indent=2))
        return True
