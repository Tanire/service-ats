import os
import json
import time
import socket
import base64
import requests
from datetime import datetime
from pathlib import Path

class GithubDBSync:
    """
    Sincronización de bases de datos usando la API REST de GitHub.
    Funciona 100% en Python con la librería requests, sin requerir la instalación
    del ejecutable de Git en la máquina cliente.
    """

    def __init__(self, repo_url, pat_token, local_dir_name=".db_sync_repo"):
        self.repo_url = repo_url
        self.pat_token = pat_token
        self.project_root = Path(__file__).resolve().parents[2]
        self.is_ready = False
        
        # Extraer owner y repo de la URL
        # ej: "https://github.com/Tanire/service-ats-db-backups.git"
        try:
            parts = repo_url.strip().split("/")
            self.owner = parts[-2]
            self.repo = parts[-1].replace(".git", "")
        except Exception as e:
            print("Error parseando repo_url:", e)
            self.owner = ""
            self.repo = ""

        # Configurar cabeceras para API REST de GitHub
        self.headers = {
            "Authorization": f"token {self.pat_token}",
            "Accept": "application/vnd.github.v3+json"
        }
        
        self.remote_files = {}
        self.upload_queue = {}
        
        self.authenticate(interactive=False)

    def has_connection(self):
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except:
            return False

    def authenticate(self, interactive=False):
        """Verifica el token PAT e inicializa la lista de archivos remotos."""
        if not self.has_connection():
            return False
            
        if not self.pat_token or self.pat_token == "TU_TOKEN_GITHUB_AQUI":
            if interactive:
                print("Error: Define tu token PAT en main.py")
            return False

        # Probar autenticación consultando la metadata del repositorio
        url = f"https://api.github.com/repos/{self.owner}/{self.repo}"
        try:
            res = requests.get(url, headers=self.headers, timeout=5)
            if res.status_code == 200:
                self.is_ready = True
                self._pull() # Cargar estado inicial de archivos remotos
                return True
            else:
                if interactive:
                    print("Error verificando token PAT en GitHub:", res.status_code, res.text)
        except Exception as e:
            if interactive:
                print("Error verificando conexión:", e)
        return False

    def _pull(self):
        """Descarga la lista de archivos del repositorio remoto y sus metadatos (SHA, URLs)."""
        if not self.is_ready:
            return
            
        url = f"https://api.github.com/repos/{self.owner}/{self.repo}/contents/"
        try:
            res = requests.get(url, headers=self.headers, timeout=10)
            if res.status_code == 200:
                files_list = res.json()
                self.remote_files = {}
                for f in files_list:
                    if f["type"] == "file":
                        self.remote_files[f["name"]] = {
                            "sha": f["sha"],
                            "size": f["size"],
                            "download_url": f["download_url"]
                        }
                print(f"[SYNC] Lista de archivos remotos cargada: {list(self.remote_files.keys())}")
            else:
                print(f"[SYNC] Error al obtener lista de archivos: {res.status_code}")
        except Exception as e:
            print(f"[SYNC] Excepción en _pull: {e}")

    def get_md5(self, path):
        if not os.path.exists(path):
            return None
        try:
            import hashlib
            hash_md5 = hashlib.md5()
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    hash_md5.update(chunk)
            return hash_md5.hexdigest()
        except Exception as e:
            print(f"Error calculando MD5 de {path}: {e}")
            return None

    def get_git_sha1(self, path):
        """Calcula el SHA-1 local usando la misma definición que usa Git para blobs."""
        if not os.path.exists(path):
            return None
        try:
            import hashlib
            size = os.path.getsize(path)
            sha1 = hashlib.sha1()
            header = f"blob {size}\0".encode("utf-8")
            sha1.update(header)
            with open(path, "rb") as f:
                for chunk in iter(lambda: f.read(4096), b""):
                    sha1.update(chunk)
            return sha1.hexdigest()
        except Exception as e:
            print(f"Error calculando Git SHA-1 para {path}: {e}")
            return None

    def parse_github_date(self, date_str):
        # Ej: "2026-06-02T14:40:00Z"
        clean = date_str.replace("Z", "+00:00")
        try:
            dt = datetime.fromisoformat(clean)
            return int(dt.timestamp())
        except Exception as e:
            print("Error parseando fecha de GitHub:", e)
            return 0

    def get_remote_file_time(self, title):
        """Obtiene la fecha del último commit de un archivo específico en GitHub."""
        url = f"https://api.github.com/repos/{self.owner}/{self.repo}/commits?path={title}&page=1&per_page=1"
        try:
            res = requests.get(url, headers=self.headers, timeout=10)
            if res.status_code == 200:
                commits = res.json()
                if commits:
                    date_str = commits[0]["commit"]["committer"]["date"]
                    return self.parse_github_date(date_str)
        except Exception as e:
            print(f"Error obteniendo fecha remota para {title}: {e}")
        return 0

    def download_file(self, title, dest_path, subfolder=None):
        """ Carga desde el repo remoto a la ruta local. """
        if not self.is_ready:
            return {"status": "no_auth"}
            
        if title not in self.remote_files:
            return {"status": "not_found"}
            
        remote_info = self.remote_files[title]
        
        # Si el archivo destino local existe, comparamos firmas y fechas
        if os.path.exists(dest_path):
            local_git_sha = self.get_git_sha1(dest_path)
            if local_git_sha and local_git_sha == remote_info["sha"]:
                print(f"[SYNC] {title} es idéntico al remoto (SHA coincidente).")
                return {"status": "skipped_identical", "path": dest_path}
                
            # Si difieren, comparamos marcas de tiempo
            remote_time = self.get_remote_file_time(title)
            if remote_time == 0:
                remote_time = int(time.time())
                
            local_time = int(os.path.getmtime(dest_path))
            
            # Si el archivo local de producción es más nuevo, omitimos sobreescribirlo
            if local_time >= remote_time:
                print(f"[SYNC] Omitiendo descarga de {title}: los datos locales son más recientes o iguales ({local_time} >= {remote_time})")
                return {"status": "skipped_local_newer", "path": dest_path}
            
        try:
            print(f"[SYNC] Descargando {title} desde GitHub raw...")
            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            res = requests.get(remote_info["download_url"], headers=self.headers, timeout=30)
            if res.status_code == 200:
                with open(dest_path, "wb") as f:
                    f.write(res.content)
                print(f"[SYNC] {title} descargado con éxito.")
                return {"status": "downloaded", "path": dest_path}
            else:
                print(f"[SYNC] Error descargando {title}: HTTP {res.status_code}")
                return {"status": "error"}
        except Exception as e:
            print("[SYNC] Error copiando BD desde repo:", e)
            return {"status": "error"}

    def upload_file(self, local_path, remote_title=None, subfolder=None):
        """ Encola el archivo local para ser subido mediante process_queue(). """
        if not self.is_ready:
            return {"status": "queued"}
            
        if not os.path.exists(local_path):
            return {"status": "not_found"}
            
        remote_title = remote_title or os.path.basename(local_path)
        self.upload_queue[remote_title] = local_path
        return {"status": "uploaded"}

    def process_queue(self):
        """ 
        Sube todas las bases encoladas a GitHub mediante llamadas PUT REST API,
        evitando subir archivos si el hash coincide.
        """
        if not self.is_ready:
            return False
            
        success = True
        for title, local_path in self.upload_queue.items():
            try:
                local_sha = self.get_git_sha1(local_path)
                remote_sha = self.remote_files.get(title, {}).get("sha")
                
                # Si son idénticos, no subimos nada
                if local_sha and remote_sha and local_sha == remote_sha:
                    print(f"[SYNC] Saltando subida de {title}: idéntico en remoto.")
                    continue
                    
                print(f"[SYNC] Subiendo {title} a GitHub mediante API REST...")
                with open(local_path, "rb") as f:
                    content_bytes = f.read()
                
                content_b64 = base64.b64encode(content_bytes).decode("utf-8")
                
                url = f"https://api.github.com/repos/{self.owner}/{self.repo}/contents/{title}"
                body = {
                    "message": f"Auto DB Sync - {time.strftime('%Y-%m-%d %H:%M:%S')}",
                    "content": content_b64
                }
                if remote_sha:
                    body["sha"] = remote_sha
                    
                res = requests.put(url, headers=self.headers, json=body, timeout=30)
                if res.status_code in [200, 201]:
                    print(f"[SYNC] Subido {title} con éxito.")
                    res_json = res.json()
                    self.remote_files[title] = {
                        "sha": res_json["content"]["sha"],
                        "size": res_json["content"]["size"],
                        "download_url": res_json["content"]["download_url"]
                    }
                else:
                    print(f"[SYNC] Error subiendo {title}: {res.status_code} - {res.text}")
                    success = False
            except Exception as e:
                print(f"[SYNC] Excepción subiendo {title}: {e}")
                success = False
                
        self.upload_queue.clear()
        return success
