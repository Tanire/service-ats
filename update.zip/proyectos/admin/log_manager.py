import sqlite3
import os
from datetime import datetime
from pathlib import Path

class LogManager:
    def __init__(self, db_path):
        self.db_path = db_path
        self._ensure_table()

    def _ensure_table(self):
        try:
            os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            c.execute("""
                CREATE TABLE IF NOT EXISTS movimientos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    usuario TEXT,
                    accion TEXT,
                    detalles TEXT
                )
            """)
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Error initializing log db: {e}")

    def log(self, usuario, accion, detalles=""):
        """Registra un nuevo evento en el log."""
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            c.execute("INSERT INTO movimientos (timestamp, usuario, accion, detalles) VALUES (?,?,?,?)",
                      (ts, usuario, accion, detalles))
            conn.commit()
            conn.close()
        except Exception as e:
            print(f"Error logging action: {e}")

    def get_logs(self, limit=500):
        """Obtiene los últimos N logs, ordenados por fecha descendente."""
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            c.execute("SELECT timestamp, usuario, accion, detalles FROM movimientos ORDER BY id DESC LIMIT ?", (limit,))
            rows = c.fetchall()
            conn.close()
            return rows
        except Exception as e:
            print(f"Error getting logs: {e}")
            return []

    def clear_logs(self):
        """Opcional: Limpiar logs antiguos"""
        try:
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            c.execute("DELETE FROM movimientos")
            conn.commit()
            conn.close()
        except:
            pass
