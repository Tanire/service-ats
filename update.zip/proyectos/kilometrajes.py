import tkinter as tk
from tkinter import ttk, messagebox, filedialog, simpledialog
import threading, time, math

try:
    from geopy.geocoders import Nominatim
    HAS_GEOPY = True
except Exception:
    HAS_GEOPY = False

try:
    import requests
    HAS_REQUESTS = True
except Exception:
    HAS_REQUESTS = False

try:
    import pandas as pd
    HAS_PANDAS = True
except Exception:
    HAS_PANDAS = False


class KilometrajesApp:
    def __init__(self, parent, conn=None, current_user=None):
        self.parent = parent
        self.conn = conn
        self.current_user = current_user or {"username": "anon", "is_admin": 0}
        self.stop_event = threading.Event()
        self.mi_ubicacion = None
        
        # UI Setup
        self.win = ttk.Frame(self.parent)
        self.win.pack(fill="both", expand=True)
        
        # Mapa Widget (tkintermapview)
        self.map_widget = None
        self.markers = []
        
        self._build_ui()
        # Auto-detectar ubicación al abrir
        self.win.after(800, self.obtener_mi_ubicacion)

    def _build_ui(self):
        # Header
        top_frame = tk.Frame(self.win, bg="#fafafa", pady=10, padx=10)
        top_frame.pack(fill="x")
        
        tk.Label(top_frame, text="Calculadora de Desplazamientos", font=("Segoe UI", 16, "bold"), bg="#fafafa").pack(side="left")
        
        self.lbl_miubic = tk.Label(top_frame, text="Detectando ubicación...", font=("Segoe UI", 10), bg="#fafafa", fg="#555")
        self.lbl_miubic.pack(side="right")
        
        btn_gps_frame = tk.Frame(top_frame, bg="#fafafa")
        btn_gps_frame.pack(side="right", padx=10)
        
        tk.Button(btn_gps_frame, text="📍 Auto GPS", command=self.obtener_mi_ubicacion, 
                 font=("Segoe UI", 9), bg="#e1f5fe").pack(side="left", padx=2)
        tk.Button(btn_gps_frame, text="✏️ Manual", command=self.definir_ubicacion_manual, 
                 font=("Segoe UI", 9), bg="#fff9c4").pack(side="left", padx=2)

        # PanedWindow Principal (Izquierda: Datos, Derecha: Mapa)
        paned = tk.PanedWindow(self.win, orient="horizontal", sashrelief="raised", sashwidth=4)
        paned.pack(fill="both", expand=True)

        # -- CRISTAL IZQUIERDO: INPUTS Y TABLA --
        left_frame = ttk.Frame(paned, padding=10)
        paned.add(left_frame, minsize=420, stretch="always")

        # Sección Búsqueda
        search_frame = ttk.LabelFrame(left_frame, text="Búsqueda", padding=10)
        search_frame.pack(fill="x", pady=(0, 10))
        
        # Notebook
        nb = ttk.Notebook(search_frame)
        nb.pack(fill="x", padx=5, pady=5)
        
        # TAB 1: Dirección Detallada
        tab_det = ttk.Frame(nb, padding=10)
        nb.add(tab_det, text="Dirección Detallada")
        
        ttk.Label(tab_det, text="Calle / Dirección:").grid(row=0, column=0, sticky="w", padx=5)
        self.entry_direccion = ttk.Entry(tab_det, width=35)
        self.entry_direccion.grid(row=0, column=1, columnspan=3, sticky="we", padx=5, pady=5)
        
        ttk.Label(tab_det, text="CP:").grid(row=0, column=4, sticky="w", padx=5)
        self.entry_cp = ttk.Entry(tab_det, width=8)
        self.entry_cp.grid(row=0, column=5, sticky="w", padx=5, pady=5)
        
        ttk.Label(tab_det, text="Ciudad:").grid(row=1, column=0, sticky="w", padx=5)
        self.entry_ciudad = ttk.Entry(tab_det, width=18)
        self.entry_ciudad.grid(row=1, column=1, sticky="w", padx=5, pady=5)
        
        ttk.Label(tab_det, text="Provincia:").grid(row=1, column=2, sticky="w", padx=5)
        self.entry_provincia = ttk.Entry(tab_det, width=18)
        self.entry_provincia.grid(row=1, column=3, sticky="w", padx=5, pady=5)
        
        # TAB 2: Lista Rápida (Text)
        tab_list = ttk.Frame(nb, padding=10)
        nb.add(tab_list, text="Lista Rápida (Varios)")
        
        ttk.Label(tab_list, text="Introduce poblaciones o lugares (uno por línea):").pack(anchor="w")
        self.txt_batch = tk.Text(tab_list, height=5, font=("Consolas", 9))
        self.txt_batch.pack(fill="x", pady=5)

        # Botones Acción
        btn_frame = ttk.Frame(search_frame)
        btn_frame.pack(fill="x", pady=10)
        
        ttk.Button(btn_frame, text="🔍 Buscar Todo", command=self.buscar_ubicaciones).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="🚗 Calcular Rutas (OSRM)", command=self.calcular_desplazamiento).pack(side="left", padx=5)
        ttk.Button(btn_frame, text="🧹 Limpiar", command=self._limpiar_campos).pack(side="left", padx=5)
        
        # Resultados
        res_frame = ttk.LabelFrame(left_frame, text="Resultados", padding=10)
        res_frame.pack(fill="both", expand=True)
        
        cols = ("Búsqueda", "Dirección", "CP", "Distancia", "Tiempo", "Lat", "Lon")
        self.tree = ttk.Treeview(res_frame, columns=cols, show="headings")
        
        self.tree.heading("Búsqueda", text="Término")
        self.tree.column("Búsqueda", width=100)
        self.tree.heading("Dirección", text="Dirección")
        self.tree.column("Dirección", width=250)
        self.tree.heading("CP", text="CP")
        self.tree.column("CP", width=60)
        self.tree.heading("Distancia", text="Km")
        self.tree.column("Distancia", width=60, anchor="e")
        self.tree.heading("Tiempo", text="Tiempo")
        self.tree.column("Tiempo", width=70, anchor="e")
        self.tree.heading("Lat", text="Lat")
        self.tree.column("Lat", width=0, stretch=False)
        self.tree.heading("Lon", text="Lon")
        self.tree.column("Lon", width=0, stretch=False)
        
        sb = ttk.Scrollbar(res_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscroll=sb.set)
        
        self.tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self.tree.bind('<<TreeviewSelect>>', self._on_tree_select)
        
        bot_frame = ttk.Frame(left_frame)
        bot_frame.pack(fill="x", pady=5)
        ttk.Button(bot_frame, text="Exportar Excel", command=self.exportar_excel).pack(side="right", padx=5)

        # -- CRISTAL DERECHO: MAPA --
        right_frame = ttk.LabelFrame(paned, text="Plano Interactivo", padding=10)
        paned.add(right_frame, minsize=400, width=500)
        
        # Intentar cargar tkintermapview
        try:
            import tkintermapview
            self.map_widget = tkintermapview.TkinterMapView(right_frame, width=400, height=400, corner_radius=0)
            self.map_widget.pack(fill="both", expand=True)
            self.map_widget.set_tile_server("https://mt0.google.com/vt/lyrs=m&hl=es&x={x}&y={y}&z={z}", max_zoom=22) # Google Maps like
        except ImportError:
            tk.Label(right_frame, text="Instala 'tkintermapview' para ver el mapa 3D.\nMostrando vista radar simple.", bg="yellow").pack(fill="x")
            self.map_canvas = tk.Canvas(right_frame, bg="#111")
            self.map_canvas.pack(fill="both", expand=True)
            self.map_widget = None

    # ------------------------------------------
    # LÓGICA GEO & MAPA
    # ------------------------------------------
    def _dibujar_mapa(self):
        """Actualiza el mapa (Widget o Canvas) con puntos: mi_ubicacion + tree items"""
        # Recopilar todos los puntos
        puntos = []
        if self.mi_ubicacion:
            puntos.append({"lat": self.mi_ubicacion["lat"], "lon": self.mi_ubicacion["lon"], "label": "YO", "type": "me"})
            
        for i in self.tree.get_children():
            v = self.tree.item(i, "values") # (Busq, Dir, CP, Dist, Time, Lat, Lon)
            if v[5] and v[6]:
                puntos.append({"lat": float(v[5]), "lon": float(v[6]), "label": v[0], "type": "dest"})
        
        # SI USAMOS TKINTERMAPVIEW
        if self.map_widget:
            self.map_widget.delete_all_marker()
            path_coords = []
            
            for p in puntos:
                if p["type"] == "me":
                    self.map_widget.set_position(p["lat"], p["lon"]) # Centrar en mi
                    m = self.map_widget.set_marker(p["lat"], p["lon"], text="Tu Ubicación", marker_color_circle="blue", marker_color_outside="lightblue")
                    path_coords.append((p["lat"], p["lon"]))
                else:
                    self.map_widget.set_marker(p["lat"], p["lon"], text=p["label"])
                    path_coords.append((p["lat"], p["lon"]))
            
            # Ajustar zoom para ver todos
            if len(puntos) > 1:
                lats = [p['lat'] for p in puntos]
                lons = [p['lon'] for p in puntos]
                min_lat, max_lat = min(lats), max(lats)
                min_lon, max_lon = min(lons), max(lons)
                
                # Evitar error si son iguales o muy cerca
                if max_lat - min_lat < 0.0001: max_lat += 0.001; min_lat -= 0.001
                if max_lon - min_lon < 0.0001: max_lon += 0.001; min_lon -= 0.001
                
                # fit_bounding_box(top_left, bottom_right) -> (lat_max, lon_min), (lat_min, lon_max)
                try:
                    self.map_widget.fit_bounding_box((max_lat, min_lon), (min_lat, max_lon))
                except: pass
            elif self.mi_ubicacion:
                 self.map_widget.set_zoom(12)

        # SI USAMOS CANVAS (Radar)
        else:
            self.map_canvas.delete("all")
            w, h = self.map_canvas.winfo_width(), self.map_canvas.winfo_height()
            self.map_canvas.create_line(w/2, 0, w/2, h, fill="#333", dash=(2,4))
            self.map_canvas.create_line(0, h/2, w, h/2, fill="#333", dash=(2,4))
            
            if not puntos: return
            
            # Bounding box
            lats = [p["lat"] for p in puntos]
            lons = [p["lon"] for p in puntos]
            min_lat, max_lat = min(lats), max(lats)
            min_lon, max_lon = min(lons), max(lons)
            
            diff_lat = (max_lat - min_lat) or 0.01
            diff_lon = (max_lon - min_lon) or 0.01
            
            margin = 0.2
            
            def to_scr(lat, lon):
                # Normalizar 0..1
                ny = (max_lat - lat) / (diff_lat * (1+margin)) + (margin/2)
                nx = (lon - min_lon) / (diff_lon * (1+margin)) + (margin/2)
                return nx * w, ny * h

            for p in puntos:
                x, y = to_scr(p["lat"], p["lon"])
                col = "#00ff00" if p["type"] == "me" else "#ff4444"
                sz = 8 if p["type"] == "me" else 5
                
                self.map_canvas.create_oval(x-sz, y-sz, x+sz, y+sz, fill=col, outline="white")
                self.map_canvas.create_text(x, y-15, text=p["label"], fill="white", font=("Arial", 8))

    def obtener_mi_ubicacion(self):
        if not HAS_REQUESTS:
            self.lbl_miubic.config(text="Falta requests", fg="red")
            return
            
        def _task():
            self.win.after(0, lambda: self.lbl_miubic.config(text="Buscando GPS...", fg="blue"))
            found = False
            data = {}
            
            # Intento 1: ipapi.co
            try:
                r = requests.get("https://ipapi.co/json/", timeout=4)
                if r.ok:
                    d = r.json()
                    data = {"lat": d.get("latitude"), "lon": d.get("longitude"), 
                            "city": d.get("city"), "region": d.get("region_code")}
                    found = True
            except: pass
            
            # Intento 2: ip-api.com
            if not found:
                try:
                    r = requests.get("http://ip-api.com/json", timeout=4)
                    if r.ok:
                        d = r.json()
                        data = {"lat": d.get("lat"), "lon": d.get("lon"), 
                                "city": d.get("city"), "region": d.get("region")}
                        found = True
                except: pass
                
            if found and data.get("lat"):
                self.mi_ubicacion = data
                txt = f"📍 {data['city']} ({data['region']})"
                self.win.after(0, lambda: self._update_ui_loc(txt))
            else:
                self.win.after(0, lambda: self.lbl_miubic.config(text="⚠️ GPS Falló - Úsalo Manual", fg="orange"))
                
        threading.Thread(target=_task, daemon=True).start()

    def definir_ubicacion_manual(self):
        addr = simpledialog.askstring("Ubicación Manual", "Introduce tu dirección actual (Ciudad, Calle...):")
        if not addr: return
        
        def _task():
            try:
                url = "https://nominatim.openstreetmap.org/search"
                params = {"q": addr, "format": "json", "limit": 1}
                headers = {"User-Agent": "ServiceATS/1.0"}
                r = requests.get(url, params=params, headers=headers, timeout=5)
                res = r.json()
                if res:
                    item = res[0]
                    self.mi_ubicacion = {
                        "lat": float(item["lat"]),
                        "lon": float(item["lon"]),
                        "city": item.get("display_name", "").split(",")[0],
                        "region": "Manual"
                    }
                    txt = f"📍 {self.mi_ubicacion['city']} (Manual)"
                    self.win.after(0, lambda: self._update_ui_loc(txt))
                else:
                    self.win.after(0, lambda: messagebox.showwarning("Error", "Dirección no encontrada."))
            except Exception as e:
                print(e)
        
        threading.Thread(target=_task, daemon=True).start()

    def _update_ui_loc(self, txt):
        self.lbl_miubic.config(text=txt, fg="#2e7d32")
        self._dibujar_mapa()

    def buscar_ubicaciones(self):
        # Recopilar queries
        queries = []
        # 1. Campos detallados
        parts = [
            self.entry_direccion.get().strip(),
            self.entry_cp.get().strip(),
            self.entry_ciudad.get().strip(),
            self.entry_provincia.get().strip()
        ]
        q_det = ", ".join([p for p in parts if p])
        if q_det: queries.append(q_det)
            
        # 2. Lista rápida
        raw_batch = self.txt_batch.get("1.0", "end").strip()
        if raw_batch:
            lines = [l.strip() for l in raw_batch.splitlines() if l.strip()]
            queries.extend(lines)
            
        if not queries:
            messagebox.showinfo("Búsqueda", "Introduce datos para buscar.")
            return

        def _task():
            if not HAS_REQUESTS:
                self.win.after(0, lambda: messagebox.showerror("Error", "Falta librería 'requests'. No se puede buscar online."))
                return

            self.win.after(0, self._limpiar_tabla)
            self.win.after(0, lambda: self.lbl_miubic.config(text="Buscando...", fg="blue"))
            
            found_count = 0
            errors = []
            
            for q in queries:
                try:
                    print(f"DEBUG: Buscando '{q}' en Nominatim...")
                    url = "https://nominatim.openstreetmap.org/search"
                    params = {"q": q, "format": "json", "limit": 1, "addressdetails": 1}
                    headers = {"User-Agent": "ServiceATS/1.0"}
                    
                    r = requests.get(url, params=params, headers=headers, timeout=5)
                    results = r.json()
                    
                    if results:
                        item = results[0]
                        addr = item.get("address", {})
                        
                        full_addr = f"{addr.get('road','')} {addr.get('house_number','')}".strip() or item.get("display_name","").split(",")[0]
                        
                        # Fallback ciudad/pueblo
                        city = addr.get("city") or addr.get("town") or addr.get("village") or addr.get("municipality") or ""
                        
                        full_desc = f"{full_addr}, {city}" if city else full_addr

                        lat = float(item.get("lat"))
                        lon = float(item.get("lon"))
                        
                        row = (q, full_desc, addr.get("postcode", ""), "---", "---", lat, lon)
                        self.win.after(0, lambda r=row: self.tree.insert("", "end", values=r))
                        found_count += 1
                    else:
                        print(f"DEBUG: Sin resultados para '{q}'")
                        
                    time.sleep(0.5)
                except Exception as e:
                    print(f"Error: {e}")
                    errors.append(str(e))
            
            self.win.after(0, self._dibujar_mapa)
            self.win.after(0, lambda: self.lbl_miubic.config(text=f"Búsqueda fin. ({found_count} resultados)", fg="black"))
            
            if found_count == 0:
                msg = "No se encontraron resultados."
                if errors: msg += f"\nErrores: {', '.join(errors)}"
                self.win.after(0, lambda: messagebox.showinfo("Resultados", msg))

        threading.Thread(target=_task, daemon=True).start()

    def calcular_desplazamiento(self):
        if not self.mi_ubicacion:
            messagebox.showwarning("Origen", "Falta ubicación.")
            return
        items = self.tree.get_children()
        if not items: return
        
        def _task():
            orig_lat = self.mi_ubicacion["lat"]
            orig_lon = self.mi_ubicacion["lon"]
            
            for item in items:
                vals = list(self.tree.item(item, "values"))
                # vals: Busq(0), Dir(1), CP(2), Dist(3), Time(4), Lat(5), Lon(6)
                try:
                    dest_lat = vals[5]
                    dest_lon = vals[6]
                    
                    url = f"http://router.project-osrm.org/route/v1/driving/{orig_lon},{orig_lat};{dest_lon},{dest_lat}?overview=false"
                    r = requests.get(url, timeout=5)
                    data = r.json()
                    
                    if data.get("code") == "Ok" and data.get("routes"):
                        route = data["routes"][0]
                        dist_km = route["distance"] / 1000
                        dur_s = route["duration"]
                        
                        hours = int(dur_s // 3600)
                        mins = int((dur_s % 3600) // 60)
                        time_str = f"{hours}h {mins}m" if hours > 0 else f"{mins}m"
                        
                        vals[3] = f"{dist_km:.2f}"
                        vals[4] = time_str
                        
                        self.win.after(0, lambda i=item, v=vals: self.tree.item(i, values=v))
                    time.sleep(0.2)
                except: pass

        threading.Thread(target=_task, daemon=True).start()

    def _limpiar_campos(self):
        self.entry_direccion.delete(0, tk.END)
        self.txt_batch.delete("1.0", tk.END)
        self._limpiar_tabla()
        self._dibujar_mapa()

    def _limpiar_tabla(self):
        for i in self.tree.get_children(): self.tree.delete(i)

    def _on_tree_select(self, event):
        sel = self.tree.selection()
        if not sel: return
        v = self.tree.item(sel[0], "values")
        if self.map_widget and v[5] and v[6]:
            self.map_widget.set_position(float(v[5]), float(v[6]))
            self.map_widget.set_zoom(14)

    def exportar_excel(self):
        if not HAS_PANDAS:
            messagebox.showerror("Error", "Necesitas pandas instalado.")
            return
        
        datos = [self.tree.item(i, "values") for i in self.tree.get_children()]
        if not datos: return
        df = pd.DataFrame(datos, columns=list(self.tree["columns"]))
        f = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
        if f: df.to_excel(f, index=False); messagebox.showinfo("Exportado", "OK")

    def on_close(self): pass