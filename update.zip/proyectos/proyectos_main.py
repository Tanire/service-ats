import tkinter as tk
from tkinter import messagebox
from proyectos.kilometrajes import KilometrajesApp
from proyectos.licitaciones import LicitacionesApp
from proyectos.valoraciones import ValoracionesApp, ConfiguracionProyectos

class ProyectosMain:
    def __init__(self, parent, conn, current_user):
        self.parent = parent
        self.conn = conn
        self.current_user = current_user
        self.build_ui()

    def build_ui(self):
        frame = tk.Frame(self.parent, bg="white")
        frame.pack(expand=True, fill="both")

        tk.Label(frame, text="Gestor de Proyectos", font=("Segoe UI", 28, "bold"),
                 fg="#004080", bg="white").pack(pady=40)

        btns = tk.Frame(frame, bg="white")
        btns.pack(pady=40)

        opciones = [
            ("Valoraciones", "#2e7d32", self.abrir_valoraciones),
            ("Kilometrajes", "#1976d2", self.abrir_kilometrajes),
            ("Licitaciones", "#1976d2", self.abrir_licitaciones),
            ("Ajustes", "#0277bd", self.abrir_ajustes),
        ]

        for texto, color, cmd in opciones:
            tk.Button(btns, text=texto, bg=color, fg="white", relief="flat",
                      font=("Segoe UI", 16, "bold"), width=25, height=2,
                      command=cmd).pack(pady=10)

        if isinstance(self.parent, tk.Toplevel):
            tk.Button(frame, text="Cerrar", bg="#d32f2f", fg="white",
                      font=("Segoe UI", 12, "bold"),
                      command=self.parent.destroy).pack(pady=30)

    def abrir_kilometrajes(self):
        km_win = tk.Toplevel(self.parent)
        km_win.title("Kilometrajes")
        km_win.state("zoomed")
        km_win.grab_set()
        KilometrajesApp(km_win, self.conn, self.current_user)

    def abrir_licitaciones(self):
        lic_win = tk.Toplevel(self.parent)
        lic_win.title("Licitaciones")
        lic_win.state("zoomed")
        lic_win.grab_set()
        LicitacionesApp(lic_win, self.conn, self.current_user)

    def abrir_valoraciones(self):
        val_win = tk.Toplevel(self.parent)
        val_win.title("Valoraciones y Presupuestos")
        val_win.state("zoomed")
        val_win.grab_set()
        ValoracionesApp(val_win, self.current_user)

    def abrir_ajustes(self):
        # Verificar Admin
        if not self.current_user or not self.current_user.get("is_admin"):
            messagebox.showerror("Acceso Denegado", "Solo los administradores pueden acceder a la configuración de precios y base de datos.")
            return
            
        ConfiguracionProyectos(self.parent)
