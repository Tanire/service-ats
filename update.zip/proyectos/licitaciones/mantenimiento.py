# proyectos/licitaciones/mantenimiento.py
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import csv
import sqlite3
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation
import uuid
from datetime import datetime
import json
from utils_paths import get_resource_path
import sqlite3

# db_path moved to method to avoid import error
# conn_elem removed from global scope



# Para exportar a Excel
try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

# Para generar PDF
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import cm
    PDF_AVAILABLE = True
except ImportError:
    PDF_AVAILABLE = False

# Try imports
try:
    import requests
except ImportError:
    requests = None

try:
    from proyectos.kilometrajes import KilometrajesApp
except ImportError:
    KilometrajesApp = None

# Para gráficos
try:
    import matplotlib.pyplot as plt
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    import matplotlib
    matplotlib.use('TkAgg')
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False


class MantenimientoLicitacionesApp:
    # Equipos organizados por categorías
    EQUIPOS_CCTV = [
        "CAMARA EXTERIOR ACCESIBLE",
        "CAMARA EXTERIOR C/ESCALERA ALTA",
        "CAMARA EXTERIOR C/ELEVADORA",
        "DOMO EXTERIOR",
        "DOMO EXTERIOR C/ESCALERA ALTA",
        "DOMO EXTERIOR C/ELEVADORA",
        "CAMARA INTERIOR",
        "CAMARA INTERIOR C/ESCALERA ALTA",
        "VIDEOGRABADOR",
        "SERVIDOR ANALITICA DE VIDEO",
        "PC GESTION",
        "MONITOR",
        "TECLADO CCTV",
        "SWITCH",
        "RACK Y SAI",
        "ANALISIS DE VIDEO EMBEBIDO",
        "FOCOS ILUMINACION"
    ]
    
    EQUIPOS_INTRUSION = [
        "CENTRAL",
        "TECLADO",
        "MODULO GSM/GPRS/IP",
        "FUENTE DE ALIMENTACION Y BATERIA",
        "CUADROS DISTRIBUCION",
        "SIRENA INTERIOR",
        "SIRENA EXTERIOR",
        "MAGNETICO GP",
        "MAGNETICO IR LARGO ALCANCE",
        "VOLUMETRICO ESTANDAR",
        "VOLUMETRICO VIA RADIO",
        "DETECTOR ROTURA CRISTAL",
        "SENSOR SISMICO",
        "GRUPO BARRERA IR",
        "GRUPO BARRERA MICROONDAS",
        "CABLE SENSOR (ZONAS)",
        "SENALES TECNICAS"
    ]
    
    # Plantillas predefinidas (actualizadas con nuevos campos)
    TIEMPOS_MANTENIMIENTO = {
        # CCTV
        "CAMARA EXTERIOR ACCESIBLE": 15,
        "CAMARA EXTERIOR C/ESCALERA ALTA": 20,
        "CAMARA EXTERIOR C/ELEVADORA": 30,
        "DOMO EXTERIOR": 20,
        "DOMO EXTERIOR C/ESCALERA ALTA": 25,
        "DOMO EXTERIOR C/ELEVADORA": 35,
        "CAMARA INTERIOR": 15,
        "CAMARA INTERIOR C/ESCALERA ALTA": 20,
        "VIDEOGRABADOR": 20,
        "SERVIDOR ANALITICA DE VIDEO": 30,
        "PC GESTION": 20,
        "MONITOR": 5,
        "TECLADO CCTV": 5,
        "SWITCH": 10,
        "RACK Y SAI": 15,
        "ANALISIS DE VIDEO EMBEBIDO": 5,
        "FOCOS ILUMINACION": 10,
        # INTRUSION
        "CENTRAL": 20,
        "TECLADO": 10,
        "MODULO GSM/GPRS/IP": 10,
        "FUENTE DE ALIMENTACION Y BATERIA": 10,
        "CUADROS DISTRIBUCION": 10,
        "SIRENA INTERIOR": 5,
        "SIRENA EXTERIOR": 10,
        "MAGNETICO GP": 5,
        "MAGNETICO IR LARGO ALCANCE": 10,
        "VOLUMETRICO ESTANDAR": 10,
        "VOLUMETRICO VIA RADIO": 10,
        "DETECTOR ROTURA CRISTAL": 10,
        "SENSOR SISMICO": 10,
        "GRUPO BARRERA IR": 20,
        "GRUPO BARRERA MICROONDAS": 20,
        "CABLE SENSOR (ZONAS)": 20,
        "SENALES TECNICAS": 5
    }

    def __init__(self, parent, conn, current_user):
        self.parent = parent
        self.conn = conn
        self.current_user = current_user

        self.centers = []
        self.cost_per_km = Decimal('0.30')
        self.cost_per_hour = Decimal('20.00')
        self.margen_beneficio = Decimal('0.15')
        self.cost_cra = Decimal('0.00')
        self.cost_sim = Decimal('0.00')
        self.cost_acuda = Decimal('0.00')
        
        self.licitacion_actual = None
        
        self.licitacion_actual = None
        
        self._crear_tablas_db()
        self._migrar_db()
        
        # Conexión local a productos.db (si existe)
        try:
            prod_path = get_resource_path("proyectos/licitaciones/productos.db")
            self.conn_elem = sqlite3.connect(prod_path)
        except Exception:
            self.conn_elem = None # Fallback si no existe
            
        self.build_ui()
        self._cargar_o_crear_licitacion()

    def _crear_tablas_db(self):
        """Crea las tablas necesarias en la base de datos"""
        cursor = self.conn.cursor()
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS licitaciones (
                id TEXT PRIMARY KEY,
                nombre TEXT,
                fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                cost_per_km REAL,
                cost_per_hour REAL,
                margen_beneficio REAL,
                cost_cra REAL DEFAULT 0,
                cost_sim REAL DEFAULT 0,
                cost_acuda REAL DEFAULT 0,
                usuario TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS centros_licitacion (
                id TEXT PRIMARY KEY,
                licitacion_id TEXT,
                nombre TEXT,
                km_ida REAL,
                km_vuelta REAL,
                t_ida REAL,
                t_mant REAL,
                t_vuelta REAL,
                n_tecnicos INTEGER,
                conectado_cra INTEGER,
                num_sims INTEGER DEFAULT 0,
                servicio_acuda INTEGER DEFAULT 0,
                equipos_json TEXT,
                tipo_mantenimiento TEXT DEFAULT 'Personalizado',
                visitas_presenciales INTEGER DEFAULT 1,
                visitas_remotas INTEGER DEFAULT 0,
                minutos_remoto INTEGER DEFAULT 15,
                fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (licitacion_id) REFERENCES licitaciones(id)
            )
        ''')
        
        self.conn.commit()

    def _migrar_db_v2(self):
        """Añade columnas para v1.15.2 (Tipos mant.) si no existen"""
        cursor = self.conn.cursor()
        try:
            cursor.execute("ALTER TABLE centros_licitacion ADD COLUMN tipo_mantenimiento TEXT DEFAULT 'Personalizado'")
        except: pass
        try:
            cursor.execute("ALTER TABLE centros_licitacion ADD COLUMN visitas_presenciales INTEGER DEFAULT 1")
        except: pass
        try:
            cursor.execute("ALTER TABLE centros_licitacion ADD COLUMN visitas_remotas INTEGER DEFAULT 0")
        except: pass
        try:
            cursor.execute("ALTER TABLE centros_licitacion ADD COLUMN minutos_remoto INTEGER DEFAULT 15")
        except: pass
        self.conn.commit()

    def _migrar_db(self):
        """Añade columnas nuevas si no existen (Migración robusta)"""
        cursor = self.conn.cursor()
        
        # Lista de columnas a verificar en licitaciones
        cols_lic = {
            "cost_cra": "REAL DEFAULT 0",
            "cost_sim": "REAL DEFAULT 0",
            "cost_acuda": "REAL DEFAULT 0"
        }
        for col, dtype in cols_lic.items():
            try:
                cursor.execute(f"ALTER TABLE licitaciones ADD COLUMN {col} {dtype}")
            except: pass

        # Lista de columnas a verificar en centros_licitacion
        cols_cen = {
            "conectado_cra": "INTEGER DEFAULT 0",
            "num_sims": "INTEGER DEFAULT 0",
            "servicio_acuda": "INTEGER DEFAULT 0",
            "tipo_mantenimiento": "TEXT DEFAULT 'Personalizado'",
            "visitas_presenciales": "INTEGER DEFAULT 1",
            "visitas_remotas": "INTEGER DEFAULT 0",
            "minutos_remoto": "INTEGER DEFAULT 15",
            "equipos_json": "TEXT" 
        }
        for col, dtype in cols_cen.items():
            try:
                cursor.execute(f"ALTER TABLE centros_licitacion ADD COLUMN {col} {dtype}")
            except: pass
        
        self.conn.commit()

    def _cargar_o_crear_licitacion(self):
        """Carga la última licitación o crea una nueva"""
        username = self.current_user.get("username", "Desconocido") if isinstance(self.current_user, dict) else str(self.current_user)
        
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT id, nombre, cost_per_km, cost_per_hour, margen_beneficio,
                   cost_cra, cost_sim, cost_acuda
            FROM licitaciones 
            WHERE usuario = ?
            ORDER BY fecha_creacion DESC 
            LIMIT 1
        ''', (username,))
        
        row = cursor.fetchone()
        if row:
            self.licitacion_actual = row[0]
            self.cost_per_km = Decimal(str(row[2]))
            self.cost_per_hour = Decimal(str(row[3]))
            self.margen_beneficio = Decimal(str(row[4]))
            self.cost_cra = Decimal(str(row[5] if row[5] else 0))
            self.cost_sim = Decimal(str(row[6] if row[6] else 0))
            self.cost_acuda = Decimal(str(row[7] if row[7] else 0))
            
            self.ent_cost_km.delete(0, "end")
            self.ent_cost_km.insert(0, str(self.cost_per_km))
            self.ent_cost_h.delete(0, "end")
            self.ent_cost_h.insert(0, str(self.cost_per_hour))
            self.ent_margen.delete(0, "end")
            self.ent_margen.insert(0, str(float(self.margen_beneficio * 100)))
            self.ent_cra.delete(0, "end"); self.ent_cra.insert(0, str(self.cost_cra))
            self.ent_sim.delete(0, "end"); self.ent_sim.insert(0, str(self.cost_sim))
            self.ent_acuda.delete(0, "end"); self.ent_acuda.insert(0, str(self.cost_acuda))
            
            self.parent.title(f"Mantenimiento - {row[1]}")
            self._cargar_centros_db()
        else:
            self._crear_nueva_licitacion()

    def _crear_nueva_licitacion(self, nombre=None):
        """Crea una nueva licitación"""
        if nombre is None:
            nombre = f"Licitación {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        
        self.licitacion_actual = str(uuid.uuid4())
        username = self.current_user.get("username", "Desconocido") if isinstance(self.current_user, dict) else str(self.current_user)
        
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO licitaciones (id, nombre, cost_per_km, cost_per_hour, margen_beneficio, cost_cra, cost_sim, cost_acuda, usuario)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            self.licitacion_actual, nombre,
            float(self.cost_per_km), float(self.cost_per_hour),
            float(self.margen_beneficio), float(self.cost_cra), float(self.cost_sim), float(self.cost_acuda),
            username
        ))
        self.conn.commit()
        self.parent.title(f"Mantenimiento - {nombre}")
        messagebox.showinfo("Nueva Licitación", f"Licitación creada: {nombre}")

    def _cargar_centros_db(self):
        """Carga centros desde la base de datos"""
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT id, nombre, km_ida, km_vuelta, t_ida, t_mant, t_vuelta,
                   n_tecnicos, conectado_cra, num_sims, servicio_acuda, equipos_json,
                   tipo_mantenimiento, visitas_presenciales, visitas_remotas, minutos_remoto
            FROM centros_licitacion 
            WHERE licitacion_id = ?
            ORDER BY fecha_creacion
        ''', (self.licitacion_actual,))
        
        for row in cursor.fetchall():
            equipos = json.loads(row[11])
            centro = {
                "id": row[0],
                "nombre": row[1],
                "km_ida": Decimal(str(row[2])),
                "km_vuelta": Decimal(str(row[3])),
                "t_ida": Decimal(str(row[4])),
                "t_mant": Decimal(str(row[5])),
                "t_vuelta": Decimal(str(row[6])),
                "n_tecnicos": row[7],
                "conectado_cra": bool(row[8]),
                "num_sims": int(row[9] if row[9] is not None else 0),
                "servicio_acuda": bool(row[10]),
                "equipos": equipos,
                "tipo_mantenimiento": row[12] if len(row) > 12 else "Personalizado",
                "visitas_presenciales": row[13] if len(row) > 13 else 1,
                "visitas_remotas": row[14] if len(row) > 14 else 0, 
                "minutos_remoto": row[15] if len(row) > 15 else 15
            }
            
            self._calcular_valores_derivados(centro)
            self.centers.append(centro)
            self._insert_tree(centro)
        
        if self.centers:
            self.calcular_totales()

    def _calcular_valores_derivados(self, centro):
        """Calcula valores derivados (km_total, horas, coste)"""
        km_total = centro["km_ida"] + centro["km_vuelta"]
        tiempo_total = centro["t_ida"] + centro["t_mant"] + centro["t_vuelta"]
        
        # Nuevos parámetros (DB puede devolver int/str, aseguramos tipos)
        n_visitas = Decimal(centro.get("visitas_presenciales", 1))
        n_remotas = Decimal(centro.get("visitas_remotas", 0))
        min_remoto = Decimal(centro.get("minutos_remoto", 15))
        
        # 1. Coste Viaje Total = Km por visita * Nº visitas
        coste_viaje = (km_total * self.cost_per_km) * n_visitas
        
        # 2. Mano de Obra Presencial (Viaje + Mant) * Nº Visitas
        horas_presenciales = (tiempo_total / Decimal(60)) * Decimal(centro["n_tecnicos"]) * n_visitas
        coste_mo_presencial = horas_presenciales * self.cost_per_hour
        
        # 3. Mano de Obra Remota (T. Remoto * N. Remotas)
        # Asumimos 1 técnico para remoto
        horas_remotas = (min_remoto / Decimal(60)) * n_remotas
        coste_mo_remota = horas_remotas * self.cost_per_hour
        
        coste_horas = coste_mo_presencial + coste_mo_remota
        horas_totales = horas_presenciales + horas_remotas
        
        # Servicios Adicionales (CRA, SIMs, Acuda) - PRECIOS MENSUALES -> ANUALES
        # User input is Monthly, so we multiply by 12 for the annual Budget
        coste_cra = (self.cost_cra * 12) if centro.get("conectado_cra") else Decimal(0)
        
        num_sims = Decimal(centro.get("num_sims", 0))
        coste_sim = (num_sims * self.cost_sim * 12)
        
        coste_acuda = (self.cost_acuda * 12) if centro.get("servicio_acuda") else Decimal(0)
        
        coste_base = coste_viaje + coste_horas + coste_cra + coste_sim + coste_acuda
        coste_con_margen = coste_base * (1 + self.margen_beneficio)
        
        # Totales para UI
        # Km totales anuales (Ida+Vuelta * Visitas)
        centro["km_total"] = (km_total * n_visitas).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        centro["horas_tecnicas"] = horas_totales.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        centro["coste_base"] = coste_base.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        centro["coste"] = coste_con_margen.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        
        # Guardar breakdown para visualización
        centro["_breakdown"] = {
            "viaje": coste_viaje, "horas": coste_horas, 
            "cra": coste_cra, "sim": coste_sim, "acuda": coste_acuda,
            "visitas": int(n_visitas), "remotas": int(n_remotas)
        }
        
        # Contar equipos totales
        centro["total_equipos"] = sum(centro.get("equipos", {}).values())

    def _guardar_centro_db(self, centro):
        """Guarda un centro en la base de datos"""
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO centros_licitacion 
            (id, licitacion_id, nombre, km_ida, km_vuelta, t_ida, t_mant, t_vuelta, 
             n_tecnicos, conectado_cra, num_sims, servicio_acuda, equipos_json,
             tipo_mantenimiento, visitas_presenciales, visitas_remotas, minutos_remoto)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            centro["id"], self.licitacion_actual, centro["nombre"],
            float(centro["km_ida"]), float(centro["km_vuelta"]),
            float(centro["t_ida"]), float(centro["t_mant"]), float(centro["t_vuelta"]),
            centro["n_tecnicos"],
            int(centro.get("conectado_cra", False)),
            int(centro.get("num_sims", 0)),
            int(centro.get("servicio_acuda", False)),
            json.dumps(centro.get("equipos", {})),
            centro.get("tipo_mantenimiento", "Personalizado"),
            centro.get("visitas_presenciales", 1),
            centro.get("visitas_remotas", 0),
            centro.get("minutos_remoto", 15)
        ))
        self.conn.commit()

    def _eliminar_centro_db(self, centro_id):
        """Elimina un centro de la base de datos"""
        cursor = self.conn.cursor()
        cursor.execute('DELETE FROM centros_licitacion WHERE id = ?', (centro_id,))
        self.conn.commit()

    def build_ui(self):
        self.parent.title("Mantenimiento - Cálculo de Costes")
        self.parent.state("zoomed")
        self.parent.configure(bg="white")

        # --- Encabezado ---
        top_frame = tk.Frame(self.parent, bg="white", pady=12)
        top_frame.pack(fill="x")

        tk.Label(top_frame, text="Cálculo de Costes de Mantenimiento", 
                 font=("Segoe UI", 20, "bold"), fg="#004080", bg="white").pack(anchor="w", padx=20)

        # --- Configuración ---
        cfg_frame = tk.LabelFrame(self.parent, text="Configuración de Costes", bg="white", padx=12, pady=8)
        cfg_frame.pack(fill="x", padx=20, pady=(5,0))

        # Fila 0: Precios Generales
        tk.Label(cfg_frame, text="€/km:", bg="white").grid(row=0, column=0, sticky="w")
        self.ent_cost_km = tk.Entry(cfg_frame, width=8)
        self.ent_cost_km.insert(0, str(self.cost_per_km))
        self.ent_cost_km.grid(row=0, column=1, padx=5)

        tk.Label(cfg_frame, text="€/hora:", bg="white").grid(row=0, column=2, sticky="w")
        self.ent_cost_h = tk.Entry(cfg_frame, width=8)
        self.ent_cost_h.insert(0, str(self.cost_per_hour))
        self.ent_cost_h.grid(row=0, column=3, padx=5)

        tk.Label(cfg_frame, text="Margen %:", bg="white").grid(row=0, column=4, sticky="w")
        self.ent_margen = tk.Entry(cfg_frame, width=8)
        self.ent_margen.insert(0, str(float(self.margen_beneficio * 100)))
        self.ent_margen.grid(row=0, column=5, padx=5)
        
        # Fila 1: Costes Servicios Add-on (MENSUALES)
        tk.Label(cfg_frame, text="CRA (Mes):", bg="white").grid(row=1, column=0, sticky="w", pady=5)
        self.ent_cra = tk.Entry(cfg_frame, width=8)
        self.ent_cra.insert(0, str(self.cost_cra))
        self.ent_cra.grid(row=1, column=1, padx=5, pady=5)
        
        tk.Label(cfg_frame, text="SIM (Mes/Ui):", bg="white").grid(row=1, column=2, sticky="w", pady=5)
        self.ent_sim = tk.Entry(cfg_frame, width=8)
        self.ent_sim.insert(0, str(self.cost_sim))
        self.ent_sim.grid(row=1, column=3, padx=5, pady=5)
        
        tk.Label(cfg_frame, text="Acuda (Mes):", bg="white").grid(row=1, column=4, sticky="w", pady=5)
        self.ent_acuda = tk.Entry(cfg_frame, width=8)
        self.ent_acuda.insert(0, str(self.cost_acuda))
        self.ent_acuda.grid(row=1, column=5, padx=5, pady=5)

        tk.Button(cfg_frame, text="Guardar Cambios", bg="#1976d2", fg="white", relief="flat",
                  command=self.aplicar_costes).grid(row=0, column=6, rowspan=2, padx=15, sticky="ns")
        
        tk.Button(cfg_frame, text="Nueva Licitación", bg="#388e3c", fg="white", relief="flat",
                  command=self.nueva_licitacion_dialog).grid(row=0, column=7, rowspan=2, padx=5, sticky="ns")
        
        tk.Button(cfg_frame, text="Cargar", bg="#f57c00", fg="white", relief="flat",
                  command=self.cargar_licitacion_dialog).grid(row=0, column=8, rowspan=2, padx=5, sticky="ns")

        # --- Formulario ---
        form_frame = tk.LabelFrame(self.parent, text="Añadir Centro", bg="white", padx=12, pady=10)
        form_frame.pack(fill="x", padx=20, pady=10)

        # Fila 0: Tipo de Mantenimiento
        tk.Label(form_frame, text="Tipo Mant.:", bg="white", font=("Segoe UI", 9, "bold")).grid(row=0, column=0, sticky="w")
        self.combo_tipo_mant = ttk.Combobox(form_frame, values=[
            "Personalizado", "CCTV (2 Presenciales)", "Intrusión (4 Presenciales)", "Intrusión Bidireccional (1 Pres. + 3 Rem.)"
        ], state="readonly", width=30)
        self.combo_tipo_mant.set("Personalizado")
        self.combo_tipo_mant.bind("<<ComboboxSelected>>", self._on_tipo_mant_change)
        self.combo_tipo_mant.grid(row=0, column=1, columnspan=3, sticky="w", padx=6, pady=4)

        tk.Label(form_frame, text="Visitas Presenciales:", bg="white").grid(row=0, column=4, sticky="e")
        self.ent_visitas = tk.Entry(form_frame, width=5)
        self.ent_visitas.insert(0, "1")
        self.ent_visitas.grid(row=0, column=5, sticky="w", padx=2)
        
        tk.Label(form_frame, text="Remotas:", bg="white").grid(row=0, column=6, sticky="e")
        self.ent_visitas_rem = tk.Entry(form_frame, width=5)
        self.ent_visitas_rem.insert(0, "0")
        self.ent_visitas_rem.grid(row=0, column=7, sticky="w", padx=2)

        # Fila 1: Nombre y técnicos
        self.ent_nombre = tk.Entry(form_frame, width=50)
        tk.Label(form_frame, text="Nombre / Dirección:", bg="white", font=("Segoe UI", 9, "bold")).grid(row=1, column=0, sticky="w", pady=8)
        self.ent_nombre.grid(row=1, column=1, columnspan=5, sticky="w", padx=6, pady=8)

        tk.Label(form_frame, text="Nº Técnicos:", bg="white", font=("Segoe UI", 9, "bold")).grid(row=1, column=6, sticky="w", padx=(20,0))
        self.ent_n_tecnicos = tk.Entry(form_frame, width=6)
        self.ent_n_tecnicos.insert(0, "1")
        self.ent_n_tecnicos.grid(row=1, column=7, sticky="w", padx=6)

        # Fila 2: Kilómetros y tiempos
        tk.Button(form_frame, text="📍 Ruta", command=self._abrir_selector_ruta, 
                  bg="#e0e0e0", relief="groove", font=("Segoe UI", 8)).grid(row=2, column=0, sticky="w", padx=2)
                  
        self.ent_km_ida = tk.Entry(form_frame, width=8)
        self.ent_km_ida.insert(0, "0")
        self.ent_km_ida.grid(row=2, column=1, sticky="w", padx=6)

        tk.Label(form_frame, text="Km vuelta:", bg="white").grid(row=2, column=2, sticky="w")
        self.ent_km_vuelta = tk.Entry(form_frame, width=8)
        self.ent_km_vuelta.insert(0, "0")
        self.ent_km_vuelta.grid(row=2, column=3, sticky="w", padx=6)

        tk.Label(form_frame, text="T. ida (min):", bg="white").grid(row=2, column=4, sticky="w", padx=(10,0))
        self.ent_t_ida = tk.Entry(form_frame, width=8)
        self.ent_t_ida.insert(0, "0")
        self.ent_t_ida.grid(row=2, column=5, sticky="w", padx=6)

        tk.Label(form_frame, text="T. mant (min):", bg="white").grid(row=2, column=6, sticky="w", padx=(10,0))
        self.ent_t_mant = tk.Entry(form_frame, width=8)
        self.ent_t_mant.insert(0, "0")
        self.ent_t_mant.grid(row=2, column=7, sticky="w", padx=6)

        tk.Label(form_frame, text="T. vuelta (min):", bg="white").grid(row=2, column=8, sticky="w", padx=(10,0))
        self.ent_t_vuelta = tk.Entry(form_frame, width=8)
        self.ent_t_vuelta.insert(0, "0")
        self.ent_t_vuelta.grid(row=2, column=9, sticky="w", padx=6)

        # Fila 3: Checkboxes y Add-ons
        tk.Label(form_frame, text="Servicios:", bg="white", font=("Segoe UI", 9, "bold")).grid(row=3, column=0, sticky="w", pady=(12,4))
        
        self.var_cra = tk.BooleanVar()
        tk.Checkbutton(form_frame, text="Conexión CRA", variable=self.var_cra, bg="white").grid(row=3, column=1, columnspan=2, sticky="w", padx=0)
        
        self.var_acuda = tk.BooleanVar()
        tk.Checkbutton(form_frame, text="Servicio Acuda", variable=self.var_acuda, bg="white").grid(row=3, column=3, columnspan=2, sticky="w", padx=0)

        # SIM Logic: Checkbox enables Entry
        self.var_sim_check = tk.BooleanVar()
        def _toggle_sim():
            if self.var_sim_check.get():
                self.ent_sim_qty.config(state="normal")
                if self.ent_sim_qty.get() == "0": self.ent_sim_qty.delete(0,"end"); self.ent_sim_qty.insert(0,"1")
            else:
                self.ent_sim_qty.delete(0,"end"); self.ent_sim_qty.insert(0,"0")
                self.ent_sim_qty.config(state="disabled")

        tk.Checkbutton(form_frame, text="Tiene SIM", variable=self.var_sim_check, bg="white", command=_toggle_sim).grid(row=3, column=5, sticky="e", padx=(10,0))
        
        self.ent_sim_qty = tk.Entry(form_frame, width=4, state="disabled")
        self.ent_sim_qty.insert(0, "0")
        self.ent_sim_qty.grid(row=3, column=6, sticky="w", padx=2)

        # Separador
        sep = ttk.Separator(form_frame, orient="horizontal")
        sep.grid(row=4, column=0, columnspan=10, sticky="ew", pady=10)

        # Fila 5: Botón para equipos
        tk.Label(form_frame, text="Equipos:", bg="white", font=("Segoe UI", 9, "bold")).grid(row=5, column=0, sticky="w")
        tk.Button(form_frame, text="📋 Gestionar Equipos", bg="#9c27b0", fg="white", 
                  command=self.abrir_gestion_equipos).grid(row=5, column=1, columnspan=2, sticky="w", padx=6)
        
        self.lbl_equipos_count = tk.Label(form_frame, text="0 equipos seleccionados", bg="white", fg="#666")
        self.lbl_equipos_count.grid(row=5, column=3, columnspan=3, sticky="w", padx=6)

        # Almacenar equipos temporales (para el formulario actual)
        self.equipos_temp = {}

        # Botones
        btn_frame = tk.Frame(form_frame, bg="white")
        btn_frame.grid(row=6, column=0, columnspan=10, pady=(12,0))

        tk.Button(btn_frame, text="➕ Añadir centro", bg="#1976d2", fg="white", width=16,
                  command=self.anadir_centro).pack(side="left", padx=8)
        tk.Button(btn_frame, text="🗑️ Eliminar", bg="#d32f2f", fg="white", width=14,
                  command=self.eliminar_seleccionado).pack(side="left", padx=8)
        tk.Button(btn_frame, text="📊 Calcular", bg="#388e3c", fg="white", width=14,
                  command=self.calcular_totales).pack(side="left", padx=8)
        tk.Button(btn_frame, text="📄 CSV", bg="#1976d2", fg="white", width=10,
                  command=self.exportar_csv).pack(side="left", padx=8)
        
        if EXCEL_AVAILABLE:
            tk.Button(btn_frame, text="📗 Excel", bg="#217346", fg="white", width=10,
                      command=self.exportar_excel).pack(side="left", padx=8)
        
        if PDF_AVAILABLE:
            tk.Button(btn_frame, text="📕 PDF", bg="#d32f2f", fg="white", width=10,
                      command=self.generar_pdf).pack(side="left", padx=8)
        
        tk.Button(btn_frame, text="📥 Importar CSV", bg="#f57c00", fg="white", width=14,
                  command=self.importar_csv).pack(side="left", padx=8)

        # --- Búsqueda ---
        search_frame = tk.Frame(self.parent, bg="white")
        search_frame.pack(fill="x", padx=20, pady=(5,0))
        
        tk.Label(search_frame, text="🔍 Buscar:", bg="white").pack(side="left", padx=(0,6))
        self.ent_buscar = tk.Entry(search_frame, width=40)
        self.ent_buscar.pack(side="left", padx=6)
        self.ent_buscar.bind("<KeyRelease>", self.filtrar_centros)
        
        tk.Button(search_frame, text="Limpiar", bg="#757575", fg="white", 
                  command=self.limpiar_busqueda).pack(side="left", padx=6)

        # --- Tabla ---
        tree_frame = tk.Frame(self.parent, bg="white")
        tree_frame.pack(fill="both", expand=True, padx=20, pady=6)

        cols = ("nombre", "equipos", "cra", "sim", "km_total",
                "n_tecnicos", "horas_tecnicas", "coste_base", "coste")
        self.tree = ttk.Treeview(tree_frame, columns=cols, show="headings", height=10)
        headings = {
            "nombre": "Centro / Dirección",
            "equipos": "N° Equipos",
            "cra": "CRA",
            "sim": "SIM",
            "km_total": "Km Total",
            "n_tecnicos": "N° Téc",
            "horas_tecnicas": "H. Técnicas",
            "coste_base": "Coste Base",
            "coste": f"Coste (+{int(float(self.margen_beneficio)*100)}%)"
        }
        for c in cols:
            self.tree.heading(c, text=headings[c])
            if c == "nombre":
                self.tree.column(c, width=300)
            elif c in ("coste", "coste_base", "horas_tecnicas"):
                self.tree.column(c, width=110, anchor="e")
            elif c in ("cra", "sim"):
                self.tree.column(c, width=50, anchor="center")
            else:
                self.tree.column(c, width=90, anchor="center")

        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        vsb.pack(side="right", fill="y")
        hsb.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)
        
        # Doble clic para ver detalles
        self.tree.bind("<Double-1>", self.ver_detalles_centro)

        # --- Resumen ---
        resumen_frame = tk.Frame(self.parent, bg="#e3f2fd", relief="raised", bd=2)
        resumen_frame.pack(fill="x", padx=20, pady=12)

        self.lbl_total_km = tk.Label(resumen_frame, text="Total Km: 0", bg="#e3f2fd", 
                                      font=("Segoe UI", 10))
        self.lbl_total_km.pack(side="left", padx=15, pady=8)

        self.lbl_total_horas = tk.Label(resumen_frame, text="Total H. Técnicas: 0.00", 
                                        bg="#e3f2fd", font=("Segoe UI", 10))
        self.lbl_total_horas.pack(side="left", padx=15)

        self.lbl_coste_base_total = tk.Label(resumen_frame, text="Coste Base: €0.00", 
                                             bg="#e3f2fd", font=("Segoe UI", 10))
        self.lbl_coste_base_total.pack(side="left", padx=15)

        self.lbl_coste_total = tk.Label(resumen_frame, text="Coste Total (+margen): €0.00", 
                                        bg="#e3f2fd", font=("Segoe UI", 11, "bold"))
        self.lbl_coste_total.pack(side="left", padx=15)

        if MATPLOTLIB_AVAILABLE:
            tk.Button(resumen_frame, text="📊 Ver Gráficos", bg="#9c27b0", fg="white",
                      command=self.mostrar_graficos).pack(side="right", padx=15)

        # --- Botón Volver ---
        tk.Button(self.parent, text="← Volver", bg="#d32f2f", fg="white", 
                  font=("Segoe UI", 12, "bold"),
                  command=self.parent.destroy).pack(pady=12)

    # ========== GESTIÓN DE EQUIPOS ==========
    def abrir_gestion_equipos(self):
        """Abre ventana para gestionar equipos del centro"""
        dialog = tk.Toplevel(self.parent)
        dialog.title("Gestión de Equipos")
        dialog.geometry("900x700")
        dialog.transient(self.parent)
        dialog.grab_set()
        
        # Frame principal con scroll
        main_frame = tk.Frame(dialog, bg="white")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Título
        tk.Label(main_frame, text="Selecciona los equipos del centro", 
                 font=("Segoe UI", 14, "bold"), bg="white").pack(pady=10)
        
        # Frame con canvas para scroll
        canvas_frame = tk.Frame(main_frame, bg="white")
        canvas_frame.pack(fill="both", expand=True)
        
        canvas = tk.Canvas(canvas_frame, bg="white")
        scrollbar = ttk.Scrollbar(canvas_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg="white")
        
        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Diccionario para almacenar los Entry widgets
        equipos_entries = {}
        
        # SECCIÓN CCTV
        cctv_frame = tk.LabelFrame(scrollable_frame, text="CCTV", bg="#e3f2fd", 
                                   font=("Segoe UI", 11, "bold"), padx=15, pady=10)
        cctv_frame.pack(fill="x", padx=10, pady=10)
        
        for idx, equipo in enumerate(self.EQUIPOS_CCTV):
            row = idx // 2
            col = (idx % 2) * 3
            
            tk.Label(cctv_frame, text=equipo + ":", bg="#e3f2fd", 
                    font=("Segoe UI", 9)).grid(row=row, column=col, sticky="w", pady=3, padx=5)
            
            entry = tk.Entry(cctv_frame, width=8)
            entry.insert(0, str(self.equipos_temp.get(equipo, 0)))
            entry.grid(row=row, column=col+1, padx=5)
            equipos_entries[equipo] = entry
        
        # SECCIÓN INTRUSIÓN
        intrusion_frame = tk.LabelFrame(scrollable_frame, text="INTRUSIÓN", bg="#fff3e0", 
                                        font=("Segoe UI", 11, "bold"), padx=15, pady=10)
        intrusion_frame.pack(fill="x", padx=10, pady=10)
        
        for idx, equipo in enumerate(self.EQUIPOS_INTRUSION):
            row = idx // 2
            col = (idx % 2) * 3
            
            tk.Label(intrusion_frame, text=equipo + ":", bg="#fff3e0", 
                    font=("Segoe UI", 9)).grid(row=row, column=col, sticky="w", pady=3, padx=5)
            
            entry = tk.Entry(intrusion_frame, width=8)
            entry.insert(0, str(self.equipos_temp.get(equipo, 0)))
            entry.grid(row=row, column=col+1, padx=5)
            equipos_entries[equipo] = entry
        
        # Botones de acción
        btn_frame = tk.Frame(main_frame, bg="white")
        btn_frame.pack(pady=15)
        
        def guardar_equipos():
            self.equipos_temp = {}
            total = 0
            for equipo, entry in equipos_entries.items():
                try:
                    valor = int(entry.get() or 0)
                    if valor > 0:
                        self.equipos_temp[equipo] = valor
                        total += valor
                except ValueError:
                    pass
            
            self.lbl_equipos_count.config(text=f"{total} equipos seleccionados")
            self._calcular_tiempo_auto()
            dialog.destroy()
        
        def limpiar_todos():
            for entry in equipos_entries.values():
                entry.delete(0, "end")
                entry.insert(0, "0")
        
        tk.Button(btn_frame, text="✓ Guardar", bg="#1976d2", fg="white", width=15,
                  font=("Segoe UI", 10, "bold"), command=guardar_equipos).pack(side="left", padx=10)
        tk.Button(btn_frame, text="🗑️ Limpiar Todos", bg="#f57c00", fg="white", width=15,
                  command=limpiar_todos).pack(side="left", padx=10)
        tk.Button(btn_frame, text="Cancelar", bg="#757575", fg="white", width=15,
                  command=dialog.destroy).pack(side="left", padx=10)

    def ver_detalles_centro(self, event=None):
        """Muestra detalles completos de un centro al hacer doble clic"""
        sel = self.tree.selection()
        if not sel:
            return
        
        centro_id = sel[0]
        centro = next((c for c in self.centers if c["id"] == centro_id), None)
        if not centro:
            return
        
        dialog = tk.Toplevel(self.parent)
        dialog.title(f"Detalles: {centro['nombre']}")
        dialog.geometry("800x600")
        dialog.transient(self.parent)
        
        # Frame principal con scroll
        main_frame = tk.Frame(dialog, bg="white")
        main_frame.pack(fill="both", expand=True, padx=15, pady=15)
        
        # Título
        tk.Label(main_frame, text=centro['nombre'], 
                 font=("Segoe UI", 14, "bold"), bg="white", fg="#1976d2").pack(pady=10)
        
        # Información general
        info_frame = tk.LabelFrame(main_frame, text="Información General", bg="white", 
                                   font=("Segoe UI", 10, "bold"), padx=10, pady=10)
        info_frame.pack(fill="x", pady=10)
        
        info_data = [
            ("Kilómetros (ida/vuelta/total):", f"{centro['km_ida']} / {centro['km_vuelta']} / {centro['km_total']} km"),
            ("Tiempos (ida/mant/vuelta):", f"{centro['t_ida']} / {centro['t_mant']} / {centro['t_vuelta']} min"),
            ("Número de técnicos:", str(centro['n_tecnicos'])),
            ("Horas técnicas totales:", f"{centro['horas_tecnicas']} horas"),

            ("Conectado a CRA:", "Sí" if centro.get('conectado_cra') else "No"),
            ("Servicio Acuda:", "Sí" if centro.get('servicio_acuda') else "No"),
            ("Tarjetas SIM:", f"{centro.get('num_sims', 0)} uds"),
        ]
        
        for idx, (label, value) in enumerate(info_data):
            tk.Label(info_frame, text=label, bg="white", font=("Segoe UI", 9, "bold")).grid(
                row=idx, column=0, sticky="w", pady=3)
            tk.Label(info_frame, text=value, bg="white", font=("Segoe UI", 9)).grid(
                row=idx, column=1, sticky="w", padx=20, pady=3)
        
        # Costes
        coste_frame = tk.LabelFrame(main_frame, text="Costes", bg="#e3f2fd", 
                                    font=("Segoe UI", 10, "bold"), padx=10, pady=10)
        coste_frame.pack(fill="x", pady=10)
        
        tk.Label(coste_frame, text="Coste Base:", bg="#e3f2fd", font=("Segoe UI", 10, "bold")).grid(
            row=0, column=0, sticky="w", pady=3)
        tk.Label(coste_frame, text=f"€{centro['coste_base']}", bg="#e3f2fd", 
                font=("Segoe UI", 10)).grid(row=0, column=1, sticky="w", padx=20, pady=3)
        
        tk.Label(coste_frame, text=f"Coste Total (+{int(float(self.margen_beneficio)*100)}%):", 
                bg="#e3f2fd", font=("Segoe UI", 10, "bold")).grid(
            row=1, column=0, sticky="w", pady=3)
        tk.Label(coste_frame, text=f"€{centro['coste']}", bg="#e3f2fd", 
                font=("Segoe UI", 11, "bold"), fg="#1976d2").grid(
            row=1, column=1, sticky="w", padx=20, pady=3)

        if "_breakdown" in centro:
            bd = centro["_breakdown"]
            tk.Label(coste_frame, text=f"Desglose Costes:", bg="#e3f2fd", font=("Segoe UI", 9, "bold")).grid(row=2, column=0, sticky="w", pady=(10,2))
            
            row_idx = 3
            details = [
                (f"  • Viaje:", f"€{bd['viaje']:.2f}"),
                (f"  • Mano Obra:", f"€{bd['horas']:.2f}"),
                (f"  • CRA:", f"€{bd['cra']:.2f}"),
                (f"  • SIMs:", f"€{bd['sim']:.2f}"),
                (f"  • Acuda:", f"€{bd['acuda']:.2f}")
            ]
            for label, val in details:
                tk.Label(coste_frame, text=label, bg="#e3f2fd", font=("Segoe UI", 9)).grid(row=row_idx, column=0, sticky="w")
                tk.Label(coste_frame, text=val, bg="#e3f2fd", font=("Segoe UI", 9)).grid(row=row_idx, column=1, sticky="e", padx=20)
                row_idx += 1
        
        # Equipos
        if centro.get("equipos"):
            equipos_frame = tk.LabelFrame(main_frame, text="Equipos Instalados", bg="white", 
                                         font=("Segoe UI", 10, "bold"), padx=10, pady=10)
            equipos_frame.pack(fill="both", expand=True, pady=10)
            
            # Canvas con scroll para equipos
            canvas = tk.Canvas(equipos_frame, bg="white", height=200)
            scrollbar = ttk.Scrollbar(equipos_frame, orient="vertical", command=canvas.yview)
            scroll_frame = tk.Frame(canvas, bg="white")
            
            scroll_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
            canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            
            # Separar por categorías
            equipos_cctv = {k: v for k, v in centro["equipos"].items() if k in self.EQUIPOS_CCTV}
            equipos_intrusion = {k: v for k, v in centro["equipos"].items() if k in self.EQUIPOS_INTRUSION}
            
            if equipos_cctv:
                tk.Label(scroll_frame, text="CCTV:", bg="#e3f2fd", 
                        font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x", pady=(5,2))
                for equipo, cantidad in sorted(equipos_cctv.items()):
                    tk.Label(scroll_frame, text=f"  • {equipo}: {cantidad}", 
                            bg="white", font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=10)
            
            if equipos_intrusion:
                tk.Label(scroll_frame, text="INTRUSIÓN:", bg="#fff3e0", 
                        font=("Segoe UI", 9, "bold"), anchor="w").pack(fill="x", pady=(10,2))
                for equipo, cantidad in sorted(equipos_intrusion.items()):
                    tk.Label(scroll_frame, text=f"  • {equipo}: {cantidad}", 
                            bg="white", font=("Segoe UI", 9), anchor="w").pack(fill="x", padx=10)
            
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
        
        # Botón cerrar
        tk.Button(main_frame, text="Cerrar", bg="#757575", fg="white", 
                 font=("Segoe UI", 10, "bold"), width=15,
                 command=dialog.destroy).pack(pady=15)

    # ========== VALIDACIÓN ==========
    def _validar_decimal_positivo(self, valor, campo):
        """Valida que el valor sea un Decimal >= 0"""
        try:
            num = Decimal(str(valor).strip())
            if num < 0:
                raise ValueError(f"{campo} no puede ser negativo")
            return num
        except (InvalidOperation, ValueError):
            raise ValueError(f"{campo} debe ser un número válido (≥0)")

    def _validar_entero_positivo(self, valor, campo):
        """Valida que el valor sea un entero >= 1"""
        try:
            num = int(valor)
            if num < 1:
                raise ValueError(f"{campo} debe ser al menos 1")
            return num
        except ValueError:
            raise ValueError(f"{campo} debe ser un número entero válido (≥1)")

    def _calcular_tiempo_auto(self):
        """Calcula t_mant basado en equipos seleccionados"""
        total_min = 0
        for equipo, cantidad in self.equipos_temp.items():
            t_unit = self.TIEMPOS_MANTENIMIENTO.get(equipo, 10)
            total_min += t_unit * cantidad
        
        self.ent_t_mant.delete(0, "end")
        self.ent_t_mant.insert(0, str(total_min))
    def aplicar_plantilla(self, event=None):
        """Aplica una plantilla predefinida"""
        seleccion = self.combo_plantilla.get()
        if seleccion == "Ninguna":
            return
        
        plantilla = self.PLANTILLAS[seleccion]
        self.ent_t_mant.delete(0, "end")
        self.ent_t_mant.insert(0, str(plantilla["t_mant"]))
        
        # Cargar equipos de la plantilla
        self.equipos_temp = plantilla["equipos"].copy()
        total = sum(self.equipos_temp.values())
        self.lbl_equipos_count.config(text=f"{total} equipos seleccionados")

    def aplicar_costes(self):
        try:
            self.cost_per_km = self._validar_decimal_positivo(self.ent_cost_km.get(), "Coste/km")
            self.cost_per_hour = self._validar_decimal_positivo(self.ent_cost_h.get(), "Coste/hora")
            margen_pct = self._validar_decimal_positivo(self.ent_margen.get(), "Margen")
            self.margen_beneficio = margen_pct / Decimal('100')
            
            # Nuevos costes
            self.cost_cra = self._validar_decimal_positivo(self.ent_cra.get(), "Coste CRA")
            self.cost_sim = self._validar_decimal_positivo(self.ent_sim.get(), "Coste SIM")
            self.cost_acuda = self._validar_decimal_positivo(self.ent_acuda.get(), "Coste Acuda")
            
            # Actualizar en BD
            cursor = self.conn.cursor()
            cursor.execute('''
                UPDATE licitaciones 
                SET cost_per_km=?, cost_per_hour=?, margen_beneficio=?,
                    cost_cra=?, cost_sim=?, cost_acuda=?
                WHERE id = ?
            ''', (float(self.cost_per_km), float(self.cost_per_hour), float(self.margen_beneficio),
                  float(self.cost_cra), float(self.cost_sim), float(self.cost_acuda),
                  self.licitacion_actual))
            self.conn.commit()
            
            self._refrescar_tabla()
            messagebox.showinfo("Aplicado", "Costes actualizados correctamente.")
        except ValueError as e:
            messagebox.showerror("Error de validación", str(e))

    def anadir_centro(self):
        nombre = self.ent_nombre.get().strip()
        if not nombre:
            messagebox.showwarning("Aviso", "Introduce un nombre para el centro.")
            return
        
        try:
            km_ida = self._validar_decimal_positivo(self.ent_km_ida.get(), "Km ida")
            km_vuelta = self._validar_decimal_positivo(self.ent_km_vuelta.get(), "Km vuelta")
            t_ida = self._validar_decimal_positivo(self.ent_t_ida.get(), "Tiempo ida")
            t_mant = self._validar_decimal_positivo(self.ent_t_mant.get(), "Tiempo mantenimiento")
            t_vuelta = self._validar_decimal_positivo(self.ent_t_vuelta.get(), "Tiempo vuelta")
            n_tecnicos = self._validar_entero_positivo(self.ent_n_tecnicos.get(), "Nº técnicos")
            
            n_visitas = self._validar_entero_positivo(self.ent_visitas.get(), "Visitas Presenc.")
            n_remotas = 0
            try: n_remotas = int(self.ent_visitas_rem.get())
            except: pass
            
            num_sims = 0
            try:
                if self.var_sim_check.get():
                    num_sims = int(self.ent_sim_qty.get())
            except: pass
            
        except ValueError as e:
            messagebox.showerror("Error de validación", str(e))
            return

        centro = {
            "id": str(uuid.uuid4()),
            "nombre": nombre,
            "km_ida": km_ida,
            "km_vuelta": km_vuelta,
            "t_ida": t_ida,
            "t_mant": t_mant,
            "t_vuelta": t_vuelta,
            "n_tecnicos": n_tecnicos,
            "conectado_cra": self.var_cra.get(),
            "num_sims": num_sims,
            "servicio_acuda": self.var_acuda.get(),
            "equipos": self.equipos_temp.copy(),
            "tipo_mantenimiento": self.combo_tipo_mant.get(),
            "visitas_presenciales": n_visitas,
            "visitas_remotas": n_remotas,
            "minutos_remoto": 15
        }

        self._calcular_valores_derivados(centro)
        self.centers.append(centro)
        self._guardar_centro_db(centro)
        self._insert_tree(centro)
        self._limpiar_formulario()
        self.calcular_totales()

    def _insert_tree(self, centro):
        cra_text = "✓" if centro.get("conectado_cra") else "✗"
        sim_text = "✓" if centro.get("tiene_tarjeta_sim") else "✗"
        
        self.tree.insert("", "end", iid=centro["id"], values=(
            centro["nombre"],
            str(centro.get("total_equipos", 0)),
            cra_text,
            sim_text,
            str(centro["km_total"]),
            str(centro["n_tecnicos"]),
            str(centro["horas_tecnicas"]),
            f"{centro['coste_base']}",
            f"{centro['coste']}"
        ))

    def _limpiar_formulario(self):
        self.ent_nombre.delete(0, "end")
        self.ent_km_ida.delete(0, "end"); self.ent_km_ida.insert(0, "0")
        self.ent_km_vuelta.delete(0, "end"); self.ent_km_vuelta.insert(0, "0")
        self.ent_t_ida.delete(0, "end"); self.ent_t_ida.insert(0, "0")
        self.ent_t_mant.delete(0, "end"); self.ent_t_mant.insert(0, "30")
        self.ent_t_vuelta.delete(0, "end"); self.ent_t_vuelta.insert(0, "0")
        self.ent_n_tecnicos.delete(0, "end"); self.ent_n_tecnicos.insert(0, "1")
        self.var_cra.set(False)
        self.var_sim_check.set(False)
        self.var_acuda.set(False)
        self.ent_sim_qty.config(state="disabled")
        self.ent_sim_qty.delete(0, "end"); self.ent_sim_qty.insert(0, "0")
        self.equipos_temp = {}
        self.lbl_equipos_count.config(text="0 equipos seleccionados")

    def eliminar_seleccionado(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Info", "Selecciona un centro para eliminar.")
            return
        
        num_items = len(sel)
        texto = f"¿Eliminar {num_items} centro(s) seleccionado(s)?"
        if not messagebox.askyesno("Confirmar eliminación", texto):
            return
        
        for item_id in sel:
            self.centers = [c for c in self.centers if c["id"] != item_id]
            self._eliminar_centro_db(item_id)
            self.tree.delete(item_id)
        
        self.calcular_totales()
        messagebox.showinfo("Eliminado", f"{num_items} centro(s) eliminado(s).")

    def calcular_totales(self):
        total_km = Decimal('0')
        total_horas = Decimal('0')
        total_coste_base = Decimal('0')
        total_coste = Decimal('0')

        for c in self.centers:
            total_km += Decimal(c["km_total"])
            total_horas += Decimal(c["horas_tecnicas"])
            total_coste_base += Decimal(c["coste_base"])
            total_coste += Decimal(c["coste"])

        total_km = total_km.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        total_horas = total_horas.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        total_coste_base = total_coste_base.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        total_coste = total_coste.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        self.lbl_total_km.config(text=f"Total Km: {total_km}")
        self.lbl_total_horas.config(text=f"Total H. Técnicas: {total_horas}")
        self.lbl_coste_base_total.config(text=f"Coste Base: €{total_coste_base}")
        self.lbl_coste_total.config(text=f"Coste Total (+margen): €{total_coste}")

    def _refrescar_tabla(self):
        """Recalcula todos los costes y refresca la tabla"""
        for centro in self.centers:
            self._calcular_valores_derivados(centro)
        
        for item_id in self.tree.get_children():
            self.tree.delete(item_id)
        
        for c in self.centers:
            self._insert_tree(c)
        
        self.tree.heading("coste", text=f"Coste (+{int(float(self.margen_beneficio)*100)}%)")
        self.calcular_totales()

    def _on_tipo_mant_change(self, event=None):
        tipo = self.combo_tipo_mant.get()
        v_pres = 1
        v_rem = 0
        
        if "CCTV" in tipo:
            v_pres = 2
            v_rem = 0
        elif "Intrusión (4" in tipo:
            v_pres = 4
            v_rem = 0
        elif "Bidireccional" in tipo:
            v_pres = 1
            v_rem = 3
        
        if tipo != "Personalizado":
            self.ent_visitas.delete(0, "end"); self.ent_visitas.insert(0, str(v_pres))
            self.ent_visitas_rem.delete(0, "end"); self.ent_visitas_rem.insert(0, str(v_rem))

    # ========== BÚSQUEDA Y FILTRADO ==========
    def _abrir_selector_ruta(self):
        """Abre el selector de rutas (KilometrajesApp)"""
        if KilometrajesApp is None:
            messagebox.showerror("Error", "Módulo de Kilometrajes no disponible.")
            return
            
        top = tk.Toplevel(self.parent)
        top.title("Seleccionar Ruta")
        top.geometry("1000x700")
        
        app = KilometrajesApp(top, current_user=self.current_user)
        
        def _usar_seleccion():
            sel = app.tree.selection()
            if not sel: return
            vals = app.tree.item(sel[0], "values")
            # Vals: (Busq, Dir, CP, Dist, Time, Lat, Lon)
            
            # Calcular si falta
            dist_str = str(vals[3])
            time_str = str(vals[4])
            
            # Intento calcular OSRM si está a 0
            if (dist_str == "---" or dist_str == "0.0") and app.mi_ubicacion and vals[5] and vals[6]:
                if requests:
                    try:
                        orig_lat = app.mi_ubicacion.get("lat")
                        orig_lon = app.mi_ubicacion.get("lon")
                        dest_lat = vals[5]
                        dest_lon = vals[6]
                        url = f"http://router.project-osrm.org/route/v1/driving/{orig_lon},{orig_lat};{dest_lon},{dest_lat}?overview=false"
                        r = requests.get(url, timeout=3)
                        data = r.json()
                        if data.get("code") == "Ok" and data.get("routes"):
                            route = data["routes"][0]
                            d_km = route["distance"] / 1000
                            dur_s = route["duration"]
                            
                            dist_str = f"{d_km:.2f}"
                            hours = int(dur_s // 3600)
                            mm = int((dur_s % 3600) // 60)
                            time_str = f"{hours}h {mm}m" if hours > 0 else f"{mm}m"
                    except Exception as e:
                        print(f"OSRM Error: {e}")

            # Parsear valores
            try:
                dist = float(dist_str) if dist_str != "---" else 0.0
                
                mins = 0
                t_str = time_str
                if "h" in t_str:
                    parts = t_str.split("h")
                    try: mins += int(parts[0]) * 60
                    except: pass
                    if len(parts) > 1 and "m" in parts[1]:
                        try: mins += int(parts[1].replace("m","").strip())
                        except: pass
                elif "m" in t_str:
                    try: mins += int(t_str.replace("m","").strip())
                    except: pass
                
                # Rellenar UI
                self.ent_nombre.delete(0, "end"); self.ent_nombre.insert(0, vals[1]) # Direccion
                self.ent_km_ida.delete(0, "end"); self.ent_km_ida.insert(0, f"{dist:.2f}")
                self.ent_km_vuelta.delete(0, "end"); self.ent_km_vuelta.insert(0, f"{dist:.2f}")
                self.ent_t_ida.delete(0, "end"); self.ent_t_ida.insert(0, str(mins))
                self.ent_t_vuelta.delete(0, "end"); self.ent_t_vuelta.insert(0, str(mins))
                
                top.destroy()
                
            except ValueError:
                messagebox.showerror("Error", "Datos no numéricos en la ruta seleccionada.")

        tk.Button(top, text="✅ USAR RUTA", bg="#4caf50", fg="white", font=("Segoe UI", 12, "bold"),
                  command=_usar_seleccion).pack(side="bottom", fill="x", pady=10)

    def filtrar_centros(self, event=None):
        """Filtra centros por texto de búsqueda"""
        texto = self.ent_buscar.get().strip().lower()
        
        for item_id in self.tree.get_children():
            self.tree.delete(item_id)
        
        for centro in self.centers:
            if not texto or texto in centro["nombre"].lower():
                self._insert_tree(centro)

    def limpiar_busqueda(self):
        """Limpia el campo de búsqueda y muestra todos los centros"""
        self.ent_buscar.delete(0, "end")
        self.filtrar_centros()

    # ========== GESTIÓN DE LICITACIONES ==========
    def nueva_licitacion_dialog(self):
        """Diálogo para crear nueva licitación"""
        dialog = tk.Toplevel(self.parent)
        dialog.title("Nueva Licitación")
        dialog.geometry("400x150")
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="Nombre de la licitación:", font=("Segoe UI", 10)).pack(pady=20)
        ent_nombre = tk.Entry(dialog, width=40)
        ent_nombre.insert(0, f"Licitación {datetime.now().strftime('%Y-%m-%d %H:%M')}")
        ent_nombre.pack(pady=10)
        ent_nombre.focus()
        
        def crear():
            nombre = ent_nombre.get().strip()
            if not nombre:
                messagebox.showwarning("Aviso", "Introduce un nombre.")
                return
            
            self.centers = []
            for item_id in self.tree.get_children():
                self.tree.delete(item_id)
            
            self._crear_nueva_licitacion(nombre)
            self.calcular_totales()
            dialog.destroy()
        
        tk.Button(dialog, text="Crear", bg="#1976d2", fg="white", command=crear).pack(pady=10)

    def cargar_licitacion_dialog(self):
        """Diálogo para cargar una licitación existente"""
        cursor = self.conn.cursor()
        cursor.execute('''
            SELECT id, nombre, fecha_creacion 
            FROM licitaciones 
            WHERE usuario = ?
            ORDER BY fecha_creacion DESC
        ''', (self.current_user,))
        
        licitaciones = cursor.fetchall()
        if not licitaciones:
            messagebox.showinfo("Info", "No hay licitaciones guardadas.")
            return
        
        dialog = tk.Toplevel(self.parent)
        dialog.title("Cargar Licitación")
        dialog.geometry("600x400")
        dialog.transient(self.parent)
        dialog.grab_set()
        
        tk.Label(dialog, text="Selecciona una licitación:", font=("Segoe UI", 12, "bold")).pack(pady=10)
        
        frame = tk.Frame(dialog)
        frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        cols = ("nombre", "fecha")
        tree = ttk.Treeview(frame, columns=cols, show="headings", height=12)
        tree.heading("nombre", text="Nombre")
        tree.heading("fecha", text="Fecha Creación")
        tree.column("nombre", width=400)
        tree.column("fecha", width=150)
        
        for lic in licitaciones:
            tree.insert("", "end", iid=lic[0], values=(lic[1], lic[2][:19]))
        
        vsb = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        tree.pack(fill="both", expand=True)
        
        def cargar():
            sel = tree.selection()
            if not sel:
                messagebox.showinfo("Info", "Selecciona una licitación.")
                return
            
            lic_id = sel[0]
            self.licitacion_actual = lic_id
            
            cursor.execute('''
                SELECT nombre, cost_per_km, cost_per_hour, margen_beneficio
                FROM licitaciones WHERE id = ?
            ''', (lic_id,))
            row = cursor.fetchone()
            
            self.cost_per_km = Decimal(str(row[1]))
            self.cost_per_hour = Decimal(str(row[2]))
            self.margen_beneficio = Decimal(str(row[3]))
            
            self.ent_cost_km.delete(0, "end")
            self.ent_cost_km.insert(0, str(self.cost_per_km))
            self.ent_cost_h.delete(0, "end")
            self.ent_cost_h.insert(0, str(self.cost_per_hour))
            self.ent_margen.delete(0, "end")
            self.ent_margen.insert(0, str(float(self.margen_beneficio * 100)))
            
            self.parent.title(f"Mantenimiento - {row[0]}")
            
            self.centers = []
            for item_id in self.tree.get_children():
                self.tree.delete(item_id)
            
            self._cargar_centros_db()
            dialog.destroy()
            messagebox.showinfo("Cargado", f"Licitación cargada: {row[0]}")
        
        btn_frame = tk.Frame(dialog)
        btn_frame.pack(pady=10)
        tk.Button(btn_frame, text="Cargar", bg="#1976d2", fg="white", width=12, command=cargar).pack(side="left", padx=10)
        tk.Button(btn_frame, text="Cancelar", bg="#757575", fg="white", width=12, command=dialog.destroy).pack(side="left", padx=10)

    # ========== IMPORTAR/EXPORTAR ==========
    def importar_csv(self):
        """Importa centros desde un archivo CSV"""
        path = filedialog.askopenfilename(
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
            title="Seleccionar archivo CSV"
        )
        if not path:
            return
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                centros_importados = 0
                
                for row in reader:
                    try:
                        # Parsear equipos JSON si existe
                        equipos = {}
                        if "Equipos" in row and row["Equipos"]:
                            try:
                                equipos = json.loads(row["Equipos"])
                            except:
                                pass
                        
                        centro = {
                            "id": str(uuid.uuid4()),
                            "nombre": row.get("Centro", row.get("nombre", "Centro sin nombre")),
                            "km_ida": Decimal(row.get("Km Ida", row.get("km_ida", 0))),
                            "km_vuelta": Decimal(row.get("Km Vta", row.get("km_vuelta", 0))),
                            "t_ida": Decimal(row.get("T Ida (min)", row.get("t_ida", 0))),
                            "t_mant": Decimal(row.get("T Mant (min)", row.get("t_mant", 30))),
                            "t_vuelta": Decimal(row.get("T Vta (min)", row.get("t_vuelta", 0))),
                            "n_tecnicos": int(row.get("N Técnicos", row.get("n_tecnicos", 1))),
                            "conectado_cra": row.get("CRA", "No").lower() in ("sí", "si", "yes", "1", "true"),
                            "tiene_tarjeta_sim": row.get("SIM", "No").lower() in ("sí", "si", "yes", "1", "true"),
                            "equipos": equipos
                        }
                        
                        self._calcular_valores_derivados(centro)
                        self.centers.append(centro)
                        self._guardar_centro_db(centro)
                        self._insert_tree(centro)
                        centros_importados += 1
                        
                    except Exception as e:
                        print(f"Error importando fila: {row}. Error: {e}")
                        continue
            
            self.calcular_totales()
            messagebox.showinfo("Importado", f"{centros_importados} centros importados correctamente.")
            
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo importar el archivo:\n{e}")

    def exportar_csv(self):
        if not self.centers:
            messagebox.showinfo("Info", "No hay datos para exportar.")
            return
        
        path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV files", "*.csv")],
            title="Guardar resumen como"
        )
        if not path:
            return
        
        try:
            with open(path, "w", newline='', encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([
                    "Centro", "N° Equipos", "CRA", "SIM",
                    "Km Ida", "Km Vta", "Km Total", 
                    "T Ida (min)", "T Mant (min)", "T Vta (min)", 
                    "N Técnicos", "Horas Técnicas", "Coste Base (€)", 
                    f"Coste Total (+{int(float(self.margen_beneficio)*100)}%) (€)", "Equipos"
                ])
                
                for c in self.centers:
                    writer.writerow([
                        c["nombre"], 
                        c.get("total_equipos", 0),
                        "Sí" if c.get("conectado_cra") else "No",
                        "Sí" if c.get("tiene_tarjeta_sim") else "No",
                        str(c["km_ida"]), str(c["km_vuelta"]), str(c["km_total"]),
                        str(c["t_ida"]), str(c["t_mant"]), str(c["t_vuelta"]),
                        str(c["n_tecnicos"]), str(c["horas_tecnicas"]), 
                        str(c["coste_base"]), str(c["coste"]),
                        json.dumps(c.get("equipos", {}))
                    ])
            
            messagebox.showinfo("Exportado", f"Resumen exportado a:\n{path}")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo exportar:\n{e}")

    def exportar_excel(self):
        """Exporta a formato Excel con formato profesional"""
        if not EXCEL_AVAILABLE:
            messagebox.showerror("Error", "La librería openpyxl no está instalada.\nInstálala con: pip install openpyxl")
            return
        
        if not self.centers:
            messagebox.showinfo("Info", "No hay datos para exportar.")
            return
        
        path = filedialog.asksaveasfilename(
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx")],
            title="Guardar como Excel"
        )
        if not path:
            return
        
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            
            wb = Workbook()
            ws = wb.active
            ws.title = "Resumen Mantenimiento"
            
            # Estilos
            header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
            header_font = Font(color="FFFFFF", bold=True, size=11)
            total_fill = PatternFill(start_color="E7E6E6", end_color="E7E6E6", fill_type="solid")
            total_font = Font(bold=True, size=11)
            border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            # Título
            ws.merge_cells('A1:M1')
            title_cell = ws['A1']
            title_cell.value = "RESUMEN DE MANTENIMIENTO - LICITACIÓN"
            title_cell.font = Font(size=16, bold=True, color="1F4E78")
            title_cell.alignment = Alignment(horizontal='center', vertical='center')
            
            # Información de configuración
            ws['A3'] = "Configuración:"
            ws['A3'].font = Font(bold=True)
            ws['A4'] = f"Coste/km: €{self.cost_per_km}"
            ws['C4'] = f"Coste/hora: €{self.cost_per_hour}"
            ws['E4'] = f"Margen: {int(float(self.margen_beneficio)*100)}%"
            ws['A5'] = f"Fecha: {datetime.now().strftime('%d/%m/%Y %H:%M')}"
            
            # Encabezados
            headers = [
                "Centro / Dirección", "N° Equipos", "CRA", "SIM", "Km Total",
                "T. Mant (min)", "N° Técnicos", "Horas Técnicas", 
                "Coste Base (€)", f"Coste Total (+{int(float(self.margen_beneficio)*100)}%) (€)"
            ]
            
            for col, header in enumerate(headers, start=1):
                cell = ws.cell(row=7, column=col, value=header)
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
                cell.border = border
            
            # Datos
            for row_idx, centro in enumerate(self.centers, start=8):
                data = [
                    centro["nombre"],
                    centro.get("total_equipos", 0),
                    "Sí" if centro.get("conectado_cra") else "No",
                    "Sí" if centro.get("tiene_tarjeta_sim") else "No",
                    float(centro["km_total"]),
                    float(centro["t_mant"]),
                    centro["n_tecnicos"],
                    float(centro["horas_tecnicas"]),
                    float(centro["coste_base"]),
                    float(centro["coste"])
                ]
                
                for col_idx, value in enumerate(data, start=1):
                    cell = ws.cell(row=row_idx, column=col_idx, value=value)
                    cell.border = border
                    if col_idx > 1:
                        cell.alignment = Alignment(horizontal='right' if col_idx > 4 else 'center')
                    if col_idx in [9, 10]:  # Columnas de coste
                        cell.number_format = '€#,##0.00'
            
            # Totales
            total_row = len(self.centers) + 8
            ws.cell(row=total_row, column=1, value="TOTALES").font = total_font
            ws.cell(row=total_row, column=1).fill = total_fill
            
            total_km = sum(Decimal(c["km_total"]) for c in self.centers)
            total_horas = sum(Decimal(c["horas_tecnicas"]) for c in self.centers)
            total_coste_base = sum(Decimal(c["coste_base"]) for c in self.centers)
            total_coste = sum(Decimal(c["coste"]) for c in self.centers)
            
            ws.cell(row=total_row, column=5, value=float(total_km)).font = total_font
            ws.cell(row=total_row, column=8, value=float(total_horas)).font = total_font
            ws.cell(row=total_row, column=9, value=float(total_coste_base)).font = total_font
            ws.cell(row=total_row, column=9).number_format = '€#,##0.00'
            ws.cell(row=total_row, column=10, value=float(total_coste)).font = total_font
            ws.cell(row=total_row, column=10).number_format = '€#,##0.00'
            
            for col in range(1, 11):
                ws.cell(row=total_row, column=col).fill = total_fill
                ws.cell(row=total_row, column=col).border = border
            
            # Ajustar anchos
            ws.column_dimensions['A'].width = 40
            ws.column_dimensions['B'].width = 12
            ws.column_dimensions['C'].width = 8
            ws.column_dimensions['D'].width = 8
            for col in ['E', 'F', 'G', 'H', 'I', 'J']:
                ws.column_dimensions[col].width = 14
            
            # Hoja adicional con detalle de equipos
            ws_equipos = wb.create_sheet("Detalle Equipos")
            ws_equipos['A1'] = "DETALLE DE EQUIPOS POR CENTRO"
            ws_equipos['A1'].font = Font(size=14, bold=True, color="1F4E78")
            
            row = 3
            for centro in self.centers:
                if centro.get("equipos"):
                    ws_equipos.cell(row=row, column=1, value=centro["nombre"]).font = Font(bold=True, size=11)
                    row += 1
                    
                    for equipo, cantidad in sorted(centro["equipos"].items()):
                        ws_equipos.cell(row=row, column=2, value=equipo)
                        ws_equipos.cell(row=row, column=3, value=cantidad)
                        row += 1
                    row += 1
            
            ws_equipos.column_dimensions['A'].width = 5
            ws_equipos.column_dimensions['B'].width = 40
            ws_equipos.column_dimensions['C'].width = 10
            
            wb.save(path)
            messagebox.showinfo("Exportado", f"Excel generado correctamente:\n{path}")
            
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo exportar a Excel:\n{e}")

    def generar_pdf(self):
        """Genera un PDF profesional con el resumen"""
        if not PDF_AVAILABLE:
            messagebox.showerror("Error", "La librería reportlab no está instalada.\nInstálala con: pip install reportlab")
            return
        
        if not self.centers:
            messagebox.showinfo("Info", "No hay datos para exportar.")
            return
        
        path = filedialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            title="Guardar como PDF"
        )
        if not path:
            return
        
        try:
            from reportlab.lib.pagesizes import A4
            from reportlab.lib import colors
            from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.units import cm
            
            doc = SimpleDocTemplate(path, pagesize=A4, topMargin=2*cm, bottomMargin=2*cm)
            story = []
            styles = getSampleStyleSheet()
            
            # Título
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=18,
                textColor=colors.HexColor('#1F4E78'),
                spaceAfter=30,
                alignment=1
            )
            story.append(Paragraph("RESUMEN DE MANTENIMIENTO - LICITACIÓN", title_style))
            story.append(Spacer(1, 0.5*cm))
            
            # Información de configuración
            info_style = styles["Normal"]
            story.append(Paragraph(f"<b>Fecha:</b> {datetime.now().strftime('%d/%m/%Y %H:%M')}", info_style))
            story.append(Paragraph(f"<b>Configuración:</b> €{self.cost_per_km}/km | €{self.cost_per_hour}/hora | Margen: {int(float(self.margen_beneficio)*100)}%", info_style))
            story.append(Spacer(1, 0.8*cm))
            
            # Tabla resumen de centros
            data = [[
                "Centro", "Equipos", "CRA", "SIM", "Km", 
                "H. Téc", f"Coste Base\n(€)", f"Coste Total\n(+{int(float(self.margen_beneficio)*100)}%)\n(€)"
            ]]
            
            for c in self.centers:
                data.append([
                    Paragraph(c["nombre"][:40], info_style),
                    str(c.get("total_equipos", 0)),
                    "Sí" if c.get("conectado_cra") else "No",
                    "Sí" if c.get("tiene_tarjeta_sim") else "No",
                    f"{c['km_total']}",
                    f"{c['horas_tecnicas']}",
                    f"{c['coste_base']}",
                    f"{c['coste']}"
                ])
            
            # Totales
            total_km = sum(Decimal(c["km_total"]) for c in self.centers)
            total_horas = sum(Decimal(c["horas_tecnicas"]) for c in self.centers)
            total_coste_base = sum(Decimal(c["coste_base"]) for c in self.centers)
            total_coste = sum(Decimal(c["coste"]) for c in self.centers)
            
            data.append([
                Paragraph("<b>TOTALES</b>", info_style),
                "",
                "",
                "",
                f"<b>{total_km}</b>",
                f"<b>{total_horas}</b>",
                f"<b>{total_coste_base}</b>",
                f"<b>{total_coste}</b>"
            ])
            
            table = Table(data, colWidths=[6*cm, 1.5*cm, 1*cm, 1*cm, 1.5*cm, 1.5*cm, 2.5*cm, 2.5*cm])
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1F4E78')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('ALIGN', (0, 1), (0, -1), 'LEFT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 9),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, -1), (-1, -1), colors.lightgrey),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                ('FONTSIZE', (0, 1), (-1, -1), 8),
            ]))
            
            story.append(table)
            
            # Si hay equipos, añadir detalle
            tiene_equipos = any(c.get("equipos") for c in self.centers)
            if tiene_equipos:
                story.append(PageBreak())
                story.append(Paragraph("DETALLE DE EQUIPOS POR CENTRO", title_style))
                story.append(Spacer(1, 0.5*cm))
                
                for centro in self.centers:
                    if centro.get("equipos"):
                        story.append(Paragraph(f"<b>{centro['nombre']}</b>", styles['Heading3']))
                        
                        # Separar por categorías
                        equipos_cctv = {k: v for k, v in centro["equipos"].items() if k in self.EQUIPOS_CCTV}
                        equipos_intrusion = {k: v for k, v in centro["equipos"].items() if k in self.EQUIPOS_INTRUSION}
                        
                        if equipos_cctv:
                            story.append(Paragraph("<b>CCTV:</b>", info_style))
                            for equipo, cant in sorted(equipos_cctv.items()):
                                story.append(Paragraph(f"&nbsp;&nbsp;&nbsp;• {equipo}: {cant}", info_style))
                        
                        if equipos_intrusion:
                            story.append(Paragraph("<b>INTRUSIÓN:</b>", info_style))
                            for equipo, cant in sorted(equipos_intrusion.items()):
                                story.append(Paragraph(f"&nbsp;&nbsp;&nbsp;• {equipo}: {cant}", info_style))
                        
                        story.append(Spacer(1, 0.5*cm))
            
            doc.build(story)
            messagebox.showinfo("PDF Generado", f"PDF creado correctamente:\n{path}")
            
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo generar el PDF:\n{e}")

    # ========== GRÁFICOS ==========
    def mostrar_graficos(self):
        """Muestra gráficos de análisis"""
        if not MATPLOTLIB_AVAILABLE:
            messagebox.showerror("Error", "La librería matplotlib no está instalada.\nInstálala con: pip install matplotlib")
            return
        
        if not self.centers:
            messagebox.showinfo("Info", "No hay datos para graficar.")
            return
        
        graph_window = tk.Toplevel(self.parent)
        graph_window.title("Análisis Gráfico")
        graph_window.geometry("1200x700")
        graph_window.state("zoomed")
        
        fig = plt.Figure(figsize=(14, 8), dpi=100)
        
        # Gráfico 1: Coste por centro
        ax1 = fig.add_subplot(2, 2, 1)
        nombres = [c["nombre"][:25] + "..." if len(c["nombre"]) > 25 else c["nombre"] for c in self.centers[:10]]
        costes = [float(c["coste"]) for c in self.centers[:10]]
        ax1.barh(nombres, costes, color='#1976d2')
        ax1.set_xlabel('Coste (€)', fontsize=10)
        ax1.set_title('Top 10 Centros por Coste', fontsize=12, fontweight='bold')
        ax1.grid(axis='x', alpha=0.3)
        
        # Gráfico 2: Distribución de costes
        ax2 = fig.add_subplot(2, 2, 2)
        total_km = sum(Decimal(c["km_total"]) for c in self.centers)
        total_horas = sum(Decimal(c["horas_tecnicas"]) for c in self.centers)
        coste_km_total = (total_km * self.cost_per_km).quantize(Decimal("0.01"))
        coste_horas_total = (total_horas * self.cost_per_hour).quantize(Decimal("0.01"))
        
        labels = ['Desplazamiento', 'Mano de Obra']
        sizes = [float(coste_km_total), float(coste_horas_total)]
        colors_pie = ['#ff9800', '#2196f3']
        explode = (0.05, 0)
        
        ax2.pie(sizes, explode=explode, labels=labels, colors=colors_pie, autopct='%1.1f%%',
                shadow=True, startangle=90)
        ax2.set_title('Distribución de Costes Totales', fontsize=12, fontweight='bold')
        
        # Gráfico 3: Equipos por centro
        ax3 = fig.add_subplot(2, 2, 3)
        centros_con_equipos = [c for c in self.centers if c.get("total_equipos", 0) > 0][:10]
        if centros_con_equipos:
            nombres_eq = [c["nombre"][:20] for c in centros_con_equipos]
            equipos = [c.get("total_equipos", 0) for c in centros_con_equipos]
            ax3.bar(range(len(nombres_eq)), equipos, color='#4caf50')
            ax3.set_xticks(range(len(nombres_eq)))
            ax3.set_xticklabels(nombres_eq, rotation=45, ha='right', fontsize=8)
            ax3.set_ylabel('Número de Equipos', fontsize=10)
            ax3.set_title('Equipos por Centro', fontsize=12, fontweight='bold')
            ax3.grid(axis='y', alpha=0.3)
        
        # Gráfico 4: Comparativa costes
        ax4 = fig.add_subplot(2, 2, 4)
        n_centros = min(8, len(self.centers))
        nombres_cortos = [c["nombre"][:15] for c in self.centers[:n_centros]]
        coste_base = [float(c["coste_base"]) for c in self.centers[:n_centros]]
        coste_total = [float(c["coste"]) for c in self.centers[:n_centros]]
        
        x = range(n_centros)
        width = 0.35
        ax4.bar([i - width/2 for i in x], coste_base, width, label='Base', color='#2196f3')
        ax4.bar([i + width/2 for i in x], coste_total, width, label=f'+Margen ({int(float(self.margen_beneficio)*100)}%)', color='#f44336')
        ax4.set_ylabel('Coste (€)', fontsize=10)
        ax4.set_title('Comparativa: Base vs Total', fontsize=12, fontweight='bold')
        ax4.set_xticks(x)
        ax4.set_xticklabels(nombres_cortos, rotation=45, ha='right', fontsize=8)
        ax4.legend()
        ax4.grid(axis='y', alpha=0.3)
        
        fig.tight_layout(pad=3.0)
        
        canvas = FigureCanvasTkAgg(fig, graph_window)
        canvas.draw()
        canvas.get_tk_widget().pack(fill="both", expand=True, padx=10, pady=10)
        
        btn_frame = tk.Frame(graph_window)
        btn_frame.pack(pady=10)
        
        def guardar_grafico():
            path = filedialog.asksaveasfilename(
                defaultextension=".png",
                filetypes=[("PNG", "*.png"), ("PDF", "*.pdf"), ("SVG", "*.svg")],
                title="Guardar gráfico"
            )
            if path:
                fig.savefig(path, dpi=300, bbox_inches='tight')
                messagebox.showinfo("Guardado", f"Gráfico guardado en:\n{path}")
        
        tk.Button(btn_frame, text="💾 Guardar Gráfico", bg="#1976d2", fg="white",
                  command=guardar_grafico).pack(side="left", padx=10)
        tk.Button(btn_frame, text="Cerrar", bg="#757575", fg="white",
                  command=graph_window.destroy).pack(side="left", padx=10)
        
        def _cargar_precios(self):
            """Carga precios desde productos.db"""
            import sqlite3
            from decimal import Decimal
            from tkinter import messagebox
            try:
                conn_elem = sqlite3.connect("proyectos/licitaciones/productos.db")
                cur = conn_elem.cursor()
                cur.execute("SELECT nombre, precio_unitario FROM elementos ORDER BY nombre")
                rows = cur.fetchall()
                conn_elem.close()
                self.precios_map = {r[0]: Decimal(str(r[1])) for r in rows}
                self.combo_elementos['values'] = list(self.precios_map.keys())
            except Exception as e:
                messagebox.showerror("Error", f"No se pudieron cargar los precios:\n{e}")
                self.precios_map = {}
                
    def _cargar_productos(self):
        """Carga los productos y precios desde productos.db"""
        try:
            conn = sqlite3.connect("proyectos/licitaciones/productos.db")
            cur = conn.cursor()
            cur.execute("SELECT modelo, precio FROM productos ORDER BY proveedor, marca, modelo")
            rows = cur.fetchall()
            conn.close()
            self.productos_map = {r[0]: Decimal(str(r[1])) for r in rows if r[0]}
            modelos = list(self.productos_map.keys())
            if hasattr(self, "combo_elementos"):
                self.combo_elementos['values'] = modelos
        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los productos:\n{e}")
            self.productos_map = {}


# ========== FUNCIÓN DE PRUEBA/LANZAMIENTO ==========
def main():
    """Función de prueba para lanzar la aplicación de forma independiente"""
    root = tk.Tk()
    root.withdraw()
    
    conn = sqlite3.connect(':memory:')
    
    window = tk.Toplevel(root)
    app = MantenimientoLicitacionesApp(window, conn, "usuario_test")
    
    root.mainloop()


if __name__ == "__main__":
    main()