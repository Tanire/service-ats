import tkinter as tk
from tkinter import messagebox
from proyectos.licitaciones.mantenimiento import MantenimientoLicitacionesApp
from proyectos.licitaciones.configuracion import ConfiguracionLicitacionesApp
from proyectos.licitaciones.instalacion_mantenimiento import InstalacionMantenimientoApp


class LicitacionesApp:
    def __init__(self, parent, conn, current_user):
        self.parent = parent
        self.conn = conn
        self.current_user = current_user
        self.build_ui()

    def build_ui(self):
        frame = tk.Frame(self.parent, bg="white")
        frame.pack(expand=True, fill="both")

        # Título principal
        tk.Label(frame, text="Gestor de Licitaciones", font=("Segoe UI", 28, "bold"),
                 fg="#004080", bg="white").pack(pady=40)

        # Contenedor de botones
        btns = tk.Frame(frame, bg="white")
        btns.pack(pady=60)

        opciones = [
            ("Mantenimiento", "#1976d2", self.abrir_mantenimiento),
            ("Instalación y Mantenimiento", "#1976d2", self.abrir_instalacion_mantenimiento),
            ("Suministro", "#1976d2", self.abrir_suministro),
            ("Configuración", "#1976d2", self.abrir_configuracion),
        ]

        for texto, color, cmd in opciones:
            tk.Button(btns, text=texto, bg=color, fg="white", relief="flat",
                      font=("Segoe UI", 16, "bold"), width=30, height=2,
                      command=cmd).pack(pady=15)

        # Botón para volver
        tk.Button(frame, text="Volver", bg="#d32f2f", fg="white", font=("Segoe UI", 12, "bold"),
                  command=self.parent.destroy).pack(pady=30)

    # Funciones de cada botón (por ahora solo muestran mensajes)
    def abrir_mantenimiento(self):
        mant_win = tk.Toplevel(self.parent)
        mant_win.title("Mantenimiento")
        mant_win.state("zoomed")
        mant_win.grab_set()
        MantenimientoLicitacionesApp(mant_win, self.conn, self.current_user)

    def abrir_instalacion_mantenimiento(self):
        win = tk.Toplevel(self.parent)
        win.title("Instalación y Mantenimiento")
        win.state("zoomed")
        win.grab_set()
        InstalacionMantenimientoApp(win, self.conn, self.current_user)

    def abrir_suministro(self):
        messagebox.showinfo("Suministro", "Sección en desarrollo.")

    def abrir_configuracion(self):
        cfg_win = tk.Toplevel(self.parent)
        cfg_win.title("Configuración - Licitaciones")
        cfg_win.state("zoomed")
        cfg_win.grab_set()
        from proyectos.licitaciones.configuracion import ConfiguracionLicitacionesApp
        ConfiguracionLicitacionesApp(cfg_win, self.conn, self.current_user)


