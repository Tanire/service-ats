# proyectos/licitaciones/productos.py
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import sqlite3
import openpyxl
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from utils_paths import get_resource_path

class ProductosApp:
    """
    Gestor de productos y precios unitarios.
    Base: proyectos/licitaciones/productos.db
    """
    def __init__(self, parent):
        self.parent = parent
        self.db_path = get_resource_path("proyectos/licitaciones/productos.db")
        self.conn = sqlite3.connect(self.db_path)
        self._crear_tabla()
        self._build_ui()
        self._cargar_datos()

    def _crear_tabla(self):
        cur = self.conn.cursor()
        cur.execute('''
            CREATE TABLE IF NOT EXISTS productos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ref_proveedor TEXT,
                proveedor TEXT,
                tipo TEXT,
                marca TEXT,
                modelo TEXT UNIQUE,
                descripcion TEXT,
                precio REAL,
                fecha_mod TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        self.conn.commit()

    def _build_ui(self):
        self.parent.title("Gestor de Productos y Precios")
        self.parent.geometry("1000x560")
        self.parent.configure(bg="white")

        tk.Label(self.parent, text="Gestión de Productos y Materiales", font=("Segoe UI", 16, "bold"),
                 fg="#004080", bg="white").pack(pady=10)

        # 🔍 Búsqueda
        top = tk.Frame(self.parent, bg="white")
        top.pack(fill="x", padx=10)

        tk.Label(top, text="Buscar:", bg="white").pack(side="left")
        self.ent_buscar = tk.Entry(top, width=40)
        self.ent_buscar.pack(side="left", padx=6)
        self.ent_buscar.bind("<KeyRelease>", lambda e: self._cargar_datos(self.ent_buscar.get().strip()))

        tk.Button(top, text="➕ Nuevo", bg="#1976d2", fg="white", command=self._nuevo).pack(side="right", padx=4)
        tk.Button(top, text="✏️ Editar", bg="#388e3c", fg="white", command=self._editar).pack(side="right", padx=4)
        tk.Button(top, text="🗑️ Eliminar", bg="#d32f2f", fg="white", command=self._eliminar).pack(side="right", padx=4)

        # --- Botones de importación/exportación ---
        btns = tk.Frame(self.parent, bg="white")
        btns.pack(fill="x", padx=10, pady=5)

        tk.Button(btns, text="📤 Exportar Excel", bg="#0288d1", fg="white", width=15,
                  command=self._exportar_excel).pack(side="left", padx=4)

        tk.Button(btns, text="📥 Importar Excel", bg="#00796b", fg="white", width=15,
                  command=self._importar_excel).pack(side="left", padx=4)

        # 🧾 Tabla
        cols = ("id", "ref_proveedor", "proveedor", "tipo", "marca", "modelo", "descripcion", "precio")
        self.tree = ttk.Treeview(self.parent, columns=cols, show="headings", height=18)
        self.tree.pack(fill="both", expand=True, padx=10, pady=8)

        headers = {
            "id": "ID", "ref_proveedor": "Ref. Prov.", "proveedor": "Proveedor",
            "tipo": "Tipo", "marca": "Marca", "modelo": "Modelo",
            "descripcion": "Descripción", "precio": "Precio (€)"
        }

        widths = {
            "id": 40, "ref_proveedor": 100, "proveedor": 120, "tipo": 120,
            "marca": 100, "modelo": 120, "descripcion": 260, "precio": 100
        }

        for c in cols:
            self.tree.heading(c, text=headers[c])
            self.tree.column(c, width=widths[c], anchor="center" if c in ["id", "precio"] else "w")

        self.tree.bind("<Double-1>", lambda e: self._editar())

        # 🔚 Pie
        tk.Button(self.parent, text="Cerrar", bg="#757575", fg="white",
                  command=self.parent.destroy).pack(pady=6)

    # -----------------------------------------------------------------------------------
    def _cargar_datos(self, filtro=""):
        cur = self.conn.cursor()
        if filtro:
            like = f"%{filtro}%"
            cur.execute("""
                SELECT id, ref_proveedor, proveedor, tipo, marca, modelo, descripcion, precio
                FROM productos
                WHERE proveedor LIKE ? OR marca LIKE ? OR modelo LIKE ? OR tipo LIKE ?
                ORDER BY tipo, marca, modelo
            """, (like, like, like, like))
        else:
            cur.execute("""
                SELECT id, ref_proveedor, proveedor, tipo, marca, modelo, descripcion, precio
                FROM productos
                ORDER BY tipo, marca, modelo
            """)
        rows = cur.fetchall()

        for i in self.tree.get_children():
            self.tree.delete(i)
        for r in rows:
            self.tree.insert("", "end", iid=r[0], values=(
                r[0], r[1] or "", r[2] or "", r[3] or "", r[4] or "", r[5] or "", r[6] or "", f"{r[7]:.2f}" if r[7] else "0.00"))

    # -----------------------------------------------------------------------------------
    def _nuevo(self):
        campos = ["ref_proveedor", "proveedor", "tipo", "marca", "modelo", "descripcion", "precio"]
        datos = {}
        for c in campos[:-1]:
            datos[c] = simpledialog.askstring("Nuevo producto", f"{c.replace('_',' ').title()}:") or ""
        precio_txt = simpledialog.askstring("Nuevo producto", "Precio (€):", initialvalue="0.00")
        try:
            datos["precio"] = float(Decimal(precio_txt).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
        except:
            messagebox.showerror("Error", "Precio inválido.")
            return

        cur = self.conn.cursor()
        try:
            cur.execute("""
                INSERT INTO productos (ref_proveedor, proveedor, tipo, marca, modelo, descripcion, precio)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, tuple(datos[c] for c in campos))
            self.conn.commit()
            self._cargar_datos()
            messagebox.showinfo("OK", "Producto añadido correctamente.")
        except sqlite3.IntegrityError:
            messagebox.showerror("Error", "El modelo ya existe.")

    # -----------------------------------------------------------------------------------
    def _editar(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Info", "Selecciona un producto para editar.")
            return
        item_id = sel[0]
        cur = self.conn.cursor()
        cur.execute("""
            SELECT ref_proveedor, proveedor, tipo, marca, modelo, descripcion, precio
            FROM productos WHERE id=?
        """, (item_id,))
        row = cur.fetchone()
        if not row:
            return
        ref_proveedor, proveedor, tipo, marca, modelo, descripcion, precio = row

        nuevos = {}
        for campo, valor in zip(["ref_proveedor", "proveedor", "tipo", "marca", "modelo", "descripcion"],
                                [ref_proveedor, proveedor, tipo, marca, modelo, descripcion]):
            nuevos[campo] = simpledialog.askstring("Editar", f"{campo.replace('_',' ').title()}:",
                                                   initialvalue=valor or "") or valor

        precio_txt = simpledialog.askstring("Editar precio", "Precio (€):", initialvalue=f"{precio:.2f}")
        try:
            nuevos["precio"] = float(Decimal(precio_txt).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
        except:
            messagebox.showerror("Error", "Precio inválido.")
            return

        cur.execute("""
            UPDATE productos
            SET ref_proveedor=?, proveedor=?, tipo=?, marca=?, modelo=?, descripcion=?, precio=?, fecha_mod=CURRENT_TIMESTAMP
            WHERE id=?
        """, (*nuevos.values(), item_id))
        self.conn.commit()
        self._cargar_datos()
        messagebox.showinfo("OK", "Producto actualizado.")

    # -----------------------------------------------------------------------------------
    def _eliminar(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Info", "Selecciona uno o más productos para eliminar.")
            return
        if not messagebox.askyesno("Confirmar", "¿Eliminar los productos seleccionados?"):
            return
        cur = self.conn.cursor()
        for iid in sel:
            cur.execute("DELETE FROM productos WHERE id=?", (iid,))
        self.conn.commit()
        self._cargar_datos()
        messagebox.showinfo("OK", "Productos eliminados.")

    # -----------------------------------------------------------------------------------
    def _exportar_excel(self):
        """Exporta todos los productos a un archivo Excel."""
        try:
            cur = self.conn.cursor()
            cur.execute("""
                SELECT ref_proveedor, proveedor, tipo, marca, modelo, descripcion, precio
                FROM productos
                ORDER BY tipo, marca, modelo
            """)
            rows = cur.fetchall()

            if not rows:
                messagebox.showinfo("Exportar", "No hay productos para exportar.")
                return

            file_path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx")],
                title="Guardar archivo Excel",
                initialfile="productos.xlsx"
            )
            if not file_path:
                return

            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Productos"
            headers = ["ref_proveedor", "proveedor", "tipo", "marca", "modelo", "descripcion", "precio"]
            ws.append(headers)
            for row in rows:
                ws.append(row)
            for col in ws.columns:
                ws.column_dimensions[col[0].column_letter].width = 20
            wb.save(file_path)
            messagebox.showinfo("Exportar", f"Productos exportados correctamente a:\n{file_path}")

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo exportar a Excel:\n{e}")

    # -----------------------------------------------------------------------------------
    def _importar_excel(self):
        """Importa o actualiza productos desde un archivo Excel."""
        try:
            file_path = filedialog.askopenfilename(
                title="Seleccionar archivo Excel",
                filetypes=[("Excel files", "*.xlsx")]
            )
            if not file_path:
                return

            wb = openpyxl.load_workbook(file_path)
            ws = wb.active

            headers = [cell.value for cell in ws[1]]
            required = ["ref_proveedor", "proveedor", "tipo", "marca", "modelo", "descripcion", "precio"]
            if headers != required:
                messagebox.showerror(
                    "Error de formato",
                    f"El archivo Excel debe tener exactamente estas columnas:\n\n{', '.join(required)}"
                )
                wb.close()
                return

            cur = self.conn.cursor()
            nuevos, actualizados = 0, 0

            for row in ws.iter_rows(min_row=2, values_only=True):
                ref_proveedor, proveedor, tipo, marca, modelo, descripcion, precio = row
                cur.execute("SELECT id FROM productos WHERE modelo=?", (modelo,))
                existe = cur.fetchone()

                if existe:
                    cur.execute("""
                        UPDATE productos
                        SET ref_proveedor=?, proveedor=?, tipo=?, marca=?, descripcion=?, precio=?, fecha_mod=CURRENT_TIMESTAMP
                        WHERE modelo=?
                    """, (ref_proveedor, proveedor, tipo, marca, descripcion, float(precio or 0), modelo))
                    actualizados += 1
                else:
                    cur.execute("""
                        INSERT INTO productos (ref_proveedor, proveedor, tipo, marca, modelo, descripcion, precio)
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (ref_proveedor, proveedor, tipo, marca, modelo, descripcion, float(precio or 0)))
                    nuevos += 1

            self.conn.commit()
            wb.close()
            self._cargar_datos()
            messagebox.showinfo("Importar Excel", f"✅ {nuevos} nuevos | 🔁 {actualizados} actualizados")

        except Exception as e:
            messagebox.showerror("Error", f"No se pudo importar desde Excel:\n{e}")
