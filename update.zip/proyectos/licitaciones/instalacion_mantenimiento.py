import tkinter as tk
from tkinter import ttk, messagebox
from decimal import Decimal, ROUND_HALF_UP
import sqlite3
import os

class InstalacionMantenimientoApp:
    def __init__(self, parent, conn, current_user):
        self.parent = parent
        self.conn = conn
        self.current_user = current_user
        self.parent.title("Instalación y Mantenimiento - Licitaciones")
        self.parent.state("zoomed")

        self.productos_map = {}
        self._cargar_productos()
        self._build_ui()

    # ==========================================================
    # === BASE DE DATOS: CARGA DE PRODUCTOS ====================
    # ==========================================================
    def _cargar_productos(self):
        """Carga los productos y precios desde productos.db"""
        try:
            import os
            # Buscar la base de datos productos.db en la carpeta de licitaciones
            base_dir = os.path.dirname(os.path.abspath(__file__))
            db_path = os.path.join(base_dir, "productos.db")

            if not os.path.exists(db_path):
                # Si no existe, intentar buscarla un nivel arriba
                db_path = os.path.join(os.path.dirname(base_dir), "productos.db")

            conn = sqlite3.connect(db_path)
            cur = conn.cursor()
            cur.execute("""
                SELECT modelo, tipo, precio
                FROM productos
                WHERE modelo IS NOT NULL AND modelo <> ''
                ORDER BY tipo, marca, modelo
            """)
            rows = cur.fetchall()
            conn.close()

            self.productos_map = {r[0]: {"tipo": r[1], "precio": Decimal(str(r[2]))} for r in rows}

        except Exception as e:
            messagebox.showerror("Error", f"No se pudieron cargar los productos:\n{e}")
            self.productos_map = {}


    # ==========================================================
    # === INTERFAZ =============================================
    # ==========================================================
    def _build_ui(self):
        notebook = ttk.Notebook(self.parent)
        notebook.pack(expand=True, fill="both")

        self.tab_inst = ttk.Frame(notebook)
        self.tab_mant = ttk.Frame(notebook)

        notebook.add(self.tab_inst, text="Instalación")
        notebook.add(self.tab_mant, text="Mantenimiento")

        self._ui_instalacion()
        self._ui_mantenimiento()

    # ==========================================================
    # === PESTAÑA: INSTALACIÓN =================================
    # ==========================================================
    def _ui_instalacion(self):
        frame = tk.Frame(self.tab_inst, bg="white")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        # --- Encabezado ---
        tk.Label(frame, text="Cálculo de Instalaciones Nuevas", bg="white", fg="#004080",
                 font=("Segoe UI", 20, "bold")).pack(pady=10)

        # --- Configuración general ---
        cfg = tk.Frame(frame, bg="white")
        cfg.pack(pady=10)

        campos = [
            ("Km ida", "ent_km_ida"), ("Km vuelta", "ent_km_vuelta"),
            ("Técnicos", "ent_tecnicos"), ("Horas trabajo", "ent_horas"),
            ("Coste €/Km", "ent_coste_km"), ("Coste €/Hora", "ent_coste_hora")
        ]

        for i, (lbl, var) in enumerate(campos):
            tk.Label(cfg, text=lbl + ":", bg="white").grid(row=0, column=i*2, sticky="e", padx=4)
            ent = tk.Entry(cfg, width=8)
            ent.grid(row=0, column=i*2+1, padx=4)
            setattr(self, var, ent)

        # --- Materiales ---
        tk.Label(frame, text="Materiales a Instalar:", bg="white",
                 font=("Segoe UI", 12, "bold")).pack(anchor="w", pady=(20,5))

        mat_frame = tk.Frame(frame, bg="white")
        mat_frame.pack(fill="x")

        tk.Label(mat_frame, text="Elemento / Modelo:", bg="white").grid(row=0, column=0, sticky="w")
        self.combo_elemento_inst = ttk.Combobox(mat_frame, width=40,
                                                values=list(self.productos_map.keys()))
        self.combo_elemento_inst.grid(row=0, column=1, padx=6)
        self.combo_elemento_inst.bind("<<ComboboxSelected>>", self._actualizar_precio_inst)

        tk.Label(mat_frame, text="Cantidad:", bg="white").grid(row=0, column=2, sticky="w")
        self.ent_cantidad_inst = tk.Entry(mat_frame, width=6)
        self.ent_cantidad_inst.grid(row=0, column=3, padx=6)

        tk.Label(mat_frame, text="Precio unitario (€):", bg="white").grid(row=0, column=4, sticky="w")
        self.ent_precio_unit_inst = tk.Entry(mat_frame, width=10)
        self.ent_precio_unit_inst.grid(row=0, column=5, padx=6)

        tk.Button(mat_frame, text="Añadir", bg="#1976d2", fg="white",
                  command=self._add_material_inst).grid(row=0, column=6, padx=8)

        # --- Tabla de materiales ---
        cols = ("modelo", "cantidad", "precio", "subtotal")
        self.tree_inst = ttk.Treeview(frame, columns=cols, show="headings", height=15)
        for c in cols:
            self.tree_inst.heading(c, text=c.capitalize())
            self.tree_inst.column(c, width=150, anchor="center")
        self.tree_inst.pack(fill="both", pady=10)

        # --- Botón Calcular ---
        tk.Button(frame, text="Calcular Coste Total", bg="#388e3c", fg="white",
                  font=("Segoe UI", 12, "bold"), command=self._calcular_instalacion).pack(pady=10)

    def _actualizar_precio_inst(self, event=None):
        modelo = self.combo_elemento_inst.get()
        if modelo in self.productos_map:
            precio = self.productos_map[modelo]["precio"]
            self.ent_precio_unit_inst.delete(0, "end")
            self.ent_precio_unit_inst.insert(0, str(precio))

    def _add_material_inst(self):
        modelo = self.combo_elemento_inst.get()
        try:
            cantidad = Decimal(self.ent_cantidad_inst.get())
            precio = Decimal(self.ent_precio_unit_inst.get())
            subtotal = cantidad * precio
            self.tree_inst.insert("", "end", values=(modelo, f"{cantidad}", f"{precio}", f"{subtotal:.2f}"))
            self.ent_cantidad_inst.delete(0, "end")
        except:
            messagebox.showerror("Error", "Introduce cantidad y precio válidos.")

    def _calcular_instalacion(self):
        km_ida = Decimal(self.ent_km_ida.get() or 0)
        km_vuelta = Decimal(self.ent_km_vuelta.get() or 0)
        tecnicos = Decimal(self.ent_tecnicos.get() or 1)
        horas = Decimal(self.ent_horas.get() or 0)
        coste_km = Decimal(self.ent_coste_km.get() or 0)
        coste_hora = Decimal(self.ent_coste_hora.get() or 0)

        # --- Materiales ---
        total_materiales = Decimal("0.00")
        for item in self.tree_inst.get_children():
            valores = self.tree_inst.item(item, "values")
            try:
                total_materiales += Decimal(valores[3])
            except:
                pass

        desplazamiento = (km_ida + km_vuelta) * coste_km
        mano_obra = tecnicos * horas * coste_hora
        total = desplazamiento + mano_obra + total_materiales

        resumen = (
            f"Materiales: {total_materiales:.2f} €\n"
            f"Mano de obra: {mano_obra:.2f} €\n"
            f"Desplazamiento: {desplazamiento:.2f} €\n\n"
            f"💰 TOTAL INSTALACIÓN: {total:.2f} €"
        )
        messagebox.showinfo("Resumen instalación", resumen)

    # ==========================================================
    # === PESTAÑA: MANTENIMIENTO ===============================
    # ==========================================================
    def _ui_mantenimiento(self):
        frame = tk.Frame(self.tab_mant, bg="white")
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        tk.Label(frame, text="Cálculo de Costes Anuales de Mantenimiento", bg="white",
                 fg="#004080", font=("Segoe UI", 20, "bold")).pack(pady=10)

        cfg = tk.Frame(frame, bg="white")
        cfg.pack(pady=10)

        campos = [
            ("Revisiones presenciales", "ent_rev_pres"),
            ("Revisiones bidireccionales", "ent_rev_bidi"),
            ("Coste mano de obra €/h", "ent_coste_hora_mant"),
            ("Horas por revisión", "ent_horas_rev"),
            ("Km desplazamiento total", "ent_km_total_mant"),
            ("Coste €/Km", "ent_coste_km_mant"),
        ]

        for i, (lbl, var) in enumerate(campos):
            tk.Label(cfg, text=lbl + ":", bg="white").grid(row=0, column=i*2, sticky="e", padx=4)
            ent = tk.Entry(cfg, width=8)
            ent.grid(row=0, column=i*2+1, padx=4)
            setattr(self, var, ent)

        # --- CRA / SIM ---
        extra = tk.Frame(frame, bg="white")
        extra.pack(pady=10)

        tk.Label(extra, text="CRA (modelo):", bg="white").grid(row=0, column=0)
        self.combo_cra = ttk.Combobox(extra, width=25,
                                      values=[m for m, v in self.productos_map.items() if v["tipo"].upper() == "CRA"])
        self.combo_cra.grid(row=0, column=1, padx=6)

        tk.Label(extra, text="SIM (modelo):", bg="white").grid(row=0, column=2)
        self.combo_sim = ttk.Combobox(extra, width=25,
                                      values=[m for m, v in self.productos_map.items() if v["tipo"].upper() == "SIM"])
        self.combo_sim.grid(row=0, column=3, padx=6)

        tk.Button(frame, text="Calcular Mantenimiento", bg="#1976d2", fg="white",
                  font=("Segoe UI", 12, "bold"), command=self._calcular_mantenimiento).pack(pady=20)

    def _calcular_mantenimiento(self):
        try:
            rev_pres = Decimal(self.ent_rev_pres.get() or 0)
            rev_bidi = Decimal(self.ent_rev_bidi.get() or 0)
            horas_rev = Decimal(self.ent_horas_rev.get() or 0)
            coste_hora = Decimal(self.ent_coste_hora_mant.get() or 0)
            km_total = Decimal(self.ent_km_total_mant.get() or 0)
            coste_km = Decimal(self.ent_coste_km_mant.get() or 0)

            cra_model = self.combo_cra.get()
            sim_model = self.combo_sim.get()
            cra_precio = self.productos_map.get(cra_model, {}).get("precio", Decimal("0.00"))
            sim_precio = self.productos_map.get(sim_model, {}).get("precio", Decimal("0.00"))

            coste_pres = rev_pres * (horas_rev * coste_hora + km_total * coste_km)
            coste_bidi = rev_bidi * (horas_rev * coste_hora * Decimal("0.3"))  # supongamos 30% del tiempo
            total = coste_pres + coste_bidi + cra_precio + sim_precio

            resumen = (
                f"Revisiones presenciales: {rev_pres} x ({horas_rev}h + km) = {coste_pres:.2f} €\n"
                f"Revisiones bidireccionales: {rev_bidi} = {coste_bidi:.2f} €\n"
                f"CRA ({cra_model}): {cra_precio:.2f} €\n"
                f"SIM ({sim_model}): {sim_precio:.2f} €\n\n"
                f"💰 TOTAL MANTENIMIENTO ANUAL: {total:.2f} €"
            )
            messagebox.showinfo("Resumen mantenimiento", resumen)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo calcular:\n{e}")
