# Paquete de licitaciones
from .licitaciones import LicitacionesApp
