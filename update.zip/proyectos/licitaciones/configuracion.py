# proyectos/licitaciones/configuracion.py
import tkinter as tk
from tkinter import messagebox
from proyectos.licitaciones.productos import ProductosApp

class ConfiguracionLicitacionesApp:
    """
    Ventana de configuración para Licitaciones. Desde aquí se accede a 'Precios'.
    Recibe parent, conn y current_user.
    """
    def __init__(self, parent, conn, current_user):
        self.parent = parent
        self.conn = conn
        self.current_user = current_user
        self.build_ui()

    def build_ui(self):
        self.parent.title("Configuración - Licitaciones")
        self.parent.geometry("520x260")
        self.parent.configure(bg="white")

        tk.Label(self.parent, text="Configuración de Licitaciones", font=("Segoe UI", 16, "bold"),
                 fg="#004080", bg="white").pack(pady=18)

        btns = tk.Frame(self.parent, bg="white")
        btns.pack(pady=12)


        tk.Button(btns, text="Cerrar", bg="#757575", fg="white", width=20,
                  font=("Segoe UI", 11), command=self.parent.destroy).pack(pady=8)
        
        tk.Button(btns, text="Productos (Base de datos de materiales)", bg="#1976d2", fg="white",
          width=30, font=("Segoe UI", 11), command=self.abrir_productos).pack(pady=8)


        
    def abrir_productos(self):
        win = tk.Toplevel(self.parent)
        ProductosApp(win)



    
