import os
import sys

def get_resource_path(relative_path: str) -> str:
    """
    Devuelve la ruta correcta tanto en modo desarrollo (Python)
    como en modo compilado (.exe con PyInstaller).
    """
    try:
        # Cuando se ejecuta el .exe
        base_path = sys._MEIPASS
    except Exception:
        # Cuando se ejecuta desde Python
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)
