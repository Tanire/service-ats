@echo off
echo ==========================================
echo    INSTALADOR Y LANZADOR SERVICE ATS
echo ==========================================
echo.

:: Comprobar si Python esta instalado
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python no esta instalado. Por favor instalalo desde python.org.
    pause
    exit /b
)

:: Crear entorno virtual si no existe
if not exist "venv" (
    echo [INFO] Creando entorno virtual...
    python -m venv venv
)

:: Activar entorno
call venv\Scripts\activate.bat

:: Instalar dependencias
if exist "requirements.txt" (
    echo [INFO] Instalando/Actualizando dependencias...
    pip install -r requirements.txt
) else (
    echo [ADVERTENCIA] No se encontro requirements.txt.
)

:: Ejecutar aplicacion
echo.
echo [INFO] Iniciando aplicacion...
python main.py

pause
