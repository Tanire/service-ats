import os
import sys
import shutil
import subprocess
from pathlib import Path

# Configuración
PROJECT_ROOT = Path(__file__).resolve().parent
UPDATE_ZIP = "update.zip"
VERSION_FILE = "version.txt"
REPO_URL = "https://github.com/Tanire/service-ats-releases.git"
REPO_DIR = PROJECT_ROOT / "service-ats-releases-repo"
PAT_TOKEN = "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"

# Insertar el token en la URL para autenticación automática
if "https://" in REPO_URL and PAT_TOKEN and PAT_TOKEN != "TU_TOKEN_GITHUB_AQUI":
    url_sin_auth = REPO_URL.replace("https://", "")
    AUTH_REPO_URL = f"https://oauth2:{PAT_TOKEN}@{url_sin_auth}"
else:
    AUTH_REPO_URL = REPO_URL

def run_cmd(cmd, cwd=None):
    try:
        subprocess.run(cmd, cwd=cwd, check=True, shell=True)
        return True
    except subprocess.CalledProcessError as e:
        print(f"ERROR ejecutando comando: {cmd}\n{e}")
        return False

def upload_updates():
    print("="*50)
    print(" SUBIR ACTUALIZACIÓN A GITHUB")
    print("="*50)

    if not os.path.exists(UPDATE_ZIP):
        print(f"ERROR: No se encuentra {UPDATE_ZIP}. Crea el archivo .zip de la actualización primero.")
        return
        
    if not os.path.exists(VERSION_FILE):
        print(f"ERROR: No se encuentra {VERSION_FILE}.")
        return

    # 1. Clonar el repositorio si no existe
    if not os.path.exists(REPO_DIR):
        print("1. Clonando repositorio de actualizaciones...")
        if not run_cmd(f"git clone {AUTH_REPO_URL} {REPO_DIR.name}", cwd=PROJECT_ROOT):
            return
    else:
        print("1. Configurando token de acceso...")
        run_cmd(f"git remote set-url origin {AUTH_REPO_URL}", cwd=REPO_DIR)
        print("1. Actualizando repositorio local...")
        if not run_cmd("git pull origin main", cwd=REPO_DIR):
            print("Intento de pull falló, es posible que no haya remotos o haya conflictos.")

    # 2. Copiar archivos
    print("2. Copiando archivos al repositorio...")
    try:
        shutil.copy2(UPDATE_ZIP, REPO_DIR / "update.zip")
        shutil.copy2(VERSION_FILE, REPO_DIR / "version.txt")
    except Exception as e:
        print(f"ERROR al copiar archivos: {e}")
        return

    # 3. Hacer push a GitHub
    print("3. Subiendo cambios a GitHub...")
    
    # Git add
    if not run_cmd("git add update.zip version.txt", cwd=REPO_DIR): return
    
    # Comprobar si hay cambios para commit
    status = subprocess.run("git status --porcelain", cwd=REPO_DIR, capture_output=True, text=True, shell=True)
    if not status.stdout.strip():
        print("No hay cambios nuevos para subir. La versión es la misma.")
        return
        
    # Git commit
    with open(VERSION_FILE, "r") as f:
        version = f.read().strip()
    
    if not run_cmd(f'git commit -m "Update to version {version}"', cwd=REPO_DIR): return
    
    # Git push
    if not run_cmd("git push origin main", cwd=REPO_DIR): return

    print("\n[OK] PROCESO COMPLETADO EXITO! Los clientes podran descargar la actualizacion ahora.")

if __name__ == "__main__":
    upload_updates()
