from pydantic import BaseModel
from typing import Optional, List, Any

class UserLogin(BaseModel):
    username: str
    password: str

class UserOut(BaseModel):
    id: int
    username: str
    is_admin: int
    # Permissions is stored as JSON string in DB, we can send it as is or parse it.
    # For simplicity in this POC, we'll confirm login success first.
    permissions: str 
    theme: str

class OvertimeCreate(BaseModel):
    fecha: str
    motivo: str
    cliente: str
    horas: float
    total: float
    tipo: str
    usuario: str    

class OvertimeOut(OvertimeCreate):
    id: int

class ExpenseCreate(BaseModel):
    fecha: str
    tipo: str
    detalle: str
    importe: float
    usuario: str

class ExpenseOut(ExpenseCreate):
    id: int
