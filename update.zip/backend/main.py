from fastapi import FastAPI
from backend.routers import auth, technicians

app = FastAPI(title="Service ATS API")

# Include routers
app.include_router(auth.router)
app.include_router(technicians.router)

@app.get("/")
def read_root():
    return {"message": "Service ATS API is running!", "status": "online"}
