import sqlite3
import os

# Point to the root directory where service_ats.db is located
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "service_ats.db")

def get_db_connection():
    """Establishes a connection to the SQLite database."""
    try:
        conn = sqlite3.connect(DB_PATH)
        # Configure row factory to access columns by name
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Error connecting to database at {DB_PATH}: {e}")
        raise e

# Paths for other databases
HORAS_DB_PATH = os.path.join(BASE_DIR, "proyectos", "tecnicos", "horas_extras.db")
GASTOS_DB_PATH = os.path.join(BASE_DIR, "proyectos", "tecnicos", "gastos.db")

def get_horas_db_connection():
    try:
        conn = sqlite3.connect(HORAS_DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Error connecting to Horas DB: {e}")
        raise e

def get_gastos_db_connection():
    try:
        conn = sqlite3.connect(GASTOS_DB_PATH)
        conn.row_factory = sqlite3.Row
        return conn
    except Exception as e:
        print(f"Error connecting to Gastos DB: {e}")
        raise e
