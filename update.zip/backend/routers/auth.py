from fastapi import APIRouter, HTTPException
from backend.models import UserLogin, UserOut
from backend.database import get_db_connection

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/login", response_model=UserOut)
def login(user: UserLogin):
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Logic copied from main.py: Case-insensitive username check, case-sensitive password
    cursor.execute("SELECT * FROM usuarios WHERE LOWER(username)=? AND password=?", (user.username.lower(), user.password))
    row = cursor.fetchone()
    conn.close()

    if row:
        return UserOut(
            id=row["id"],
            username=row["username"],
            is_admin=row["is_admin"],
            permissions=row["permissions"] if row["permissions"] else "[]",
            theme=row["theme"] if "theme" in row.keys() and row["theme"] else "flatly"
        )
    else:
        raise HTTPException(status_code=401, detail="Usuario o contraseña incorrectos")
