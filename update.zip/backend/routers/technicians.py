from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from backend.models import OvertimeCreate, OvertimeOut, ExpenseCreate, ExpenseOut
from backend.database import get_horas_db_connection, get_gastos_db_connection

router = APIRouter(prefix="/technicians", tags=["technicians"])

# --- HOURS / OVERTIME ---

@router.get("/overtime", response_model=List[OvertimeOut])
def get_overtime(
    username: Optional[str] = None, 
    month: Optional[str] = Query(None, description="Format YYYY-MM")
):
    conn = get_horas_db_connection()
    c = conn.cursor()
    
    query = "SELECT * FROM horas_extras WHERE 1=1"
    params = []
    
    if username:
        query += " AND usuario=?"
        params.append(username)
    
    if month:
        query += " AND fecha LIKE ?"
        params.append(f"{month}%")
        
    query += " ORDER BY fecha DESC"
    
    c.execute(query, params)
    rows = c.fetchall()
    conn.close()
    
    return [dict(row) for row in rows]

@router.post("/overtime", response_model=OvertimeOut)
def create_overtime(item: OvertimeCreate):
    conn = get_horas_db_connection()
    c = conn.cursor()
    try:
        c.execute("""
            INSERT INTO horas_extras (fecha, motivo, cliente, horas, total, tipo, usuario) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (item.fecha, item.motivo, item.cliente, item.horas, item.total, item.tipo, item.usuario))
        item_id = c.lastrowid
        conn.commit()
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    conn.close()
    
    return OvertimeOut(id=item_id, **item.model_dump())

# --- EXPENSES ---

@router.get("/expenses", response_model=List[ExpenseOut])
def get_expenses(
    username: Optional[str] = None,
    month: Optional[str] = Query(None, description="Format YYYY-MM")
):
    conn = get_gastos_db_connection()
    c = conn.cursor()
    
    query = "SELECT * FROM gastos WHERE 1=1"
    params = []
    
    if username:
        query += " AND usuario=?"
        params.append(username)
    
    if month:
        query += " AND fecha LIKE ?"
        params.append(f"{month}%")
        
    query += " ORDER BY fecha DESC"
    
    c.execute(query, params)
    rows = c.fetchall()
    conn.close()
    
    return [dict(row) for row in rows]

@router.post("/expenses", response_model=ExpenseOut)
def create_expense(item: ExpenseCreate):
    conn = get_gastos_db_connection()
    c = conn.cursor()
    try:
        c.execute("""
            INSERT INTO gastos (fecha, tipo, detalle, importe, usuario) 
            VALUES (?, ?, ?, ?, ?)
        """, (item.fecha, item.tipo, item.detalle, item.importe, item.usuario))
        item_id = c.lastrowid
        conn.commit()
    except Exception as e:
        conn.close()
        raise HTTPException(status_code=500, detail=f"Database error: {e}")
    conn.close()
    
    return ExpenseOut(id=item_id, **item.model_dump())
