@echo off
echo ==================================================
echo REPARANDO ENTORNO VIRTUAL
echo ==================================================
echo.
echo 1. Eliminando entorno antiguo (.venv)...
if exist .venv (
    rmdir /s /q .venv
)

echo 2. Creando nuevo entorno virtual...
python -m venv .venv

echo 3. Actualizando pip...
.venv\Scripts\python.exe -m pip install --upgrade pip

echo 4. Instalando dependencias...
.venv\Scripts\pip install -r requirements.txt
if exist requirements_api.txt (
    .venv\Scripts\pip install -r requirements_api.txt
)

echo.
echo ==================================================
echo REPARACION COMPLETADA.
echo Ahora intenta abrir el programa de nuevo.
echo ==================================================
pause
