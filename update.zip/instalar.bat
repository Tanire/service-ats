@echo off
title Instalador de Service ATS
color 0A

echo ==================================================
echo   INSTALADOR DE SERVICE ATS (v1.17.0)
echo ==================================================
echo.
echo Se instalara la aplicacion en la siguiente ruta:
echo   %LOCALAPPDATA%\SoftwareATS
echo.
set /p confirmar="¿Desea continuar con la instalacion? (S/N): "
if /i "%confirmar%" neq "S" (
    echo.
    echo Instalacion cancelada.
    echo.
    pause
    exit /b
)

echo.
echo 1. Copiando archivos de la aplicacion...
if not exist "%LOCALAPPDATA%\SoftwareATS" mkdir "%LOCALAPPDATA%\SoftwareATS"
xcopy /E /I /Y "ServiceATS" "%LOCALAPPDATA%\SoftwareATS\ServiceATS" >nul

echo.
echo 2. Creando accesos directos...
:: Crear acceso directo en el Escritorio
powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Service ATS.lnk')); $Shortcut.TargetPath = [System.IO.Path]::Combine($env:LOCALAPPDATA, 'SoftwareATS', 'ServiceATS', 'ServiceATS.exe'); $Shortcut.WorkingDirectory = [System.IO.Path]::Combine($env:LOCALAPPDATA, 'SoftwareATS', 'ServiceATS'); $Shortcut.IconLocation = [System.IO.Path]::Combine($env:LOCALAPPDATA, 'SoftwareATS', 'ServiceATS', '_internal', 'assets', 'icon.ico'); $Shortcut.Save()"

:: Crear acceso directo en el Menú Inicio
powershell -Command "$WshShell = New-Object -ComObject WScript.Shell; $StartMenu = [System.IO.Path]::Combine([Environment]::GetFolderPath('Programs'), 'Service ATS'); if (!(Test-Path $StartMenu)) { New-Item -ItemType Directory -Path $StartMenu | Out-Null }; $Shortcut = $WshShell.CreateShortcut([System.IO.Path]::Combine($StartMenu, 'Service ATS.lnk')); $Shortcut.TargetPath = [System.IO.Path]::Combine($env:LOCALAPPDATA, 'SoftwareATS', 'ServiceATS', 'ServiceATS.exe'); $Shortcut.WorkingDirectory = [System.IO.Path]::Combine($env:LOCALAPPDATA, 'SoftwareATS', 'ServiceATS'); $Shortcut.IconLocation = [System.IO.Path]::Combine($env:LOCALAPPDATA, 'SoftwareATS', 'ServiceATS', '_internal', 'assets', 'icon.ico'); $Shortcut.Save()"

echo.
echo ==================================================
echo   INSTALACION COMPLETADA CON EXITO
echo ==================================================
echo.
echo Puedes iniciar el programa utilizando el acceso directo
echo creado en tu Escritorio ("Service ATS").
echo.
pause
