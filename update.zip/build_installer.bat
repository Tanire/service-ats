@echo off
echo ==================================================
echo   CONSTRUYENDO INSTALADOR (setup.exe)
echo ==================================================
echo.

set PYTHON_EXE=.\.venv\Scripts\python.exe

if not exist "%PYTHON_EXE%" (
    set PYTHON_EXE=.\venv\Scripts\python.exe
)

if not exist "%PYTHON_EXE%" (
    echo [ERROR] No se encuentra python.exe
    pause
    exit /b 1
)

if exist "dist\setup.exe" del "dist\setup.exe"

echo Empaquetando Instalador con PyInstaller...
"%PYTHON_EXE%" -m PyInstaller --noconsole --onefile ^
    --name setup ^
    --add-data "dist\ServiceATS;ServiceATS" ^
    --icon "assets\icon.ico" ^
    installer.py

echo.
if exist "dist\setup.exe" (
    echo [EXITO] Instalador creado: dist\setup.exe
    if not exist "..\instalacion" mkdir "..\instalacion"
    copy "dist\setup.exe" "..\instalacion\setup.exe"
    echo El instalador final esta en la carpeta "instalacion"
) else (
    echo [ERROR] Fallo al crear el instalador.
)

pause
