import sys
import os
import shutil
import winshell
from win32com.client import Dispatch
import subprocess
import tkinter as tk
from tkinter import messagebox

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

def create_shortcut(target_path, shortcut_path, icon_path=None, working_dir=None):
    shell = Dispatch('WScript.Shell')
    shortcut = shell.CreateShortCut(shortcut_path)
    shortcut.Targetpath = target_path
    if working_dir:
        shortcut.WorkingDirectory = working_dir
    if icon_path:
        shortcut.IconLocation = icon_path
    shortcut.save()

def main():
    root = tk.Tk()
    root.withdraw() # Hide main window

    # Destination folder selection
    local_app_data = os.getenv('LOCALAPPDATA')
    default_dest = os.path.join(local_app_data, 'SoftwareATS')
    
    from tkinter import filedialog
    dest_folder = filedialog.askdirectory(
        initialdir=local_app_data,
        title="Selecciona la carpeta donde quieres instalar Service ATS"
    )
    
    if not dest_folder:
        return # User cancelled
        
    dest_folder = os.path.join(dest_folder, 'SoftwareATS')
    
    msg = messagebox.askyesno("Confirmar Instalación", 
                             f"El software se instalará en:\n{dest_folder}\n\n¿Deseas continuar?")
    if not msg:
        return

    # Delete existing if it exists
    if os.path.exists(dest_folder):
        try:
            shutil.rmtree(dest_folder, ignore_errors=True)
        except:
            pass
            
    # Copy the whole ServiceATS folder
    src_folder = resource_path("ServiceATS")
    try:
        shutil.copytree(src_folder, dest_folder, dirs_exist_ok=True)
    except Exception as e:
        messagebox.showerror("Error", f"Fallo al copiar los archivos:\n{e}")
        return

    # Desktop shortcut
    exe_dest = os.path.join(dest_folder, "ServiceATS.exe")
    desktop = winshell.desktop()
    shortcut_path = os.path.join(desktop, "Service ATS.lnk")
    icon_path = os.path.join(dest_folder, "_internal", "assets", "icon.ico") if os.path.exists(os.path.join(dest_folder, "_internal", "assets", "icon.ico")) else exe_dest
    
    create_shortcut(exe_dest, shortcut_path, icon_path=icon_path, working_dir=dest_folder)
    
    # Start Menu shortcut
    programs = winshell.programs()
    start_menu_folder = os.path.join(programs, "Service ATS")
    if not os.path.exists(start_menu_folder):
        os.makedirs(start_menu_folder)
    start_shortcut_path = os.path.join(start_menu_folder, "Service ATS.lnk")
    create_shortcut(exe_dest, start_shortcut_path, icon_path=icon_path, working_dir=dest_folder)

    messagebox.showinfo("Instalación Completa", "Service ATS se ha instalado correctamente.\n\nPuedes abrir el programa usando el acceso directo que se ha creado en tu escritorio.")

if __name__ == "__main__":
    main()
