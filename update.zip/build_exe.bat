@echo off
echo ==========================================
echo    CONSTRUCTOR DE EJECUTABLE (.EXE)
echo ==========================================
echo.

:: Intentar detectar el comando de Python
set PYTHON_CMD=python

:: Prueba 1: python
python --version >nul 2>&1
if %errorlevel% equ 0 goto :FOUND

:: Prueba 2: py (Launcher)
set PYTHON_CMD=py
py --version >nul 2>&1
if %errorlevel% equ 0 goto :FOUND

:: Prueba 3: python3
set PYTHON_CMD=python3
python3 --version >nul 2>&1
if %errorlevel% equ 0 goto :FOUND

:: Fallo
echo [ERROR] No se encuentra Python.
echo Asegurate de que Python esta instalado y agregado al PATH.
pause
exit /b

:FOUND
echo [INFO] Python detectado: %PYTHON_CMD%

:: Crear/Activar Venv
if not exist "venv" (
    echo [INFO] Creando entorno virtual...
    %PYTHON_CMD% -m venv venv
)
call venv\Scripts\activate.bat

:: Instalar dependencias si hace falta
echo [INFO] Verificando dependencias...
if exist "requirements.txt" pip install -r requirements.txt >nul
pip install pyinstaller >nul

:: Limpiar builds anteriores
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist "*.spec" del /q "*.spec"

echo.
echo [INFO] Generando ejecutable...
echo Esto puede tardar unos minutos...
echo.

:: Comando PyInstaller
pyinstaller --noconsole --onefile ^
    --name "ServiceATS_PC" ^
    --icon "assets/icon.ico" ^
    --add-data "assets;assets" ^
    --add-data "version.txt;." ^
    --hidden-import "PIL._tkinter_finder" ^
    --hidden-import "msgraph" ^
    --hidden-import "babel.numbers" ^
    main.py

echo.
if %errorlevel% neq 0 (
    echo [ERROR] Fallo al crear el ejecutable.
    pause
    exit /b
)

echo.
echo ==========================================
echo    [EXITO] EJECUTABLE CREADO
echo ==========================================
echo.
echo El archivo "ServiceATS_PC.exe" esta en la carpeta "dist".
echo.
echo Copia ese archivo (y la carpeta 'assets' si quieres editar iconos)
echo al ordenador de destino.
echo.
pause
