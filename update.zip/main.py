import tkinter as tk
from tkinter import messagebox, simpledialog, filedialog
from tkinter import Canvas as TkCanvas
import math
import os
import sqlite3
import json
import requests

import zipfile
import shutil
import time
import sys
from pathlib import Path

# Intentar usar ttkbootstrap (opcional pero recomendado)
try:
    import ttkbootstrap as ttk
    from ttkbootstrap.constants import *
    TTK_AVAILABLE = True
except Exception:
    TTK_AVAILABLE = False
    import tkinter.ttk as ttk

# Pillow (Image) con compatibilidad Resampling <- LANCZOS
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("Advertencia: PIL (Pillow) no encontrado. Logos desactivados.")
try:
    Resampling = Image.Resampling
except AttributeError:
    class _ResamplingFallback:
        LANCZOS = Image.LANCZOS
    Resampling = _ResamplingFallback

# Importar módulos externos (deja tal cual)
from sim_manager import SIMManager
from planos_manager import PlanosManagerPro as PlanosManager
import proyectos.proyectos_main as proyectos_main  # módulo principal de Proyectos

# NUEVAS IMPORTS para Drive & Horas Extras
from proyectos.tecnicos.horas_extras import HorasExtrasFrame
from proyectos.admin.log_manager import LogManager
from proyectos.sincronizacion.github_db_sync import GithubDBSync

# --- CONFIGURACIÓN --- (actualizada)
PROJECT_ROOT = Path(__file__).resolve().parent
LOGO_PATH = str(PROJECT_ROOT / "recursos" / "iconos" / "logo.png") if (PROJECT_ROOT / "recursos" / "iconos" / "logo.png").exists() else str(PROJECT_ROOT / "assets" / "logo.png") if (PROJECT_ROOT / "assets" / "logo.png").exists() else ""
VERSION = "v1.16.0"

# Drive: estructura en Mi unidad / SOFTWARE ATS
DRIVE_BASE_FOLDER = "SOFTWARE ATS"          # carpeta principal en "Mi unidad"
DRIVE_UPDATES_PATH = "updates"              # dentro de DRIVE_BASE_FOLDER
DRIVE_DATABASES_PATH = "databases"          # dentro de DRIVE_BASE_FOLDER
DRIVE_VERSION_FILE_TITLE = "version.txt"    # título del archivo en Drive (en updates/)
DRIVE_UPDATE_ZIP_TITLE = "update.zip"       # en updates/

# Local paths for DBs (mantener)
LOCAL_DB_PATH = str(PROJECT_ROOT / "service_ats.db")
# DBs específicos
LOCAL_CONFIG_DB = str(PROJECT_ROOT / "config" / "config.db")
LOCAL_GASTOS_DB = str(PROJECT_ROOT / "proyectos" / "tecnicos" / "gastos.db")
LOCAL_HORAS_DB = str(PROJECT_ROOT / "proyectos" / "tecnicos" / "horas_extras.db")
LOCAL_VACACIONES_DB = str(PROJECT_ROOT / "proyectos" / "tecnicos" / "vacaciones.db")

# CLIENT_SECRETS guardado en project config (según tu confirmación)
CLIENT_SECRETS_PATH = str(PROJECT_ROOT / "config" / "drive_auth" / "client_secrets.json")
# token y demás serán gestionados por pydrive2 dentro del módulo google_drive_sync (localmente)

# Elegir clase base: ttk.Window si ttkbootstrap está disponible (mejor integración visual)
BaseWindow = ttk.Window if TTK_AVAILABLE and hasattr(ttk, "Window") else tk.Tk


class ServiceATSApp(BaseWindow):
    def __init__(self):
        # Interfaz base
        if TTK_AVAILABLE and isinstance(BaseWindow, type) and BaseWindow is ttk.Window:
            super().__init__(themename="cyborg")
        else:
            super().__init__()

        self.title(f"SERVICE ATS - {VERSION}")
        try:
            self.state("zoomed")
        except Exception:
            self.geometry("1200x800")

        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.bind("<Escape>", lambda e: self.on_close())

        # Rutas y conexión BD principal
        self.conn = sqlite3.connect(LOCAL_DB_PATH)
        self.cursor = self.conn.cursor()
        self.create_tables()

        # Estilo / tema
        self.app_style = ttk.Style()
        self.cursor.execute("SELECT value FROM config WHERE key='theme'")
        theme_row = self.cursor.fetchone()
        theme = theme_row[0] if theme_row else "flatly"
        try:
            self.app_style.theme_use(theme)
        except Exception:
            try:
                self.app_style.theme_use("flatly")
            except Exception:
                pass

        # --- GITHUB SYNC DB ---
        self.gdrive = None
        try:
            self.gdrive = GithubDBSync(
                repo_url="https://github.com/Tanire/service-ats-db-backups.git",
                pat_token="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"
            )
        except Exception as e:
            print("Warning: no se pudo instanciar GithubDBSync:", e)
            self.gdrive = None

        # Log Manager
        try:
            log_db_path = str(PROJECT_ROOT / "proyectos" / "admin" / "logs.db")
            self.log_manager = LogManager(log_db_path)
        except Exception as e:
            print("Error init log_manager:", e)
            self.log_manager = None

        # Frames
        self.splash_frame = None
        self.login_frame = None
        self.main_frame = None
        self.main_content = None  # contenedor para cargar vistas internas (sin Toplevel)
        self.current_user = None

        self.checked_update = False

        # Mostrar splash y luego login
        self.show_splash()

    # --- CREAR TABLAS ---
    def create_tables(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            is_admin INTEGER DEFAULT 0,
            permissions TEXT DEFAULT '[]'
        )""")
        
        # Migración: Verificar si existe columna 'permissions'
        self.cursor.execute("PRAGMA table_info(usuarios)")
        columns = [col[1] for col in self.cursor.fetchall()]
        if "permissions" not in columns:
            print("Migrating DB: Adding permissions column")
            self.cursor.execute("ALTER TABLE usuarios ADD COLUMN permissions TEXT DEFAULT '[]'")
            self.conn.commit()

        # Migración: Verificar si existe columna 'theme'
        if "theme" not in columns:
            print("Migrating DB: Adding theme column to users")
            self.cursor.execute("ALTER TABLE usuarios ADD COLUMN theme TEXT DEFAULT 'flatly'")
            self.conn.commit()

        # Tabla de configuración global (simple key/value)
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS config (
            key TEXT PRIMARY KEY,
            value TEXT
        )""")

        # Si no hay tema guardado, establecer uno por defecto
        self.cursor.execute("SELECT value FROM config WHERE key='theme'")
        if not self.cursor.fetchone():
            self.cursor.execute("INSERT OR REPLACE INTO config (key, value) VALUES ('theme', 'flatly')")

        # Usuario admin por defecto
        self.cursor.execute("SELECT * FROM usuarios WHERE username='admin'")
        if not self.cursor.fetchone():
            self.cursor.execute(
                "INSERT INTO usuarios (username, password, is_admin, permissions) VALUES (?,?,?,?)",
                ("admin", "1256", 1, '["all"]')
            )
        self.conn.commit()

    # --- CERRAR ---
    # --- CERRAR ---
    def on_close(self):
        if messagebox.askokcancel("Salir", "¿Deseas salir de la aplicación?"):
            try:
                # Cerrar conexión BD local
                self.conn.close()
            except:
                pass
            
            # Intentar backup rápido si hay drive activo
            if self.gdrive:
                # Mostrar ventanita flotante "Guardando..."
                top = tk.Toplevel(self)
                top.title("Sincronizando")
                top.geometry("300x100")
                # Centrar
                x = self.winfo_x() + (self.winfo_width() // 2) - 150
                y = self.winfo_y() + (self.winfo_height() // 2) - 50
                top.geometry(f"+{x}+{y}")
                
                tk.Label(top, text="Guardando copias en la nube...\nPor favor espere.", font=("Segoe UI", 10)).pack(expand=True)
                top.update()
                
                # Ejecutar subida (bloqueante intencionalmente para no cerrar a medias)
                self._sync_databases_to_drive()
                top.destroy()

            self.destroy()

    # --- SPLASH ---
    def show_splash(self):
        self.clear_frames()
        self.splash_frame = tk.Frame(self, bg="white")
        self.splash_frame.pack(expand=True, fill="both")

        # Logo (safe)
        if LOGO_PATH and os.path.exists(LOGO_PATH):
            try:
                img = Image.open(LOGO_PATH).resize((200, 200), Resampling.LANCZOS)
                self.logo_img = ImageTk.PhotoImage(img)
                tk.Label(self.splash_frame, image=self.logo_img, bg="white").pack(pady=20)
            except Exception as e:
                print("Error cargando logo:", e)
                tk.Label(self.splash_frame, text="[LOGO]", font=("Arial", 32), fg="blue", bg="white").pack(pady=20)
        else:
            tk.Label(self.splash_frame, text="[LOGO]", font=("Arial", 32), fg="blue", bg="white").pack(pady=20)

        tk.Label(self.splash_frame, text="SERVICE ATS", font=("Segoe UI", 32, "bold"),
                 fg="#004080", bg="white").pack(pady=10)

        # STATUS CHECKLIST
        self.splash_status_frame = tk.Frame(self.splash_frame, bg="white")
        self.splash_status_frame.pack(pady=20)

        def create_status_label(text):
            lbl = tk.Label(self.splash_status_frame, text=text, font=("Segoe UI", 12), bg="white", fg="#555")
            lbl.pack(anchor="w", pady=2)
            return lbl

        self.lbl_conn = create_status_label("○ Conectando con servidor...")
        self.lbl_ver = create_status_label("○ Comprobando versión...")
        self.lbl_sync = create_status_label("○ Sincronizando bases de datos...")

        # Al terminar el splash, arrancar comprobación
        self.after(1000, self._startup_sync_tasks)

    def _startup_sync_tasks(self):
        def update_label(label, text, color="green"):
            try:
                label.config(text=text, fg=color, font=("Segoe UI", 12, "bold"))
            except: pass

        def job():
            time.sleep(1) # Pequeña pausa para ver el splash

            t0 = time.time()
            # print(f"[TIMING] Inicio Startup Job: 0.00s")

            # 1. CONEXIÓN
            conn_ok = False
            try:
                # Verificar internet primero
                import socket
                try:
                    socket.setdefaulttimeout(3)
                    socket.create_connection(("8.8.8.8", 53))
                    internet_ok = True
                except:
                    internet_ok = False
                
                if internet_ok and self.gdrive:
                    # Auth silenciosa
                    if self.gdrive.is_ready: # GithubDBSync no tiene authenticate interactivo
                        self.after(0, lambda: update_label(self.lbl_conn, "✓ Conectado a GitHub", "#2e7d32"))
                        conn_ok = True
                    else:
                        self.after(0, lambda: update_label(self.lbl_conn, "⚠ Sin token de acceso", "#ef6c00"))
                else:
                    self.after(0, lambda: update_label(self.lbl_conn, "⚠ Sin conexión a Internet", "#c62828"))
                
            except Exception as e:
                print("Error conn check:", e)
                self.after(0, lambda: update_label(self.lbl_conn, "Error de conexión", "red"))

            # 2. VERSIÓN
            if conn_ok:
                try:
                    # Usamos una versión modificada de check_for_updates que retorne estado
                    # O simplemente llamamos y asumimos éxito si no explota
                    update_avail = self._check_update_silent()
                    if update_avail:
                         self.after(0, lambda: update_label(self.lbl_ver, "⚠ Actualización disponible", "#ef6c00"))
                         # check_for_updates ya habrá lanzado el prompt en main thread si así lo configuramos
                         # pero aquí lo hemos hecho separado para controlar el texto
                    else:
                         self.after(0, lambda: update_label(self.lbl_ver, "✓ Aplicación actualizada", "#2e7d32"))
                except Exception as e:
                    print("Error ver check:", e)
                    self.after(0, lambda: update_label(self.lbl_ver, "Error comprobando versión", "red"))
            else:
                self.after(0, lambda: update_label(self.lbl_ver, "Omitido (Offline)", "#757575"))

            # 3. SYNC
            if conn_ok:
                try:
                    if self.gdrive:
                        self._sync_databases_from_drive()
                    self.after(0, lambda: update_label(self.lbl_sync, "✓ Sincronizado", "#2e7d32"))
                except Exception as e:
                    import traceback
                    print("Error sync:", e)
                    try:
                        with open("error_sync.txt", "a") as f:
                            f.write("Error: " + str(e) + "\n" + traceback.format_exc() + "\n")
                    except: pass
                    self.after(0, lambda e=e: update_label(self.lbl_sync, f"Error de sincronización: {str(e)[:30]}", "red"))
            else:
                self.after(0, lambda: update_label(self.lbl_sync, "Omitido (Offline)", "#757575"))

            # Terminar -> Login
            time.sleep(1.5)
            self.after(0, self.show_login)

        # Ejecutar en thread
        import threading
        t = threading.Thread(target=job, daemon=True)
        t.start()
        
    # --- LOGIN (ttkbootstrap integrado) ---
    def show_login(self):
        # Asegurar esquema correcto (por si el sync de Drive sobreescribió la BD con una versión vieja)
        try:
            self.create_tables()
        except Exception as e:
            print(f"Error re-verifying schema in show_login: {e}")

        self.clear_frames()

        # Crear un Canvas de fondo
        self.bg_canvas = tk.Canvas(self, bg="#1e1e28", highlightthickness=0)
        self.bg_canvas.place(relwidth=1, relheight=1)

        # Crear el elemento flotante (Logo en vez de círculo)
        self.login_floating_img = None
        if LOGO_PATH and os.path.exists(LOGO_PATH):
            try:
                # Cargar y redondear/redimensionar logo
                l_img = Image.open(LOGO_PATH).resize((300, 300), Resampling.LANCZOS)
                self.login_floating_img = ImageTk.PhotoImage(l_img)
                # Usar create_image en lugar de create_oval
                halo = self.bg_canvas.create_image(550, 400, image=self.login_floating_img)
            except Exception as e:
                print("Error loading login logo:", e)
                halo = self.bg_canvas.create_oval(0, 0, 400, 400, fill="#3a3a4d", outline="")
        else:
            halo = self.bg_canvas.create_oval(0, 0, 400, 400, fill="#3a3a4d", outline="")

        # Animación de rotación del elemento (logo orbita suavemente)
        def animate(angle=0):
            try:
                if not self.bg_canvas.winfo_exists():
                    return
                x_center, y_center = 550, 400
                radius = 50 # Radio más pequeño para movimiento sutil, o 150 para orbita amplia
                # Usuario quería "el circulo que se mueve sea el logo". El original orbitaba con radio 150.
                
                # Vamos a hacer un movimiento suave de "flotación" o una órbita lenta
                x = x_center + 40 * math.cos(math.radians(angle))
                y = y_center + 40 * math.sin(math.radians(angle))
                
                self.bg_canvas.coords(halo, x, y)
                self.bg_canvas.after(50, animate, (angle + 2) % 360)
            except Exception:
                pass

        animate()

        # Crear el frame del login encima del fondo
        self.login_frame = tk.Frame(self.bg_canvas, bg="#2d2d39", bd=0, highlightthickness=0)
        self.login_frame.place(relx=0.5, rely=0.5, anchor="center")

        # Bordes decorativos (simulan ::after)
        border = tk.Frame(self.login_frame, bg="#25252b", bd=8)
        border.pack(padx=8, pady=8)
        inner = tk.Frame(border, bg="#2d2d39", bd=0)
        inner.pack(padx=10, pady=10)

        # Contenido de login
        tk.Label(inner, text="Iniciar Sesión", font=("Segoe UI", 22, "bold"),
                 fg="white", bg="#2d2d39").pack(pady=(0, 20))

        tk.Label(inner, text="Usuario:", font=("Segoe UI", 14), bg="#2d2d39", fg="white").pack(pady=5)
        self.username_entry = tk.Entry(inner, font=("Segoe UI", 14), bg="#1e1e28", fg="white", insertbackground="white")
        self.username_entry.pack(pady=5)

        tk.Label(inner, text="Contraseña:", font=("Segoe UI", 14), bg="#2d2d39", fg="white").pack(pady=5)
        self.password_entry = tk.Entry(inner, show="*", font=("Segoe UI", 14),
                                   bg="#1e1e28", fg="white", insertbackground="white")
        self.password_entry.pack(pady=5)

        tk.Button(inner, text="Entrar", font=("Segoe UI", 14, "bold"),
                  bg="#d32f2f", fg="white", activebackground="#9a0007",
                  relief="flat", width=12,
                  command=self.check_login).pack(pady=20)

    # --- CHECK LOGIN ---
    def check_login(self):
        username = self.username_entry.get().strip()
        password = self.password_entry.get()
        try:
            # Búsqueda insensible a mayúsculas/minúsculas
            self.cursor.execute("SELECT * FROM usuarios WHERE LOWER(username)=? AND password=?", (username.lower(), password))
            user = self.cursor.fetchone()
        except Exception as e:
            messagebox.showerror("Error BD", f"Error consultando la base de datos: {e}")
            return

        if user:
            # Recuperar datos incluyendo tema
            # user = (id, username, is_admin, permissions, theme)
            # Como SELECT * es arriesgado, hacemos query explícita o mapeamos por índice si schema es fijo.
            # Mejor hacemos otra query para asegurar
            self.cursor.execute("SELECT id, username, is_admin, permissions, theme FROM usuarios WHERE id=?", (user[0],))
            u_data = self.cursor.fetchone()
            
            self.current_user = {
                "id": u_data[0],
                "username": u_data[1],
                "is_admin": u_data[2],
                "permissions": json.loads(u_data[3]) if u_data[3] else [],
                "theme": u_data[4] if u_data[4] else "flatly"
            }
            
            # Aplicar tema del usuario
            if TTK_AVAILABLE:
                try:
                    self.app_style.theme_use(self.current_user["theme"])
                except:
                    pass
            
            # LOG LOGIN
            if self.log_manager:
                self.log_manager.log(self.current_user["username"], "LOGIN", "Inicio de Sesión Exitoso")

            self.show_main()
        else:

            messagebox.showerror("Error", "Usuario o contraseña incorrectos")

    def logout(self):
        """Cierra la sesión actual y vuelve al login"""
        if messagebox.askyesno("Cerrar Sesión", "¿Estás seguro de que quieres cerrar la sesión?"):
            # LOG LOGOUT
            try:
                if self.log_manager and self.current_user:
                    self.log_manager.log(self.current_user["username"], "LOGOUT", "Cierre de Sesión")
            except: pass

            self.current_user = None
            self.clear_frames()
            self.show_login()

    # --- MAIN ---
    def show_main(self):
        self.clear_frames()
        self.main_frame = tk.Frame(self, bg="white")
        self.main_frame.pack(expand=True, fill="both")

        # --- BARRA DE NAVEGACIÓN (Solo visible en módulos) ---
        self.nav_bar = tk.Frame(self.main_frame, bg="#e0e0e0", height=40)
        # No la empaquetamos todavía
        
        # Botón Volver
        tk.Button(self.nav_bar, text="⬅ Volver al Menú", font=("Segoe UI", 10, "bold"),
                  bg="#757575", fg="white", relief="flat",
                  command=self._go_home).pack(side="left", padx=10, pady=5)
        
        # Título pequeño en nav bar (opcional)
        self.nav_title = tk.Label(self.nav_bar, text="", font=("Segoe UI", 12, "bold"), bg="#e0e0e0")
        self.nav_title.pack(side="left", padx=10)

        # --- MENÚ PRINCIPAL (Logo + Botones) ---
        self.menu_container = tk.Frame(self.main_frame, bg="white")
        self.menu_container.pack(expand=True, fill="both")

        # Logo y título
        if LOGO_PATH and os.path.exists(LOGO_PATH):
            try:
                img = Image.open(LOGO_PATH).resize((150, 150), Resampling.LANCZOS)
                self.logo_img = ImageTk.PhotoImage(img)
                tk.Label(self.menu_container, image=self.logo_img, bg="white").pack(pady=10)
            except Exception as e:
                print("Error al cargar logo en main:", e)
                tk.Label(self.menu_container, text="[LOGO]", font=("Arial", 24), fg="blue", bg="white").pack(pady=10)
        else:
            tk.Label(self.menu_container, text="[LOGO]", font=("Arial", 24), fg="blue", bg="white").pack(pady=10)

        tk.Label(self.menu_container, text="SERVICE ATS", font=("Segoe UI", 28, "bold"),
                 fg="#004080", bg="white").pack(pady=10)

        # Botones
        btns_frame = tk.Frame(self.menu_container, bg="white")
        btns_frame.pack(pady=10)



        herramientas_btn = self.create_button(btns_frame, "Herramientas", "#1976d2", self.abrir_herramientas)
        herramientas_btn.pack(pady=6)

        sim_btn = self.create_button(btns_frame, "Registro de Tarjetas SIM", "#1976d2", self.abrir_sim_manager)
        sim_btn.pack(pady=6)

        proyectos_btn = self.create_button(btns_frame, "Proyectos", "#1976d2", self.abrir_proyectos)
        proyectos_btn.pack(pady=6)

        tecnicos_btn = self.create_button(btns_frame, "Técnicos", "#1976d2", self.abrir_tecnicos)
        tecnicos_btn.pack(pady=6)

        conf_btn = self.create_button(btns_frame, "Configuración", "#1976d2", self.abrir_configuracion)
        conf_btn.pack(pady=6)



        # Separador visual
        ttk.Separator(btns_frame, orient="horizontal").pack(fill="x", pady=10)

        # Botón Cerrar Sesión
        logout_btn = self.create_button(btns_frame, "Cerrar Sesión", "#d32f2f", self.logout)
        logout_btn.pack(pady=6)
        # Si NO usamos ttk, cambiar color a rojo manualmente si no lo hace helper
        if not TTK_AVAILABLE: logout_btn.config(bg="#d32f2f")
        if TTK_AVAILABLE: logout_btn.configure(bootstyle="danger")

        # Botón Materiales movido a configuración




        # --- CONTENEDOR DE MÓDULOS ---
        self.main_content = tk.Frame(self.main_frame, bg="white")
        # No empaquetado inicialmente

        # Comprobar actualizaciones (solo una vez) - automática al iniciar la app
    # ELIMINADO: Ya se comprueba en el splash inicial (_startup_sync_tasks)
    # y el usuario tiene botón manual.
    pass

    def _show_module_view(self, title=""):
        """Oculta menú, muestra barra de navegación y contenedor de módulo"""
        self.menu_container.pack_forget()
        
        self.nav_bar.pack(side="top", fill="x")
        self.nav_title.config(text=title)
        
        self.main_content.pack(side="top", expand=True, fill="both", padx=20, pady=10)
        
        # limpiar contenido anterior
        for w in self.main_content.winfo_children():
            w.destroy()

    def _go_home(self):
        """Volver al menú principal"""
        # Limpiar módulo
        for w in self.main_content.winfo_children():
            w.destroy()
        self.main_content.pack_forget()
        self.nav_bar.pack_forget()
        
        # Mostrar menú
        self.menu_container.pack(expand=True, fill="both")

    def create_button(self, parent, text, color, command):
        # Si ttkbootstrap está disponible, usamos ttk.Button con estilo; si no, tk.Button
        if TTK_AVAILABLE:
            btn = ttk.Button(parent, text=text, bootstyle="primary", command=command, width=30)
            return btn
        else:
            return tk.Button(parent, text=text, font=("Segoe UI", 12, "bold"),
                             bg=color, fg="white", activebackground="#0d47a1",
                             activeforeground="white", relief="flat",
                             width=25, height=1, command=command)

    # --- ACTUALIZACIONES ---
    def _parse_version(self, v_str):
        """Convierte string '1.10' a tupla (1, 10) para comparación numérica segura."""
        try:
            # Eliminar posibles BOM o espacios, y caracteres no numéricos extra si los hubiera
            clean = v_str.replace("\ufeff", "").lower().strip()
            if clean.startswith("v"):
                clean = clean[1:]
            # Tomar solo la parte numérica inicial (ej. 1.2.3)
            parts = clean.split(".")
            return tuple(int(p) for p in parts if p.isdigit())
        except:
            return (0,)

    def _check_update_silent(self):
        """Retorna True si hay actualización MAYOR, False si no o error. Sin UI blocker."""
        try:
            url = "https://raw.githubusercontent.com/Tanire/service-ats-releases/main/version.txt"
            response = requests.get(url, timeout=5)
            if response.status_code == 200:
                remote_version = response.text.strip()
                remote_tuple = self._parse_version(remote_version)
                local_tuple = self._parse_version(VERSION)
                
                # Solo notificar si la remota es MAYOR estrictamente
                if remote_tuple > local_tuple:
                    # Encolar el prompt para el usuario
                    self.after(0, lambda: self._prompt_update_dialog(remote_version.strip()))
                    return True
        except Exception as e:
            print("Silent update check error:", e)
        return False

    def _prompt_update_dialog(self, remote_ver):
        if messagebox.askyesno("Actualización disponible",
                               f"Nueva versión encontrada ({remote_ver}).\n¿Actualizar ahora?"):
            self._download_and_apply_update()

    # --- ACTUALIZACIONES (Legacy / Manual) ---
    def check_for_updates(self, manual=True):
        """
        Si manual=True -> mostrar errores/avisos al usuario.
        Si manual=False -> funcionamiento silencioso: solo notifica si hay actualización disponible.
        """
        try:
            url_version = "https://raw.githubusercontent.com/Tanire/service-ats-releases/main/version.txt"
            response = requests.get(url_version, timeout=10)
            
            if response.status_code == 200:
                remote_version = response.text.strip()
                remote_tuple = self._parse_version(remote_version)
                local_tuple = self._parse_version(VERSION)
                
                if remote_tuple > local_tuple:
                    def prompt_update():
                        try:
                            if messagebox.askyesno("Actualización disponible",
                                               f"Hay una nueva versión disponible ({remote_version.strip()}).\n¿Deseas actualizar ahora?"):
                                self._download_and_apply_update()
                            else:
                                if manual:
                                    messagebox.showinfo("Actualización", "Se ha pospuesto la actualización.")
                        except: pass
                    self.after(0, prompt_update)
                else:
                    if manual:
                        self.after(0, lambda: messagebox.showinfo("Actualización", "✅ Service ATS está actualizado."))
            else:
                if manual:
                    messagebox.showwarning("Actualización", f"No se pudo conectar a GitHub para comprobar actualizaciones. Error HTTP: {response.status_code}")
        except Exception as e:
            if manual:
                messagebox.showwarning("Error", f"Excepción comprobando versión:\n{e}")
            else:
                print("check_for_updates (silent) error:", e)

    def _download_and_apply_update(self):
        """
        Descarga update.zip desde GitHub y lo extrae
        sobre la carpeta del proyecto (PROJECT_ROOT).
        Luego reinicia la aplicación.
        """
        try:
            def update_task():
                try:
                    # Mostrar ventana de progreso temporal
                    progress_top = tk.Toplevel(self)
                    progress_top.title("Actualizando")
                    progress_top.geometry("300x100")
                    progress_top.attributes('-topmost', True)
                    tk.Label(progress_top, text="Descargando actualización desde GitHub...\nPor favor espera.", font=("Segoe UI", 10)).pack(expand=True)
                    progress_top.update()

                    url_zip = "https://raw.githubusercontent.com/Tanire/service-ats-releases/main/update.zip"
                    tmp_zip = str(PROJECT_ROOT / "tmp_update.zip")
                    
                    import urllib.request
                    urllib.request.urlretrieve(url_zip, tmp_zip)
                    
                    progress_top.destroy()
                    
                    # Extraer en carpeta temporal y mover
                    extract_dir = str(PROJECT_ROOT / "tmp_update_extract")
                    if os.path.exists(extract_dir):
                        shutil.rmtree(extract_dir)
                    os.makedirs(extract_dir, exist_ok=True)
                    with zipfile.ZipFile(tmp_zip, 'r') as z:
                        z.extractall(extract_dir)

                    # Copiar archivos extraídos sobre PROJECT_ROOT (sobrescribir)
                    for root, dirs, files in os.walk(extract_dir):
                        rel_root = os.path.relpath(root, extract_dir)
                        dest_root = os.path.join(PROJECT_ROOT, rel_root) if rel_root != "." else str(PROJECT_ROOT)
                        os.makedirs(dest_root, exist_ok=True)
                        for f in files:
                            src_file = os.path.join(root, f)
                            dest_file = os.path.join(dest_root, f)
                            try:
                                shutil.copy2(src_file, dest_file)
                            except Exception as e:
                                print("Error copiando archivo de update:", e)

                    # limpieza
                    try:
                        os.remove(tmp_zip)
                    except:
                        pass
                    try:
                        shutil.rmtree(extract_dir)
                    except:
                        pass

                    # Reiniciar la app (reemplazo del proceso)
                    # messagebox.showinfo("Actualización", "Actualización aplicada. La aplicación se reiniciará ahora.")
                    # Usamos subprocess pasándole una señal visual antes
                    # En Windows, para soltar el ejecutable bloqueado (si es .exe compilado y no Python script puro),
                    # Es algo delicado sobreeescribirse en caliente. Asumimos que update.zip reemplaza .py scripts.
                    # Si main.py es reemplazado antes, de ser un .exe esto falla. 
                    # Pero la lógica original ya lo hacía así y lo mantenemos.
                    python = sys.executable
                    os.execv(python, [python] + sys.argv)
                    
                except Exception as inner_e:
                    try: progress_top.destroy()
                    except: pass
                    messagebox.showerror("Actualización", f"Error al procesar la actualización: {inner_e}")
                
        except Exception as e:
            messagebox.showerror("Actualización", f"Error al iniciar la actualización: {e}")
            
        import threading
        # Lanzar la descarga en background para no congelar interfaz si tarda
        t = threading.Thread(target=update_task, daemon=True)
        t.start()

    # --- HELPER METODOS PARA TIMESTAMP DE SYNC ---
    def _update_sync_timestamp(self, db_name):
        try:
            with sqlite3.connect(LOCAL_DB_PATH) as conn:
                c = conn.cursor()
                c.execute("""
                CREATE TABLE IF NOT EXISTS config (
                    key TEXT PRIMARY KEY,
                    value TEXT
                )""")
                now = time.strftime("%Y-%m-%d %H:%M:%S")
                c.execute("INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)", (f"last_sync_{db_name}", now))
                conn.commit()
        except Exception as e:
            print(f"Error updating sync timestamp for {db_name}: {e}")

    def _get_sync_timestamps(self):
        timestamps = {}
        db_list = ["horas_extras.db", "gastos.db", "config.db", "service_ats.db", "valoraciones.db", "vacaciones.db"]
        for db in db_list:
            timestamps[db] = "Nunca"
        try:
            with sqlite3.connect(LOCAL_DB_PATH) as conn:
                c = conn.cursor()
                c.execute("SELECT key, value FROM config WHERE key LIKE 'last_sync_%'")
                for row in c.fetchall():
                    key = row[0].replace("last_sync_", "")
                    timestamps[key] = row[1]
        except Exception as e:
            print(f"Error reading sync timestamps: {e}")
        return timestamps

    # --- SINCRONIZACIÓN DE BASES DE DATOS ---
    def _sync_databases_from_drive(self):
        """
        Intenta descargar las bases desde GitHub hacia las rutas locales.
        """
        if not self.gdrive:
            return

        try:
            # Sincronizar (Pull) del repositorio remoto
            self.gdrive._pull()

            # Lista de pares remote_title -> local_path
            LOCAL_VALORACIONES_DB = os.path.join(PROJECT_ROOT, "tecnicos", "valoraciones.db")
            
            pairs = [
                ("horas_extras.db", LOCAL_HORAS_DB),
                ("gastos.db", LOCAL_GASTOS_DB),
                ("config.db", LOCAL_CONFIG_DB),
                ("service_ats.db", LOCAL_DB_PATH),
                ("valoraciones.db", LOCAL_VALORACIONES_DB),
                ("vacaciones.db", LOCAL_VACACIONES_DB)
            ]

            for remote_title, local_path in pairs:
                try:
                    res = self.gdrive.download_file(remote_title, local_path)
                    if isinstance(res, dict) and res.get("status") in ["downloaded", "skipped_identical", "skipped_local_newer"]:
                        self._update_sync_timestamp(remote_title)
                except Exception as e:
                    print("Error sincronizando", remote_title, e)
        except Exception as e:
            print("Error global en _sync_databases_from_drive:", e)

    def _sync_databases_to_drive(self):
        """
        Sube las bases locales a GitHub (Backup al cerrar).
        Genera también un backup JSON de usuarios.
        """
        if not self.gdrive or not self.gdrive.is_ready:
            return

        # Generar backup de usuarios automático
        try:
            # Usar conexión independiente para evitar error "closed database" si la principal ya cerró
            with sqlite3.connect(LOCAL_DB_PATH) as tmp_conn:
                tmp_c = tmp_conn.cursor()
                tmp_c.execute("SELECT username, password, is_admin, permissions FROM usuarios")
                users = []
                for u in tmp_c.fetchall():
                    users.append({
                        "username": u[0],
                        "password": u[1],
                        "is_admin": u[2],
                        "permissions": u[3]
                    })
            
            users_json_path = os.path.join(PROJECT_ROOT, "usuarios_backup.json")
            with open(users_json_path, "w", encoding="utf-8") as f:
                json.dump(users, f, ensure_ascii=False, indent=2)
                
        except Exception as e:
            print("Error generando usuarios_backup.json:", e)
            users_json_path = None

        # Definir rutas de bases de datos
        # LOCAL_GASTOS_DB ya definido globalmente
        # LOCAL_HORAS_DB ya definido globalmente
        
        LOCAL_VALORACIONES_DB = os.path.join(PROJECT_ROOT, "tecnicos", "valoraciones.db")

        pairs = [
            ("horas_extras.db", LOCAL_HORAS_DB),
            ("gastos.db", LOCAL_GASTOS_DB),
            ("config.db", LOCAL_CONFIG_DB),
            ("service_ats.db", LOCAL_DB_PATH),
            ("valoraciones.db", LOCAL_VALORACIONES_DB),
            ("vacaciones.db", LOCAL_VACACIONES_DB)
        ]
        
        if users_json_path and os.path.exists(users_json_path):
            pairs.append(("usuarios_backup.json", users_json_path))
        
        for remote_title, local_path in pairs:
            if os.path.exists(local_path):
                try:
                    res = self.gdrive.upload_file(local_path, remote_title)
                    if isinstance(res, dict) and res.get("status") in ["uploaded", "skipped"]:
                        self._update_sync_timestamp(remote_title)
                except Exception as e:
                    print(f"Error subiendo {remote_title}: {e}")
                    
        # Realizar commit y push de todos los archivos modificados
        self.gdrive.process_queue()

    def conectar_drive(self):
        """Forzar conexión manual con GitHub"""
        if not self.gdrive:
            messagebox.showerror("Error", "El módulo de Github no está inicializado.")
            return
        
        if not self.gdrive.is_ready:
            messagebox.showwarning("Sin conexión", "No hay conexión a Internet o token no configurado.")
            return

        try:
            if self.gdrive.is_ready:
                messagebox.showinfo("Éxito", "Conexión con GitHub establecida correctamente.")
            else:
                messagebox.showerror("Error", "No se pudo conectar con GitHub. Verifique su token.")
        except Exception as e:
            messagebox.showerror("Error", f"Ocurrió un error durante la conexión:\n{e}")

    # --- SIM MANAGER ---
    def abrir_sim_manager(self):
        if not self._check_permission("sims"): return
        self._show_module_view("Registro de Tarjetas SIM")
        try:
            SIMManager(self.main_content, conn=self.conn, current_user=self.current_user, log_manager=self.log_manager).show()
        except TypeError:
            SIMManager(self.main_content).show()

    # --- PLANOS ---
    # --- HERRAMIENTAS ---
    def abrir_herramientas(self):
        self._show_module_view("Herramientas")
        
        menu_frame = tk.Frame(self.main_content, bg="white")
        menu_frame.pack(expand=True, fill="both", padx=20, pady=20)
        
        tk.Label(menu_frame, text="Seleccione una Herramienta", font=("Segoe UI", 14, "bold"), bg="white").pack(pady=20)
        
        # Planos
        self.create_button(menu_frame, "Creación de Planos", "#1565c0", self.abrir_planos).pack(pady=10)
        
        # Calculadoras
        self.create_button(menu_frame, "Cálculo de Disco Duro", "#00838f", self.abrir_calculadora_hdd).pack(pady=10)
        self.create_button(menu_frame, "Cálculo de Consumo", "#ff6f00", self.abrir_calculadora_consumo).pack(pady=10)


    def abrir_planos(self):
        if not self._check_permission("planos"): return
        self._show_module_view("Creación de Planos")
        from planos_manager import iniciar_planos_manager
        iniciar_planos_manager(self.main_content, self.current_user, auto_wizard=True)


    def abrir_calculadora_hdd(self):
        self._show_module_view("Calculadora HDD")
        try:
            from proyectos.calculadoras import HDDCalculatorFrame
            HDDCalculatorFrame(self.main_content)
        except Exception as e:
             tk.Label(self.main_content, text=f"Error: {e}", bg="white", fg="red").pack()

    def abrir_calculadora_consumo(self):
        self._show_module_view("Calculadora Consumo")
        try:
            from proyectos.calculadoras import PowerCalculatorFrame
            PowerCalculatorFrame(self.main_content)
        except Exception as e:
             tk.Label(self.main_content, text=f"Error: {e}", bg="white", fg="red").pack()

    # --- PROYECTOS ---
    def abrir_proyectos(self):
        if not self._check_permission("proyectos"): return
        self._show_module_view("Proyectos")
        try:
            proyectos_main.ProyectosMain(self.main_content, self.conn, self.current_user)
        except TypeError:
            proyectos_main.ProyectosMain(self.main_content)

    # --- TÉCNICOS ---
    def abrir_tecnicos(self):
        if not self._check_permission("tecnicos"): return
        self._show_module_view("Técnicos")

        menu_frame = tk.Frame(self.main_content, bg="white")
        menu_frame.pack(side="left", fill="y", padx=(0, 10))

        content_frame = tk.Frame(self.main_content, bg="white")
        content_frame.pack(side="right", expand=True, fill="both")

        # Botones submenú
        btn_he = self.create_button(menu_frame, "Horas Extras", "#1976d2", lambda: self._load_horas_extras(content_frame))
        btn_he.pack(pady=6, padx=6)
        
        btn_gastos = self.create_button(menu_frame, "Gastos Mensuales", "#1976d2", lambda: self._load_gastos(content_frame))
        btn_gastos.pack(pady=6, padx=6)
        
        btn_kms = self.create_button(menu_frame, "Kilómetros", "#1976d2", lambda: self._load_kilometros(content_frame))
        btn_kms.pack(pady=6, padx=6)
        
        btn_manuales = self.create_button(menu_frame, "Manuales", "#1976d2", lambda: self._placeholder(content_frame, "Manuales"))
        btn_manuales.pack(pady=6, padx=6)

        btn_vac = self.create_button(menu_frame, "Vacaciones", "#1976d2", lambda: self._load_vacaciones(content_frame))
        btn_vac.pack(pady=6, padx=6)

        # Por defecto cargar Horas Extras
        self._load_horas_extras(content_frame)

    def _placeholder(self, parent, title):
        for w in parent.winfo_children():
            w.destroy()
        tk.Label(parent, text=title, font=("Segoe UI", 16, "bold"), bg="white").pack(pady=20)
        tk.Label(parent, text="Módulo en desarrollo", bg="white").pack(pady=8)

    def _load_horas_extras(self, parent):
        for w in parent.winfo_children(): w.destroy()
        try:
            # Pasar usuario actual para que HorasExtras registre quién guarda
            frame = HorasExtrasFrame(parent, current_user=self.current_user)
            frame.pack(expand=True, fill="both")
        except Exception as e:
            tk.Label(parent, text="Error:\n" + str(e), bg="white", fg="red").pack(pady=20)

    def _load_gastos(self, parent):
        for w in parent.winfo_children(): w.destroy()
        try:
            from proyectos.tecnicos.gastos import GastosFrame
            frame = GastosFrame(parent, current_user=self.current_user)
            frame.pack(expand=True, fill="both")
        except Exception as e:
            tk.Label(parent, text="Error cargando Gastos:\n" + str(e), bg="white", fg="red").pack(pady=20)

    def _load_kilometros(self, parent):
        for w in parent.winfo_children(): w.destroy()
        try:
            from proyectos.tecnicos.kilometros import KilometrosFrame
            frame = KilometrosFrame(parent, current_user=self.current_user)
            frame.pack(expand=True, fill="both")
        except Exception as e:
            tk.Label(parent, text="Error cargando Kilómetros:\n" + str(e), bg="white", fg="red").pack(pady=20)

    def _load_vacaciones(self, parent):
        for w in parent.winfo_children(): w.destroy()
        try:
            from proyectos.tecnicos.vacaciones import VacacionesFrame
            frame = VacacionesFrame(parent, current_user=self.current_user, log_manager=self.log_manager, drive_sync=self.gdrive)
            frame.pack(expand=True, fill="both")
        except Exception as e:
            tk.Label(parent, text="Error cargando Vacaciones:\n" + str(e), bg="white", fg="red").pack(pady=20)

    # --- CONFIGURACIÓN ---
    def abrir_configuracion(self):
        # Permitir acceso a TODOS (ya no hay check de admin aquí)
        self._show_module_view("Configuración")
        
        config_frame = self.main_content
        
        # Tabs para separar "Mi Cuenta" de "Administración"
        # Si TTK disponible usamos Notebook, sino botones simples
        if TTK_AVAILABLE:
            notebook = ttk.Notebook(config_frame)
            notebook.pack(expand=True, fill="both", padx=10, pady=10)
            
            # Tab 1: Mi Cuenta
            tab_cuenta = tk.Frame(notebook, bg="white")
            notebook.add(tab_cuenta, text="Mi Cuenta")
            
            tk.Label(tab_cuenta, text=f"Usuario: {self.current_user['username']}", 
                     font=("Segoe UI", 12, "bold"), bg="white").pack(pady=20)
            
            tk.Button(tab_cuenta, text="🔑 Cambiar mi Contraseña", font=("Segoe UI", 11),
                      bg="#f0f0f0", command=self.cambiar_contrasena).pack(pady=10)

            # Selector de Tema (Personal)
            tk.Label(tab_cuenta, text="Tema de Interfaz:", font=("Segoe UI", 10, "bold"), bg="white").pack(pady=(20, 5))
            temas = sorted(ttk.Style().theme_names())
            # Default to flatly if not set
            curr_theme = self.current_user.get("theme", "flatly")
            tema_var = tk.StringVar(value=curr_theme)
            tema_combo = ttk.Combobox(tab_cuenta, textvariable=tema_var, values=temas, state="readonly", width=25)
            tema_combo.pack(pady=5)
            
            def cambiar_tema_personal(event=None):
                nuevo = tema_var.get()
                try:
                    self.app_style.theme_use(nuevo)
                    # Guardar en DB Usuario
                    self.cursor.execute("UPDATE usuarios SET theme=? WHERE id=?", (nuevo, self.current_user["id"]))
                    self.conn.commit()
                    self.current_user["theme"] = nuevo
                except Exception as e:
                    messagebox.showerror("Error", f"No se pudo cambiar el tema: {e}")
                    
            tema_combo.bind("<<ComboboxSelected>>", cambiar_tema_personal)
            
            # Tab 2: Gestión Avanzada (Materiales, etc) -> Visible si Admin o permiso add_articles
            if self._check_permission("add_articles") or self.current_user["is_admin"] == 1:
                tab_gestion = tk.Frame(notebook, bg="white")
                notebook.add(tab_gestion, text="Gestión")
                
                tk.Label(tab_gestion, text="Herramientas de Gestión", font=("Segoe UI", 12, "bold"), bg="white").pack(pady=20)
                
                tk.Button(tab_gestion, text="Gestión Materiales / Precios", width=25, bg="#fff9c4", font=("Segoe UI", 10),
                          command=self.abrir_gestion_materiales).pack(pady=10)

            # Tab 3: Administración (Solo Admin)
            if self.current_user["is_admin"] == 1:
                tab_admin = tk.Frame(notebook, bg="white")
                notebook.add(tab_admin, text="Administración")
                self._build_admin_panel(tab_admin)
            else:
                # Si no es admin, solo ve Mi Cuenta (y Gestión si tiene permiso)
                pass

        else:
            # Fallback sin tabs (poco probable hoy día con ttkbootstrap/tkinter mod)
            tk.Label(config_frame, text=f"Usuario: {self.current_user['username']}", bg="white").pack()
            tk.Button(config_frame, text="Cambiar Contraseña", command=self.cambiar_contrasena).pack(pady=5)
            
            if self.current_user["is_admin"] == 1:
                tk.Label(config_frame, text="--- Administración ---", font=("Segoe UI", 12, "bold"), bg="white").pack(pady=10)
                admin_frame = tk.Frame(config_frame, bg="white")
                admin_frame.pack(fill="both", expand=True)
                self._build_admin_panel(admin_frame)
            
            # Fallback "Gestión" section
            if self._check_permission("add_articles") or self.current_user["is_admin"] == 1:
                tk.Label(config_frame, text="--- Gestión ---", font=("Segoe UI", 12, "bold"), bg="white").pack(pady=10)
                tk.Button(config_frame, text="Gestión Materiales / Precios", width=25, bg="#fff9c4", font=("Segoe UI", 10),
                          command=self.abrir_gestion_materiales).pack(pady=10)

    def _build_admin_panel(self, parent):
        """Construye el panel de administración dentro de la pestaña correspondiente"""
        opciones_frame = tk.Frame(parent, bg="white")
        opciones_frame.pack(pady=10)

        tk.Button(opciones_frame, text="Usuarios", width=20,
                  command=lambda: self.usuarios_panel(parent)).grid(row=0, column=0, padx=10, pady=10)

        tk.Button(opciones_frame, text="Ver Log de Movimientos", width=20, bg="#e0f7fa",
                  command=self.open_audit_log_viewer).grid(row=0, column=2, padx=10, pady=10)

        tk.Button(opciones_frame, text="Buscar Actualizaciones", width=20,
                  command=lambda: self.check_for_updates(manual=True)).grid(row=0, column=1, padx=10, pady=10)
        
        tk.Button(opciones_frame, text="Conectar Google Drive", width=20,
                  command=self.conectar_drive).grid(row=1, column=0, columnspan=2, pady=20)
                  
        # Separador visual
        try:
            ttk.Separator(parent, orient="horizontal").pack(fill="x", pady=20)
        except:
            tk.Frame(parent, height=2, bg="#ccc").pack(fill="x", pady=20)

        # Sección Copia de Seguridad
        backup_frame = tk.LabelFrame(parent, text="Copia de Seguridad y Github", bg="white", font=("Segoe UI", 12, "bold"))
        backup_frame.pack(fill="x", pady=10)
        
        tk.Label(backup_frame, text="Estado: " + ("Conectado" if self.gdrive and self.gdrive.is_ready else "Desconectado"), 
                 bg="white", fg=("green" if self.gdrive and self.gdrive.is_ready else "red")).pack(pady=5)

        tk.Button(backup_frame, text="Realizar Backup Completo Ahora", 
                  command=lambda: self._manual_backup(parent),
                  bg="#2e7d32", fg="white", font=("Segoe UI", 10, "bold")).pack(pady=10)

        # Sección Información de Sistema y Sincronización
        sys_info_frame = tk.LabelFrame(parent, text="Información de Sistema y Sincronización", bg="white", font=("Segoe UI", 12, "bold"))
        sys_info_frame.pack(fill="x", pady=10, padx=10)
        
        tk.Label(sys_info_frame, text=f"Versión del software: {VERSION}", font=("Segoe UI", 11, "bold"), bg="white", fg="#004080").pack(anchor="w", padx=10, pady=5)
        
        db_frame = tk.Frame(sys_info_frame, bg="white")
        db_frame.pack(fill="x", padx=10, pady=5)
        
        tk.Label(db_frame, text="Base de Datos", font=("Segoe UI", 10, "bold"), bg="white", width=30, anchor="w").grid(row=0, column=0, padx=5, pady=2)
        tk.Label(db_frame, text="Última Sincronización", font=("Segoe UI", 10, "bold"), bg="white", width=30, anchor="w").grid(row=0, column=1, padx=5, pady=2)
        
        timestamps = self._get_sync_timestamps()
        
        friendly_names = {
            "horas_extras.db": "Horas Extras",
            "gastos.db": "Gastos Mensuales",
            "config.db": "Configuración del Sistema",
            "service_ats.db": "Base de Datos Principal",
            "valoraciones.db": "Valoraciones y Precios",
            "vacaciones.db": "Vacaciones del Personal"
        }
        
        for idx, (db, name) in enumerate(friendly_names.items(), start=1):
            ts = timestamps.get(db, "Nunca")
            color = "#2e7d32" if ts != "Nunca" else "#c62828"
            tk.Label(db_frame, text=name, bg="white", width=30, anchor="w").grid(row=idx, column=0, padx=5, pady=2)
            tk.Label(db_frame, text=ts, bg="white", fg=color, width=30, anchor="w", font=("Segoe UI", 9, "bold") if ts != "Nunca" else ("Segoe UI", 9)).grid(row=idx, column=1, padx=5, pady=2)

    def _manual_backup(self, parent=None):
        """Ejecuta backup manual con feedback visual"""
        if not self.gdrive:
            messagebox.showerror("Error", "Google Drive no está configurado.")
            return
            
        if not messagebox.askyesno("Confirmar", "¿Desea subir una copia de seguridad de todas las bases de datos ahora?"):
            return
            
        # Ventana de progreso
        top = tk.Toplevel(self)
        top.title("Realizando Backup")
        try:
            top.geometry("300x120")
            # Centrar
            x = self.winfo_x() + (self.winfo_width() // 2) - 150
            y = self.winfo_y() + (self.winfo_height() // 2) - 60
            top.geometry(f"+{x}+{y}")
        except: pass
        
        tk.Label(top, text="Subiendo bases de datos...", font=("Segoe UI", 11, "bold")).pack(pady=10)
        lbl_detail = tk.Label(top, text="Iniciando...", font=("Segoe UI", 9))
        lbl_detail.pack(pady=5)
        top.update()
        
        # Bloquear interacción
        top.grab_set()
        
        try:
            self._sync_databases_to_drive()
            lbl_detail.config(text="¡Completado!")
            top.update()
            time.sleep(1)
            top.destroy()
            if parent:
                self._reload_admin_panel(parent)
            messagebox.showinfo("Backup", "Copia de seguridad completada exitosamente.")
        except Exception as e:
            top.destroy()
            messagebox.showerror("Error", f"Fallo en el backup: {e}")

    def abrir_gestion_materiales(self):
        # Permiso: Admin o 'add_articles'
        if not self._check_permission("add_articles"): return
        
        try:
            from proyectos.valoraciones import ConfiguracionProyectos
            ConfiguracionProyectos(self)
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo abrir la gestión de materiales:\n{e}")
    
    def usuarios_panel(self, parent):
        # Limpiar completamente el frame padre (tab_admin)
        for widget in parent.winfo_children():
            widget.destroy()

        # Botón Volver al menú admin
        tk.Button(parent, text="⬅ Volver a Administración", font=("Segoe UI", 9),
                 bg="#e0e0e0", command=lambda: self._reload_admin_panel(parent)).pack(anchor="w", padx=10, pady=5)

        tk.Label(parent, text="Gestión de Usuarios", font=("Segoe UI", 16, "bold"), bg="white").pack(pady=10)
        
        # Lista de usuarios
        list_frame = tk.Frame(parent, bg="white")
        list_frame.pack(fill="both", expand=True, padx=20, pady=10)
        
        # Headers
        h_frame = tk.Frame(list_frame, bg="#f5f5f5")
        h_frame.pack(fill="x")
        tk.Label(h_frame, text="Usuario", width=20, anchor="w", bg="#f5f5f5", font=("Segoe UI", 9, "bold")).pack(side="left", padx=5)
        tk.Label(h_frame, text="Perfil", width=10, anchor="w", bg="#f5f5f5", font=("Segoe UI", 9, "bold")).pack(side="left")
        tk.Label(h_frame, text="Permisos", width=30, anchor="w", bg="#f5f5f5", font=("Segoe UI", 9, "bold")).pack(side="left")
        
        self.cursor.execute("SELECT id, username, is_admin, permissions FROM usuarios")
        users = self.cursor.fetchall()

        for u in users:
            uid, uname, is_admin, perms_json = u
            perms = json.loads(perms_json) if perms_json else []
            
            row = tk.Frame(list_frame, pady=2, bg="white")
            row.pack(fill="x", padx=5)
            
            tk.Label(row, text=uname, width=20, anchor="w", bg="white").pack(side="left", padx=5)
            tk.Label(row, text="Admin" if is_admin else "Usuario", width=10, anchor="w", bg="white").pack(side="left")
            
            # Formatear permisos para mostrar
            perm_str = "Todos" if is_admin or "all" in perms else ", ".join(perms)
            tk.Label(row, text=perm_str, width=30, anchor="w", fg="#555", bg="white").pack(side="left")
            
            # Acciones
            tk.Button(row, text="Editar", font=("Segoe UI", 8),
                     command=lambda i=uid: self._open_user_editor(parent, i)).pack(side="left", padx=2)
            
            if uname.lower() != "admin": # No borrar al admin principal
                tk.Button(row, text="❌", font=("Segoe UI", 8), fg="red",
                         command=lambda i=uid, n=uname: self._delete_user(parent, i, n)).pack(side="left", padx=2)

        tk.Button(parent, text="➕ Nuevo Usuario", bg="#2e7d32", fg="white", font=("Segoe UI", 10, "bold"),
                 command=lambda: self._open_user_editor(parent)).pack(pady=10)

    def _delete_user(self, parent, user_id, username):
        if messagebox.askyesno("Eliminar", f"¿Seguro que deseas eliminar al usuario '{username}'?"):
            self.cursor.execute("DELETE FROM usuarios WHERE id=?", (user_id,))
            self.conn.commit()
            self.usuarios_panel(parent)
            
    def _reload_admin_panel(self, parent):
        for w in parent.winfo_children(): w.destroy()
        self._build_admin_panel(parent)

    def _open_user_editor(self, parent_panel, user_id=None):
        title = "Editar Usuario" if user_id else "Nuevo Usuario"
        
        top = tk.Toplevel(self)
        top.title(title)
        top.geometry("400x500")
        
        # Centrar
        x = self.winfo_x() + (self.winfo_width()//2) - 200
        y = self.winfo_y() + (self.winfo_height()//2) - 250
        top.geometry(f"+{x}+{y}")
        top.transient(self)
        top.grab_set()
        
        # Datos iniciales
        curr_user = ""
        curr_admin = False
        curr_perms = []
        
        if user_id:
            self.cursor.execute("SELECT username, is_admin, permissions FROM usuarios WHERE id=?", (user_id,))
            row = self.cursor.fetchone()
            if row:
                curr_user = row[0]
                curr_admin = bool(row[1])
                curr_perms = json.loads(row[2]) if row[2] else []
        
        # UI
        tk.Label(top, text="Nombre de Usuario:", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=20, pady=(20,5))
        e_user = tk.Entry(top, font=("Segoe UI", 10))
        e_user.pack(fill="x", padx=20)
        e_user.insert(0, curr_user)
        
        tk.Label(top, text="Contraseña:", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=20, pady=(15,5))
        if user_id:
            tk.Label(top, text="(Dejar en blanco para no cambiar)", font=("Segoe UI", 8, "italic"), fg="gray").pack(anchor="w", padx=20)
        e_pass = tk.Entry(top, show="*", font=("Segoe UI", 10))
        e_pass.pack(fill="x", padx=20)
        
        # Admin switch
        var_admin = tk.BooleanVar(value=curr_admin)
        chk_admin = tk.Checkbutton(top, text="Es Administrador (Acceso total)", variable=var_admin, font=("Segoe UI", 10, "bold"))
        chk_admin.pack(anchor="w", padx=20, pady=15)
        
        # Permisos frame
        perm_frame = tk.LabelFrame(top, text="Permisos de Módulos", font=("Segoe UI", 10))
        perm_frame.pack(fill="x", padx=20, pady=10)
        
        perms_map = {
            "proyectos": "Gestión de Proyectos",
            "tecnicos": "Área Técnica (Horas/Gastos)",
            "sims": "Gestor de SIMs",
            "planos": "Creación de Planos",
            "add_articles": "Añadir Artículos a BD"
        }
        
        vars_perms = {}
        for key, label in perms_map.items():
            var = tk.BooleanVar(value=(key in curr_perms))
            vars_perms[key] = var
            tk.Checkbutton(perm_frame, text=label, variable=var).pack(anchor="w", padx=10, pady=2)
            
        def save():
            uname = e_user.get().strip()
            upass = e_pass.get().strip()
            
            if not uname:
                messagebox.showerror("Error", "El nombre de usuario es obligatorio.", parent=top)
                return
            
            # Recopilar permisos
            final_perms = []
            if var_admin.get():
                final_perms = ["all"]
            else:
                for k, v in vars_perms.items():
                    if v.get(): final_perms.append(k)
            
            perms_json = json.dumps(final_perms)
            is_adm = 1 if var_admin.get() else 0
            
            try:
                if user_id:
                    # Update
                    if upass:
                        self.cursor.execute("UPDATE usuarios SET username=?, password=?, is_admin=?, permissions=? WHERE id=?",
                                          (uname, upass, is_adm, perms_json, user_id))
                    else:
                        self.cursor.execute("UPDATE usuarios SET username=?, is_admin=?, permissions=? WHERE id=?",
                                          (uname, is_adm, perms_json, user_id))
                else:
                    # Insert
                    if not upass:
                        messagebox.showerror("Error", "La contraseña es obligatoria para nuevos usuarios.", parent=top)
                        return
                    self.cursor.execute("INSERT INTO usuarios (username, password, is_admin, permissions) VALUES (?,?,?,?)",
                                      (uname, upass, is_adm, perms_json))
                
                self.conn.commit()
                top.destroy()
                self.usuarios_panel(parent_panel)
                messagebox.showinfo("Guardado", "Usuario guardado correctamente.")
                
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "El nombre de usuario ya existe.", parent=top)
            except Exception as ex:
                messagebox.showerror("Error", f"Error guardando: {ex}", parent=top)

        tk.Button(top, text="💾 Guardar Usuario", bg="#1976d2", fg="white", font=("Segoe UI", 11, "bold"),
                 command=save).pack(pady=20, fill="x", padx=20)

    def _check_permission(self, module_key):
        """Verifica si el usuario actual tiene permiso para el módulo"""
        if not self.current_user: return False
        if self.current_user.get("is_admin", 0) == 1: return True
        
        # Obtener permisos frescos de la BD (por si cambiaron en la sesión)
        try:
            self.cursor.execute("SELECT permissions FROM usuarios WHERE id=?", (self.current_user["id"],))
            row = self.cursor.fetchone()
            if row and row[0]:
                perms = json.loads(row[0])
                if "all" in perms or module_key in perms:
                    return True
        except Exception as e:
            print("Error checking permissions:", e)
            
        messagebox.showerror("Acceso Denegado", "No tienes permisos para acceder a este módulo.")
        return False

    def cambiar_contrasena(self):
        """Diálogo para cambiar contraseña propia"""
        if not self.current_user: return
        
        top = tk.Toplevel(self)
        top.title("Cambiar Contraseña")
        top.geometry("350x300")
        
        # Centrar
        x = self.winfo_x() + (self.winfo_width()//2) - 175
        y = self.winfo_y() + (self.winfo_height()//2) - 150
        top.geometry(f"+{x}+{y}")
        top.transient(self)
        top.grab_set()
        
        tk.Label(top, text="Contraseña Actual:", font=("Segoe UI", 10)).pack(anchor="w", padx=20, pady=(20,5))
        e_old = tk.Entry(top, show="*", font=("Segoe UI", 10))
        e_old.pack(fill="x", padx=20)
        
        tk.Label(top, text="Nueva Contraseña:", font=("Segoe UI", 10)).pack(anchor="w", padx=20, pady=(15,5))
        e_new = tk.Entry(top, show="*", font=("Segoe UI", 10))
        e_new.pack(fill="x", padx=20)
        
        tk.Label(top, text="Confirmar Nueva:", font=("Segoe UI", 10)).pack(anchor="w", padx=20, pady=(15,5))
        e_confirm = tk.Entry(top, show="*", font=("Segoe UI", 10))
        e_confirm.pack(fill="x", padx=20)
        
        def save_pass():
            old = e_old.get()
            new = e_new.get()
            conf = e_confirm.get()
            
            if not old or not new:
                messagebox.showerror("Error", "Todos los campos son obligatorios.", parent=top)
                return
            
            if new != conf:
                messagebox.showerror("Error", "La nueva contraseña no coincide.", parent=top)
                return
                
            # Verificar old pass
            uid = self.current_user["id"]
            self.cursor.execute("SELECT password FROM usuarios WHERE id=?", (uid,))
            row = self.cursor.fetchone()
            if not row or row[0] != old:
                messagebox.showerror("Error", "La contraseña actual es incorrecta.", parent=top)
                return
            
            # Update
            self.cursor.execute("UPDATE usuarios SET password=? WHERE id=?", (new, uid))
            self.conn.commit()
            messagebox.showinfo("Éxito", "Contraseña actualizada correctamente.", parent=top)
            top.destroy()
            
        tk.Button(top, text="Actualizar Contraseña", bg="#388e3c", fg="white", font=("Segoe UI", 10, "bold"),
                 command=save_pass).pack(pady=20, fill="x", padx=20)

    # --- BACKUP (Legacy / Removed Granular) ---
    # Se eliminó backup_panel por peticion del usuario, se mantiene solo el de Drive en Admin Panel base.


    def export_usuarios(self):
        file = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json")])
        if not file:
            return
        self.cursor.execute("SELECT username, password, is_admin FROM usuarios")
        users = [{"username": u[0], "password": u[1], "is_admin": u[2]} for u in self.cursor.fetchall()]
        with open(file, "w", encoding="utf-8") as f:
            json.dump(users, f, ensure_ascii=False, indent=2)
        messagebox.showinfo("Exportación", "Usuarios exportados correctamente")

    def import_usuarios(self):
        file = filedialog.askopenfilename(filetypes=[("JSON files", "*.json")])
        if not file:
            return
        with open(file, "r", encoding="utf-8") as f:
            users = json.load(f)
        for u in users:
            try:
                self.cursor.execute(
                    "INSERT OR REPLACE INTO usuarios (username, password, is_admin) VALUES (?,?,?)",
                    (u["username"], u["password"], u["is_admin"])
                )
            except Exception:
                continue
        self.conn.commit()
        messagebox.showinfo("Importación", "Usuarios importados correctamente")

    # --- LIMPIAR FRAMES ---
    def clear_frames(self):
        for frame in [self.splash_frame, self.login_frame, self.main_frame]:
            if frame:
                try:
                    frame.destroy()
                except Exception:
                    pass

    # --- AUDIT LOG VIEWER ---
    def open_audit_log_viewer(self):
        if not self.log_manager:
            messagebox.showerror("Error", "El gestor de logs no está disponible.")
            return
        
        top = tk.Toplevel(self)
        top.title("Log de Movimientos (Admin)")
        try:
            top.state("zoomed")
        except:
            top.geometry("1000x600")
        
        # Toolbar
        tb = tk.Frame(top, bg="#f0f0f0", height=40)
        tb.pack(fill="x")
        
        tk.Button(tb, text="🔄 Actualizar", command=lambda: load_logs()).pack(side="left", padx=10, pady=5)
        tk.Label(tb, text="Últimos 500 movimientos del sistema", bg="#f0f0f0", fg="gray").pack(side="left", padx=10)
        
        # Contenedor para Treeview
        container = tk.Frame(top)
        container.pack(fill="both", expand=True, padx=10, pady=10)
        
        cols = ("timestamp", "usuario", "accion", "detalles")
        tree = ttk.Treeview(container, columns=cols, show="headings")
        
        tree.heading("timestamp", text="Fecha/Hora")
        tree.column("timestamp", width=150, anchor="center")
        tree.heading("usuario", text="Usuario")
        tree.column("usuario", width=100)
        tree.heading("accion", text="Acción")
        tree.column("accion", width=150)
        tree.heading("detalles", text="Detalles")
        tree.column("detalles", width=500)
        
        tree.pack(side="left", fill="both", expand=True)
        
        sb = ttk.Scrollbar(container, orient="vertical", command=tree.yview)
        sb.pack(side="right", fill="y")
        tree.configure(yscrollcommand=sb.set)
        
        def load_logs():
            for i in tree.get_children(): tree.delete(i)
            # get_logs returns (timestamp, usuario, accion, detalles)
            logs = self.log_manager.get_logs(limit=500)
            for row in logs:
                tree.insert("", "end", values=row)
                
        load_logs()


# --- EJECUTAR ---
if __name__ == "__main__":
    import sys
    app = ServiceATSApp()
    app.mainloop()
