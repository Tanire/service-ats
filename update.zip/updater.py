import requests
import os
import sys
import subprocess

# URLs públicas de tu repositorio GitHub
GITHUB_VERSION_URL = "https://raw.githubusercontent.com/Tanire/service-ats/main/version.txt"
GITHUB_INSTALLER_URL = "https://github.com/Tanire/service-ats/releases/latest/download/ServiceATS_Installer.exe"
LOCAL_VERSION_FILE = "version.txt"

def normalize_version(version_str):
    """Normaliza una versión eliminando caracteres especiales y espacios"""
    if not version_str:
        return ""
    return version_str.replace("\ufeff", "").replace("\n", "").replace("\r", "").strip().lower()

def get_local_version():
    try:
        with open(LOCAL_VERSION_FILE, "r", encoding="utf-8") as f:
            version = f.read().strip()
            return normalize_version(version)
    except FileNotFoundError:
        return "v0.0"

def get_remote_version():
    try:
        response = requests.get(GITHUB_VERSION_URL, timeout=5)
        if response.status_code == 200:
            version = response.text.strip()
            return normalize_version(version)
    except Exception as e:
        print(f"⚠️ Error al obtener versión remota: {e}")
    return None

def check_for_update():
    local_version = get_local_version()
    remote_version = get_remote_version()
    
    if not remote_version:
        print("⚠️ No se pudo comprobar la versión online.")
        return False
    
    # Debug: mostrar las versiones comparadas
    print(f"Versión local: '{local_version}' (len: {len(local_version)})")
    print(f"Versión GitHub: '{remote_version}' (len: {len(remote_version)})")
    print(f"Son diferentes: {remote_version != local_version}")
    
    return remote_version != local_version

def download_and_update():
    print("⬇️ Descargando nueva versión...")
    try:
        response = requests.get(GITHUB_INSTALLER_URL, stream=True)
        response.raise_for_status()
        
        installer_path = "ServiceATS_Update.exe"
        with open(installer_path, "wb") as f:
            for chunk in response.iter_content(1024):
                if chunk:
                    f.write(chunk)
        
        print("✅ Descarga completa. Iniciando actualización...")
        subprocess.Popen([installer_path])
        sys.exit()
    except Exception as e:
        print(f"❌ Error al descargar actualización: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if check_for_update():
        download_and_update()
    else:
        print("✅ Service ATS está actualizado.")