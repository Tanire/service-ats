@echo off
echo ==================================================
echo   REPARACION Y COMPILACION DE SERVICE ATS - v2
echo ==================================================
echo.

set PYTHON_EXE=.\.venv\Scripts\python.exe

if not exist "%PYTHON_EXE%" (
    echo [ERROR] No se encuentra el entorno virtual en .\.venv
    echo Buscando en carpeta venv...
    set PYTHON_EXE=.\venv\Scripts\python.exe
)

if not exist "%PYTHON_EXE%" (
    echo [CRITICAL] No se encuentra python.exe en .venv ni en venv.
    echo Por favor, reinstala el entorno.
    pause
    exit /b 1
)

echo Usando Python en: %PYTHON_EXE%

echo.
echo 1. Deteniendo procesos Python...
taskkill /F /IM python.exe /T 2>NUL

echo.
echo 2. Reparando libreria Pillow (Downgrade a v10 para compatibilidad)...
"%PYTHON_EXE%" -m pip uninstall -y pillow
"%PYTHON_EXE%" -m pip install "pillow<11.0.0"

echo.
echo 3. Instalando PyInstaller y PyMuPDF...
"%PYTHON_EXE%" -m pip install pyinstaller pymupdf

echo.
echo 4. Compilando aplicacion...
"%PYTHON_EXE%" -m PyInstaller ServiceATS.spec --clean --noconfirm

echo.
if %errorlevel% neq 0 (
    echo [ERROR] La compilacion fallo.
    pause
    exit /b %errorlevel%
)

echo.
echo ==================================================
echo   COMPILACION EXITOSA
echo ==================================================
echo El ejecutable esta en: dist\ServiceATS.exe
echo.
pause
