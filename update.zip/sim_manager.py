# sim_manager.py
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
import os
import openpyxl
from tkinter import filedialog

from pathlib import Path

# Calcular ruta absoluta del proyecto (asumiendo sim_manager.py en la raíz)
PROJECT_ROOT = Path(__file__).resolve().parent
DB_FILE = str(PROJECT_ROOT / "service_ats.db")

class SIMManager:
    """
    SIMManager dibuja su interfaz dentro del `parent` que se le pase.
    Constructor: SIMManager(parent, conn, current_user)
      - parent: frame o Toplevel donde se colocará la UI
      - conn: sqlite3.Connection (opcional). Si no se pasa se abre DB por defecto.
      - current_user: dict con info del usuario actual (ej: {'id':1,'username':'admin','is_admin':1})
    """
    def __init__(self, parent, conn=None, current_user=None, log_manager=None):
        self.parent = parent
        self.conn = conn or sqlite3.connect(DB_FILE)
        self.cursor = self.conn.cursor()
        self.current_user = current_user or {"is_admin": 0, "username": "guest"}
        self.log_manager = log_manager
        self.frame = None
        self.selected_id = None
        self._ensure_table()

    def _ensure_table(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS sim (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                abonado TEXT,
                cliente TEXT,
                sistema TEXT,
                compania TEXT,
                numero_tarjeta TEXT,
                numero_telefono TEXT,
                notas TEXT
            )
        """)
        self.conn.commit()

    def show(self):
        """Dibuja la UI dentro de self.parent"""
        self.clear_frame()
        # Si parent es un Toplevel o Frame, usamos pack sobre él
        self.frame = tk.Frame(self.parent, bg="white")
        self.frame.pack(expand=True, fill="both")

        tk.Label(self.frame, text="Registro de Tarjetas SIM", font=("Segoe UI", 18, "bold"), bg="white").pack(pady=8)

        # --- Formulario ---
        form = tk.Frame(self.frame, bg="white")
        form.pack(padx=12, pady=8, fill="x")

        self.fields = ["abonado","cliente","sistema","compania","numero_tarjeta","numero_telefono","notas"]
        self.entries = {}
        for i, field in enumerate(self.fields):
            lbl = tk.Label(form, text=field.replace("_"," ").title()+":", width=16, anchor="e", bg="white")
            lbl.grid(row=i, column=0, padx=6, pady=4, sticky="e")
            ent = tk.Entry(form, width=40)
            ent.grid(row=i, column=1, padx=6, pady=4, sticky="w")
            self.entries[field] = ent

        # Botón Guardar (añade o actualiza)
        save_btn = tk.Button(form, text="Guardar", bg="#1976d2", fg="white", width=12,
                             command=self.add_or_update_sim)
        save_btn.grid(row=0, column=2, rowspan=2, padx=10)

        # --- Buscador ---
        search_frame = tk.Frame(self.frame, bg="white")
        search_frame.pack(fill="x", padx=12, pady=6)

        tk.Label(search_frame, text="Buscar (texto libre):", bg="white").pack(side="left")
        self.search_entry = tk.Entry(search_frame, width=40)
        self.search_entry.pack(side="left", padx=6)
        tk.Button(search_frame, text="Buscar", command=self.search).pack(side="left", padx=6)
        tk.Button(search_frame, text="Limpiar", command=self.refresh_list).pack(side="left", padx=6)

        # --- Treeview (listado) ---
        cols = self.fields  # orden de columnas
        self.tree = ttk.Treeview(self.frame, columns=cols, show="headings", selectmode="browse")
        for c in cols:
            self.tree.heading(c, text=c.replace("_"," ").title())
            # small width for mobile, wider for desktop
            self.tree.column(c, width=140, anchor="w")
        self.tree.pack(expand=True, fill="both", padx=12, pady=8)
        self.tree.bind("<Double-1>", self._on_double_click)

        # Configurar filas alternas (Grid effect)
        self.tree.tag_configure('evenrow', background='white')
        self.tree.tag_configure('oddrow', background='#f0f0f0')

        # Botones acción
        ctrl_frame = tk.Frame(self.frame, bg="white")
        ctrl_frame.pack(pady=6)
        tk.Button(ctrl_frame, text="Eliminar", bg="#d32f2f", fg="white", width=12,
                  command=self.delete_sim).pack(side="left", padx=6)
        tk.Button(ctrl_frame, text="Modificar (cargar)", width=14,
                  command=self.load_selected).pack(side="left", padx=6)
        tk.Button(ctrl_frame, text="Limpiar formulario", width=14,
                  command=self.clear_form).pack(side="left", padx=6)
        
        # Excel
        tk.Button(ctrl_frame, text="Exportar Excel", bg="#2e7d32", fg="white", width=12,
                  command=self.export_excel).pack(side="left", padx=6)
        tk.Button(ctrl_frame, text="Importar Excel", bg="#0277bd", fg="white", width=12,
                  command=self.import_excel).pack(side="left", padx=6)
        
        # Solo mostrar Cerrar si es ventana independiente
        if isinstance(self.parent, tk.Toplevel):
            tk.Button(ctrl_frame, text="Cerrar", width=12, command=self._close_parent).pack(side="left", padx=6)

        # Cargar listado
        self.refresh_list()

    def clear_frame(self):
        if self.frame:
            self.frame.destroy()
            self.frame = None

    def add_or_update_sim(self):
        # Leer valores y validar no vacíos
        data = {f: self.entries[f].get().strip() for f in self.fields}
        for k,v in data.items():
            if k != "notas" and v == "":
                messagebox.showerror("Error", f"El campo '{k.replace('_',' ').title()}' no puede estar vacío")
                return

        if self.selected_id is not None:
            # actualizar
            self.cursor.execute("""
                UPDATE sim SET abonado=?, cliente=?, sistema=?, compania=?, numero_tarjeta=?, numero_telefono=?, notas=?
                WHERE id=?
            """, (*[data[f] for f in self.fields], int(self.selected_id)))
            self.conn.commit()
            messagebox.showinfo("Actualizado", "Registro actualizado correctamente")
            if self.log_manager:
                self.log_manager.log(self.current_user.get("username", "Unknown"), "SIM_UPDATE", f"Tarjeta: {data.get('numero_tarjeta')}")
            self.selected_id = None
        else:
            # insertar
            self.cursor.execute("""
                INSERT INTO sim (abonado, cliente, sistema, compania, numero_tarjeta, numero_telefono, notas)
                VALUES (?,?,?,?,?,?,?)
            """, tuple(data[f] for f in self.fields))
            self.conn.commit()
            messagebox.showinfo("Añadido", "Registro añadido correctamente")
            if self.log_manager:
                self.log_manager.log(self.current_user.get("username", "Unknown"), "SIM_ADD", f"Tarjeta: {data.get('numero_tarjeta')}")

        self.refresh_list()
        self.clear_form()

    def refresh_list(self):
        # limpia tree y carga todas las filas
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        self.cursor.execute("SELECT * FROM sim ORDER BY id DESC")
        for i, row in enumerate(self.cursor.fetchall()):
            # row[0] = id, row[1:] = campos
            tag = 'evenrow' if i % 2 == 0 else 'oddrow'
            self.tree.insert("", tk.END, iid=str(row[0]), values=row[1:], tags=(tag,))

    def _on_double_click(self, event):
        # cargar en formulario para editar
        self.load_selected()

    def load_selected(self, event=None):
        sel = self.tree.selection()
        if not sel:
            messagebox.showerror("Error", "Seleccione un registro primero")
            return
        iid = sel[0]
        values = self.tree.item(iid, "values")
        # rellenar entradas
        for i, f in enumerate(self.fields):
            self.entries[f].delete(0, tk.END)
            self.entries[f].insert(0, values[i])
        self.selected_id = int(iid)

    def delete_sim(self):
        # permiso admin requerido
        is_admin = False
        if isinstance(self.current_user, dict):
            is_admin = bool(self.current_user.get("is_admin", 0) == 1)
        else:
            # si nos pasan username 'admin' string
            is_admin = (str(self.current_user).lower() == "admin")

        if not is_admin:
            messagebox.showerror("Permiso denegado", "Sólo el usuario admin puede eliminar registros")
            return

        sel = self.tree.selection()
        if not sel:
            messagebox.showerror("Error", "Seleccione un registro para eliminar")
            return
        iid = sel[0]
        try:
            row_id = int(iid)
        except:
            messagebox.showerror("Error", "ID inválido")
            return
        if not messagebox.askyesno("Eliminar", "¿Desea eliminar este registro?"):
            return
        self.cursor.execute("DELETE FROM sim WHERE id=?", (row_id,))
        self.conn.commit()
        self.refresh_list()
        self.clear_form()
        messagebox.showinfo("Éxito", "Registro eliminado correctamente")
        if self.log_manager:
            self.log_manager.log(self.current_user.get("username", "Unknown"), "SIM_DELETE", f"ID Eliminado: {row_id}")

    def search(self):
        term = self.search_entry.get().strip().lower()
        if not term:
            self.refresh_list()
            return
        for iid in self.tree.get_children():
            self.tree.delete(iid)
        self.cursor.execute("SELECT * FROM sim")
        for row in self.cursor.fetchall():
            # buscar en cualquiera de los campos (row[1:])
            if any(term in str(col).lower() for col in row[1:]):
                tag = 'evenrow'
                # Simplificación para búsqueda: alternar no es tan trivial sin índice, 
                # pero podemos contar al insertar.
                count = len(self.tree.get_children())
                tag = 'evenrow' if count % 2 == 0 else 'oddrow'
                self.tree.insert("", tk.END, iid=str(row[0]), values=row[1:], tags=(tag,))

    def clear_form(self):
        for f in self.fields:
            self.entries[f].delete(0, tk.END)
        self.selected_id = None

    def _close_parent(self):
        # si parent es Toplevel cerramos, si es Frame simplemente destruimos el frame
        try:
            if isinstance(self.parent, tk.Toplevel):
                self.parent.destroy()
            else:
                self.clear_frame()
        except:
            self.clear_frame()

    def export_excel(self):
        file = filedialog.asksaveasfilename(defaultextension=".xlsx", filetypes=[("Excel files", "*.xlsx")])
        if not file: return
        
        try:
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "SIMs"
            
            # Headers
            headers = self.fields
            ws.append(headers)
            
            self.cursor.execute("SELECT " + ",".join(headers) + " FROM sim")
            for row in self.cursor.fetchall():
                ws.append(row)
                
            wb.save(file)
            messagebox.showinfo("Exportar", "Datos exportados correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"Fallo al exportar: {e}")

    def import_excel(self):
        msg = "El Excel debe tener orden de columnas:\n" + ", ".join(self.fields) + "\n(O headers coincidentes). Identificador único: numero_tarjeta.\n¿Continuar?"
        if not messagebox.askyesno("Importar", msg): return
        
        file = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx")])
        if not file: return
        
        try:
            wb = openpyxl.load_workbook(file)
            ws = wb.active
            
            # Mapeo simple de headers si existen
            headers_map = {}
            for cell in ws[1]:
                if cell.value:
                    headers_map[str(cell.value).lower().strip()] = cell.column - 1
            
            # fields required
            count = 0
            for row in ws.iter_rows(min_row=2, values_only=True):
                if not row[0] and not row[4]: continue # Skip if empty abonado/card? logic flexible
                
                # Helper data extraction
                data = {}
                # Default mapping by index if headers fail or match simplistic
                for i, field in enumerate(self.fields):
                    # Try find by header name
                    col_idx = -1
                    for h_name, h_idx in headers_map.items():
                        if field in h_name:
                            col_idx = h_idx
                            break
                    
                    val = ""
                    if col_idx != -1 and col_idx < len(row):
                        val = row[col_idx]
                    elif i < len(row): # fallback positional
                        val = row[i]
                        
                    data[field] = str(val if val is not None else "").strip()
                
                # Chequeo duplicados por NUMERO TARJETA
                card = data.get("numero_tarjeta", "")
                existing_id = None
                
                if card:
                    self.cursor.execute("SELECT id FROM sim WHERE numero_tarjeta=?", (card,))
                    res = self.cursor.fetchone()
                    if res: existing_id = res[0]
                
                if existing_id:
                    # Update
                    self.cursor.execute("""
                        UPDATE sim SET abonado=?, cliente=?, sistema=?, compania=?, numero_telefono=?, notas=?
                        WHERE id=?
                    """, (
                        data["abonado"], data["cliente"], data["sistema"], data["compania"], 
                        data["numero_telefono"], data["notas"], existing_id
                    ))
                else:
                    # Insert
                    self.cursor.execute("""
                        INSERT INTO sim (abonado, cliente, sistema, compania, numero_tarjeta, numero_telefono, notas)
                        VALUES (?,?,?,?,?,?,?)
                    """, (
                        data["abonado"], data["cliente"], data["sistema"], data["compania"],
                        data["numero_tarjeta"], data["numero_telefono"], data["notas"]
                    ))
                count += 1
                
            self.conn.commit()
            self.refresh_list()
            messagebox.showinfo("Importar", f"Proceso completado. Registros procesados: {count}")
            if self.log_manager:
                self.log_manager.log(self.current_user.get("username", "Unknown"), "SIM_IMPORT", f"Registros procesados: {count}")

        except Exception as e:
            messagebox.showerror("Error", f"Fallo al importar: {e}")
